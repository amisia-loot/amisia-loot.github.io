-- Amisia guild wishes: the website's wishlist pasted in as text ("Copy for the addon" on the
-- Wishlist tab), so officers see at the loot who wished for an item: a tooltip line, a "W" on the
-- loot window and the group loot roll frames, wishers first in the award dialog. Wishes change no
-- rule: the roll order (SR, MS, OS, +1) stays as it is. Stored in AmisiaDB.bis.guild.
--
-- The pasted text is untrusted: escape codes and bars are stripped, every field is checked and
-- capped, and no link is ever built from it.
local ADDON, ns = ...
local L = ns.L

local HEAD_FAIL = L["Das ist keine Wunschliste der Amisia-Seite."]
local MAX_LINES = 2000      -- lines read, the head included
local MAX_LINE = 200        -- bytes of one line that are looked at
local NAME_MAX = 48
local NOTE_MAX = 40
local MAX_ID = 9999999
local OLD_DAYS = 14
local TIP_NAMES = 8         -- names in the tooltip line, the rest counted
-- The own game is always WoW Forever; "tbc" is named so that an old list is refused in words.
local OWN_GAME = "forever"
local GAME_NAMES = { forever = "WoW Forever", tbc = "TBC Anniversary" }
local PRIO_TIP = { [3] = L[" (hoch)"], [1] = L[" (niedrig)"] }
local PRIO_TEXT = { [3] = L["hoch"], [2] = L["mittel"], [1] = L["niedrig"] }
local BLUE = { 0.55, 0.75, 1 }

---------------------------------------------------------------------------
-- Parser and storage
---------------------------------------------------------------------------

-- Pasted text without escape codes (colours, links, textures, atlases) and without any bar left.
local function stripCodes(s)
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|H.-|h", ""):gsub("|h", "")
    s = s:gsub("|T.-|t", ""):gsub("|A.-|a", ""):gsub("|", "")
    return s
end

local function gameName(key)
    return GAME_NAMES[key] or stripCodes(tostring(key)):sub(1, 24)
end

-- A list name: "_" is the space of the site's text; no digits, no control characters, not too long.
local function cleanName(raw)
    local name = ns.FullName((raw:gsub("_", " ")))
    if not name or #name > NAME_MAX or name:find("[%d%c]") then return nil end
    return name
end

local function byPrio(a, b)
    if a.prio ~= b.prio then return a.prio > b.prio end
    return a.name < b.name
end

-- Reads the website's text:
--   #AMISIA-WL 1 <game> <yyyy-mm-dd>
--   W <itemID> <prio 1-3> <name with _> [<note>]
--   #END
-- Returns { game, date, list = { [id] = { { name, prio, note }, ... } }, n, skipped } or nil and
-- the reason (German). Lines it does not know are skipped and counted; at most 2000 lines are read.
function ns.ParseGuildWishes(text)
    if type(text) ~= "string" then return nil, HEAD_FAIL end
    local res = { list = {}, n = 0, skipped = 0 }
    local read, head, ended = 0, false, false
    for raw in text:gmatch("[^\r\n]+") do
        local line = stripCodes(raw:sub(1, MAX_LINE)):match("^%s*(.-)%s*$")
        if line ~= "" then
            if not head then
                line = line:gsub("^\239\187\191", "")
                local ver, game, day = line:match("^#AMISIA%-WL%s+(%d+)%s+(%S+)%s+(%S+)")
                if ver ~= "1" or not day or not day:match("^%d%d%d%d%-%d%d%-%d%d$") then return nil, HEAD_FAIL end
                game = game:lower()
                if game ~= OWN_GAME then
                    return nil, L["Diese Wunschliste ist für %s, du bist in %s."]:format(gameName(game), gameName(OWN_GAME))
                end
                res.game, res.date, head = game, day, true
                read = 1
            elseif line == "#END" then
                ended = true
                break
            elseif read >= MAX_LINES then
                res.skipped = res.skipped + 1
            else
                read = read + 1
                local id, prio, name, note = line:match("^W%s+(%d+)%s+(%d+)%s+(%S+)%s*(.-)$")
                id, prio = tonumber(id), tonumber(prio)
                name = name and cleanName(name)
                if not id or id < 1 or id > MAX_ID or not prio or not name then
                    res.skipped = res.skipped + 1
                else
                    prio = math.max(1, math.min(3, math.floor(prio)))
                    note = ns.CleanNote(note, NOTE_MAX) or ""
                    local entries = res.list[id] or {}
                    res.list[id] = entries
                    local same
                    for _, e in ipairs(entries) do
                        if e.name:lower() == name:lower() then same = e break end
                    end
                    if not same then
                        entries[#entries + 1] = { name = name, prio = prio, note = note }
                        res.n = res.n + 1
                    elseif prio > same.prio then
                        same.prio, same.note = prio, note
                    end
                end
            end
        end
    end
    if not head then return nil, HEAD_FAIL end
    if res.n == 0 then return nil, L["Die Liste ist leer."] end
    for _, entries in pairs(res.list) do table.sort(entries, byPrio) end
    res.ended = ended
    return res
end

local function guild()
    local b = AmisiaDB and AmisiaDB.bis
    local g = type(b) == "table" and b.guild
    if type(g) ~= "table" or type(g.list) ~= "table" then return nil end
    return g
end

local refreshMarks

-- Stores a pasted list (the old one stays when the text is refused). Returns the parse result or
-- nil and the reason.
function ns.SetGuildWishes(text)
    local res, why = ns.ParseGuildWishes(text)
    if not res then return nil, why end
    if not AmisiaDB then return nil, L["Amisia ist noch nicht geladen."] end
    if type(AmisiaDB.bis) ~= "table" then ns.BisMigrate(AmisiaDB) end
    AmisiaDB.bis.guild = { game = res.game, date = res.date, at = time(), by = ns.UnitFullName("player"), n = res.n, list = res.list }
    refreshMarks()
    ns.Fire("GUILD_WISHES")
    return res
end

function ns.ClearGuildWishes()
    if AmisiaDB and type(AmisiaDB.bis) == "table" then AmisiaDB.bis.guild = nil end
    refreshMarks()
    ns.Fire("GUILD_WISHES")
end

-- { date, n, age (whole days since the list's date), game } or nil without a list.
function ns.GuildWishesInfo()
    local g = guild()
    if not g then return nil end
    return { date = g.date, n = tonumber(g.n) or 0, age = ns.SoftResAge({ date = g.date }), game = g.game }
end

-- "Die Wunschliste ist 16 Tage alt." for a list older than two weeks, else nil.
function ns.GuildWishesAgeText()
    local info = ns.GuildWishesInfo()
    if info and info.age and info.age > OLD_DAYS then return L["Die Wunschliste ist %d Tage alt."]:format(info.age) end
    return nil
end

-- Who wished for an item: { { name, prio, note, inGroup } } by priority, then name; groupOnly
-- leaves out who is not in the group. A first name alone matches only while no other member of the
-- group carries it (ns.SameNameIn).
function ns.WishersOf(item, groupOnly)
    local g = guild()
    local id = tonumber(item) or ns.ItemID(item)
    local entries = g and id and g.list[id]
    local out = {}
    if type(entries) ~= "table" then return out end
    -- the group once per call: exact names in a set, the rest by first name, so ns.SameNameIn
    -- only runs for names that may match
    local roster = ns.GroupRoster()
    local exact, byFirst = {}, {}
    for _, r in ipairs(roster) do
        local low = r:lower()
        exact[low] = true
        local first = low:match("^(%S+)")
        byFirst[first] = byFirst[first] or {}
        table.insert(byFirst[first], r)
    end
    for _, e in ipairs(entries) do
        if type(e) == "table" and type(e.name) == "string" then
            local low = e.name:lower()
            local inGroup = exact[low] or false
            if not inGroup then
                for _, r in ipairs(byFirst[low:match("^(%S+)") or ""] or {}) do
                    if ns.SameNameIn(e.name, r, roster) then inGroup = true break end
                end
            end
            if inGroup or not groupOnly then
                out[#out + 1] = { name = e.name, prio = tonumber(e.prio) or 2, note = e.note, inGroup = inGroup }
            end
        end
    end
    table.sort(out, byPrio)
    return out
end

local function officerOn(path)
    return guild() ~= nil and ns.Get(path) and ns.IsOfficerView()
end

---------------------------------------------------------------------------
-- Tooltip line (officers), through the shared item tooltip hook
---------------------------------------------------------------------------

-- "Gewünscht: Anna (hoch), Bob (+2 außerhalb)": in a group only wishers from it, the others counted.
function ns.GuildWishTooltipText(item)
    local all = ns.WishersOf(item)
    if #all == 0 then return nil end
    local grouped = IsInGroup and IsInGroup() or false
    local shown, outside = {}, 0
    for _, e in ipairs(all) do
        if e.inGroup or not grouped then
            shown[#shown + 1] = e.name .. (PRIO_TIP[e.prio] or "")
        else
            outside = outside + 1
        end
    end
    local text
    if #shown == 0 then
        text = L["Gewünscht: niemand aus der Gruppe"]
    elseif #shown > TIP_NAMES then
        text = L["Gewünscht: %s und %d weitere"]:format(table.concat(shown, ", ", 1, TIP_NAMES), #shown - TIP_NAMES)
    else
        text = L["Gewünscht: %s"]:format(table.concat(shown, ", "))
    end
    if outside > 0 then text = text .. L[" (+%d außerhalb)"]:format(outside) end
    return text
end

ns.OnItemTooltip("guildwish", function(tip, _, id)
    if not officerOn("bis.guildTooltip") then return false end   -- l10n-ok: setting key
    local text = ns.GuildWishTooltipText(id)
    if not text then return false end
    tip:AddLine(text, BLUE[1], BLUE[2], BLUE[3])
    return true
end)

---------------------------------------------------------------------------
-- "W" on the loot window and the group loot roll frames (SR sits top left, W top right)
---------------------------------------------------------------------------

local lootMarks = setmetatable({}, { __mode = "k" })   -- loot button -> font string
local rollMarks = setmetatable({}, { __mode = "k" })   -- roll frame -> font string
local hooked = setmetatable({}, { __mode = "k" })

local function report(err)
    local handler = geterrorhandler and geterrorhandler()
    if handler then handler(err) end
end

local function wishedInGroup(link)
    local id = ns.ItemID(ns.Plain(link))
    return id ~= nil and #ns.WishersOf(id, true) > 0
end

local function setMark(store, owner, parent, on)
    local mark = store[owner]
    if on and not mark then
        -- on the item icon, top right (the quality text of a scrolling loot element sits on its right)
        mark = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        mark:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -1, -1)
        mark:SetText("W")
        mark:SetTextColor(BLUE[1], BLUE[2], BLUE[3])
        store[owner] = mark
    end
    if mark then
        if on then mark:Show() else mark:Hide() end
    end
end

-- btn: an element of the scrolling loot window; the mark sits on its icon button, btn.Item.
local function markButton(btn, slot, on)
    local icon = btn.Item
    if type(icon) ~= "table" or type(icon.CreateFontString) ~= "function" then return end
    local wished = on and slot and GetLootSlotLink and wishedInGroup(GetLootSlotLink(slot)) or false
    setMark(lootMarks, btn, icon, wished)
end

local function markLoot()
    local on = officerOn("bis.guildLootMark")   -- l10n-ok: setting key
    local box = LootFrame and LootFrame.ScrollBox
    if box and box.ForEachFrame then
        box:ForEachFrame(function(frame)
            if frame.GetSlotIndex then markButton(frame, frame:GetSlotIndex(), on) end
        end)
    end
end

-- Marks the open loot window again (protected).
function ns.MarkGuildWishLoot()
    local ok, err = pcall(markLoot)
    if not ok then report(err) end
end

-- The loot window is a scroll box that hands its element frames to other slots while it scrolls:
-- every element it sets up is marked again (the client's initialised-frame callback).
local scrollHooked
local function onLootElement(_, frame)
    if type(frame) ~= "table" or type(frame.GetSlotIndex) ~= "function" then return end
    local ok, err = pcall(function() markButton(frame, frame:GetSlotIndex(), officerOn("bis.guildLootMark")) end)   -- l10n-ok: setting key
    if not ok then report(err) end
end
local function hookLootScroll()
    if scrollHooked then return end
    local box = LootFrame and LootFrame.ScrollBox
    local util = _G.ScrollUtil
    if type(box) ~= "table" or type(util) ~= "table" or type(util.AddInitializedFrameCallback) ~= "function" then return end
    scrollHooked = true
    util.AddInitializedFrameCallback(box, onLootElement, lootMarks)
end
hookLootScroll()

local function markRoll(frame)
    local on = false
    local fn = _G.GetLootRollItemLink
    if officerOn("bis.guildLootMark") and type(fn) == "function" then   -- l10n-ok: setting key
        local ok, link = pcall(fn, ns.Plain(frame.rollID))
        on = ok and wishedInGroup(link) or false
    end
    local parent = type(frame.IconFrame) == "table" and frame.IconFrame or frame
    setMark(rollMarks, frame, parent, on)
end

local function onRollFrameShow(frame)
    local ok, err = pcall(markRoll, frame)
    if not ok then report(err) end
end

local function hookRollFrames()
    for i = 1, tonumber(_G.NUM_GROUP_LOOT_FRAMES) or 4 do
        local f = _G["GroupLootFrame" .. i]
        if type(f) == "table" and type(f.HookScript) == "function" and not hooked[f] then
            hooked[f] = true
            f:HookScript("OnShow", onRollFrameShow)
        end
    end
end
hookRollFrames()
ns.OnEvent("PLAYER_ENTERING_WORLD", hookRollFrames)

refreshMarks = function()
    ns.MarkGuildWishLoot()
    for frame in pairs(rollMarks) do
        if frame.IsShown and frame:IsShown() then onRollFrameShow(frame) end
    end
end

ns.OnEvent("LOOT_OPENED", function()
    hookLootScroll()
    C_Timer.After(0, ns.MarkGuildWishLoot)
end)
ns.OnEvent("LOOT_SLOT_CLEARED", function() C_Timer.After(0, ns.MarkGuildWishLoot) end)
ns.Listen("SETTING", function(path)
    if path == "bis.guildLootMark" or path == "ui.view" then refreshMarks() end   -- l10n-ok: setting key
end)

-- For tests and the window: the W of a loot button and of a roll frame.
function ns.GuildWishMark(btn) return lootMarks[btn] end
function ns.GuildWishMarkShown(btn)
    local m = lootMarks[btn]
    return (m and m:IsShown()) and true or false
end
function ns.GuildWishRollMarkText(frame)
    local m = rollMarks[frame]
    return (m and m:IsShown()) and m:GetText() or nil
end

---------------------------------------------------------------------------
-- Award dialog: wishers first (bis.guildAward), the rest as before
---------------------------------------------------------------------------

-- names: the dialog's names, sorted. Returns the picker values with the wishers of the item first
-- (by priority, "Anna (Wunsch hoch)"), or nil when nothing changes.
function ns.GuildWishAwardValues(item, names)
    if not item or not officerOn("bis.guildAward") then return nil end   -- l10n-ok: setting key
    local wishers = ns.WishersOf(item)
    if #wishers == 0 then return nil end
    local first, rest = {}, {}
    for _, n in ipairs(names) do
        local hit
        for _, e in ipairs(wishers) do
            if ns.SameNameIn(e.name, n, names) then hit = e break end
        end
        if hit then first[#first + 1] = { name = n, prio = hit.prio } else rest[#rest + 1] = n end
    end
    if #first == 0 then return nil end
    table.sort(first, byPrio)
    local values = {}
    for _, e in ipairs(first) do
        values[#values + 1] = { value = e.name, text = L["%s (Wunsch %s)"]:format(e.name, PRIO_TEXT[e.prio] or PRIO_TEXT[2]) }
    end
    for _, n in ipairs(rest) do values[#values + 1] = { value = n, text = n } end
    return values
end

---------------------------------------------------------------------------
-- Clearing (the gear page's guild view asks with this dialog) and the command
---------------------------------------------------------------------------

StaticPopupDialogs["AMISIA_GUILDWISH_CLEAR"] = {
    text = L["Die Gildenwünsche löschen?"],
    button1 = L["Löschen##Knopf"],
    button2 = L["Abbrechen"],
    OnAccept = function() ns.ClearGuildWishes() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

ns.RegisterSlash("wuensche", { en = "wishes", officer = true, desc = L["Gildenwünsche von der Website einfügen"],
    run = function()
        if not ns.IsOfficerView() then
            ns.msg(L["Gildenwünsche nur in der Offiziersansicht."])
            return
        end
        -- the gear page's guild view, with the import box
        ns.ShowGear("guild")
    end })
