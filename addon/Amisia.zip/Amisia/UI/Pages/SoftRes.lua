-- Soft-reserves: the loaded list in three views (items, raiders, the check against the raid),
-- name fixes with one click, importing and clearing for officers, and the overview card.
local ADDON, ns = ...
local L = ns.L
local W, T = ns.W, ns.Theme
-- rows of 22 from the column heads (90) to the footer (458): 16
local ROWS, ROW_H = 16, 22
local GREY, ORANGE, RED = T.GREY, T.ORANGE, "|cffff5050"
local MAX_CHIPS, CHIP_MAX_W = 3, 100
-- the columns of a row; the list is 590 px wide (602 of the content less 12 for its scroll bar)
local COL_A, COL_A_W, COL_B, COL_B_W, COL_C, COL_C_W = 6, 228, 238, 30, 272, 312
local COLS = { { "a", COL_A, COL_A_W }, { "b", COL_B, COL_B_W }, { "c", COL_C, COL_C_W } }

local GetItemInfo = C_Item.GetItemInfo

local page
local view = "items"   -- the chosen view, kept until logout

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function plural(n, one, many) return n == 1 and one or many end

local QCOLOR = { [0] = "9d9d9d", "ffffff", "1eff00", "0070dd", "a335ee", "ff8000", "e6cc80" }
local function quality(id)
    local known = AmisiaDB and AmisiaDB.itemNames and AmisiaDB.itemNames[id]
    local q = known and known.q
    if not q or q == 0 then
        local _, _, iq = GetItemInfo(id)
        q = iq or q
    end
    return q or 0
end

local function itemText(id)
    return ("|cff%s%s|r"):format(QCOLOR[quality(id)] or "ffffff", ns.ItemName(id))
end

local function itemLink(id)
    local _, link = GetItemInfo(id)
    return link or ("item:" .. tostring(id))
end

-- Puts a link into the chat the way the client does (ChatFrameUtil.InsertLink).
local function insertLink(link)
    if type(ChatFrameUtil) == "table" and type(ChatFrameUtil.InsertLink) == "function" then
        return ChatFrameUtil.InsertLink(link)
    end
end

local function times(sr, item, name) return ns.SoftResTimes(sr, item, name) end

local function withTimes(text, n) return n > 1 and ("%s x%d"):format(text, n) or text end

local function set(list)
    local out = {}
    for _, v in ipairs(list or {}) do out[v] = true end
    return out
end

-- What a refresh works with: the list, the roster, the check, the class of every raid member and
-- the list names outside the raid.
local function context()
    local sr = AmisiaDB and AmisiaDB.softres
    local roster, label = ns.SoftResRoster()
    local ctx = { sr = sr, roster = roster, label = label, classes = {}, absent = {} }
    ctx.check = sr and ns.SoftResCheck(sr, roster) or nil
    if ctx.check then ctx.absent = set(ctx.check.absent) end
    if IsInRaid() then
        for i = 1, GetNumGroupMembers() or 0 do
            local name, _, _, _, _, class = GetRaidRosterInfo(i)
            name = ns.FullName(ns.Plain(name))
            if name then ctx.classes[name:lower()] = ns.Plain(class) end
        end
    end
    return ctx
end

-- The class of a list name: the raid member it means, by spelling, else by ns.SameName.
local function classOf(ctx, name)
    local class = ctx.classes[name:lower()]
    if class then return class end
    for _, r in ipairs(ctx.roster) do
        if ns.SameName(r, name) then return ctx.classes[r:lower()] end
    end
    return nil
end

local function coloured(ctx, name)
    if ctx.absent[name] then return GREY .. name .. L[" (nicht im Raid)|r"] end
    local class = classOf(ctx, name)
    local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    return c and ("|c%s%s|r"):format(c.colorStr, name) or name
end

-- Every list name with its items { item, n } and the sum of its reservations.
local function byName(sr)
    local out = {}
    for item, names in pairs(sr and sr.byItem or {}) do
        for _, name in ipairs(names) do
            local e = out[name]
            if not e then
                e = { name = name, items = {}, n = 0 }
                out[name] = e
            end
            local n = times(sr, item, name)
            e.items[#e.items + 1] = { item = item, n = n, sort = ns.ItemName(item) }
            e.n = e.n + n
        end
    end
    for _, e in pairs(out) do
        table.sort(e.items, function(a, b) if a.sort ~= b.sort then return a.sort < b.sort end return a.item < b.item end)
    end
    return out
end

local function itemsText(items)
    local parts = {}
    for _, it in ipairs(items) do parts[#parts + 1] = withTimes(ns.ItemName(it.item), it.n) end
    return table.concat(parts, ", ")
end

-- "Abgleich mit Raid (25): 22 reserviert · 3 ohne · ..." from the check.
local function checkLine(ctx)
    local c = ctx.check
    if not c then return "" end
    if not ctx.label then return L["Kein Raid zum Abgleichen."] end
    local parts = { L["Abgleich mit %s: %d reserviert"]:format((ctx.label:gsub("^letzter ", "letztem ")), #c.ok) }   -- l10n-ok: German case of the label (English has no match)
    if #c.missing > 0 then parts[#parts + 1] = L["%d ohne"]:format(#c.missing) end
    if #c.absent > 0 then parts[#parts + 1] = L["%d nicht im Raid"]:format(#c.absent) end
    if #c.unclear > 0 then parts[#parts + 1] = L["%d unklar"]:format(#c.unclear) end
    if #c.over > 0 then parts[#parts + 1] = L["%d zu viel"]:format(#c.over) end
    return table.concat(parts, " · ")
end

---------------------------------------------------------------------------
-- The rows of the three views
---------------------------------------------------------------------------
local function itemRows(ctx, me)
    local out = {}
    for item, names in pairs(ctx.sr and ctx.sr.byItem or {}) do
        local parts, mine = {}, false
        for _, name in ipairs(names) do
            local label = withTimes(name, times(ctx.sr, item, name))
            parts[#parts + 1] = ctx.absent[name] and (GREY .. label .. L[" (nicht im Raid)|r"]) or label
            if me and ns.SameName(name, me) then mine = true end
        end
        out[#out + 1] = { kind = "item", item = item, sort = ns.ItemName(item), text = table.concat(parts, ", "), mine = mine }
    end
    table.sort(out, function(a, b) if a.sort ~= b.sort then return a.sort < b.sort end return a.item < b.item end)
    return out
end

local function raiderRows(ctx, me)
    local limit = tonumber(ns.Get("softres.limit")) or 0
    local out = {}
    for name, e in pairs(byName(ctx.sr)) do
        out[#out + 1] = { kind = "raider", name = name, n = e.n, over = limit > 0 and e.n > limit,
                          text = itemsText(e.items), mine = me and ns.SameName(name, me) or false,
                          was = ctx.sr and ctx.sr.renamed and ctx.sr.renamed[name] or nil }
    end
    for _, name in ipairs(ctx.check and ctx.check.missing or {}) do
        out[#out + 1] = { kind = "raider", name = name, n = 0, text = L["keine"], mine = me and ns.SameName(name, me) or false }
    end
    table.sort(out, function(a, b)
        local la, lb = a.name:lower(), b.name:lower()
        if la ~= lb then return la < lb end
        return a.n > b.n
    end)
    return out
end

-- One row per finding: unclear, too many, without a reservation, not in the raid, doubles.
local function checkRows(ctx)
    local c, sr = ctx.check, ctx.sr
    local out = {}
    if not c then return out end
    local names = byName(sr)
    local unclear = {}
    for _, u in ipairs(c.unclear) do
        unclear[u.name] = true
        out[#out + 1] = { kind = "unclear", name = u.name, suggest = u.suggest,
                          label = ORANGE .. L["Unklar:|r %s"]:format(u.name) .. (u.kind == "surname" and L[" (ohne Nachnamen)"] or L[" (Schreibweise?)"]) }
    end
    local limit = tonumber(ns.Get("softres.limit")) or 0
    for _, o in ipairs(c.over) do
        out[#out + 1] = { kind = "over", name = o.name, label = RED .. L["Zu viel:|r %s"]:format(o.name),
                          text = L["%d Reservierungen, erlaubt %d"]:format(o.n, limit) }
    end
    local reminded = sr and sr.reminded or {}
    for _, name in ipairs(c.missing) do
        local at = tonumber(reminded[name])
        out[#out + 1] = { kind = "missing", name = name, label = L["Ohne Reserve: %s"]:format(name),
                          text = at and L["erinnert %s"]:format(date("%H:%M", at)) or "" }
    end
    for _, name in ipairs(c.absent) do
        if not unclear[name] then
            out[#out + 1] = { kind = "absent", name = name, label = GREY .. L["Nicht im Raid:|r %s"]:format(name),
                              text = names[name] and itemsText(names[name].items) or "" }
        end
    end
    for _, m in ipairs(c.multi) do
        out[#out + 1] = { kind = "multi", name = m.name, label = GREY .. L["Mehrfach:|r %s"]:format(m.name),
                          text = withTimes(ns.ItemName(m.item), m.n) }
    end
    return out
end

---------------------------------------------------------------------------
-- The page
---------------------------------------------------------------------------
function ns.SoftResPageFrame() return page end

-- Opens the page on one view ("items", "raider", "check").
function ns.ShowSoftRes(v)
    if v == "items" or v == "raider" or v == "check" then view = v end
    ns.ShowPage("softres")
end

local function chooseView(v)
    view = v
    ns.Refresh()
end

local function col(parent, x, w, template)
    local fs = W.Text(parent, template or T.FONT.text, w)
    fs:SetPoint("LEFT", x, 0)
    return fs
end

local HEADS = {
    items = { "Item", "", L["Reserviert von"] },
    raider = { L["Raider##Spalte"], "SR", "Items" },
    check = { L["Befund"], "", L["Vorschläge und Details"] },
}

local function buildRow(r)
    r.sel = W.SelectBar(r)
    r.a = col(r, COL_A, COL_A_W)
    r.b = col(r, COL_B, COL_B_W)
    r.c = col(r, COL_C, COL_C_W)
    r.chips = {}
    for i = 1, MAX_CHIPS do
        local chip = W.Chip(r, "", 60, function(self)
            if not self.from or not self.to then return end
            local from, to = self.from, self.to
            if ns.RenameReserve(from, to, true) > 0 then
                ns.msg(L["Soft-Reserves: %s heißt jetzt %s, auch in kommenden Listen."]:format(from, to))
            end
        end)
        if i == 1 then
            chip:SetPoint("LEFT", COL_C, 0)
        else
            chip:SetPoint("LEFT", r.chips[i - 1], "RIGHT", 4, 0)
        end
        chip:SetOn(false)
        chip:Hide()
        r.chips[i] = chip
    end
    r:SetScript("OnClick", function(self)
        local e = self.item
        if e and e.kind == "item" and IsShiftKeyDown and IsShiftKeyDown() then insertLink(itemLink(e.item)) end
    end)
    r:SetScript("OnEnter", function(self)
        local e = self.item
        if not e then return end
        if e.kind == "item" and GameTooltip.SetHyperlink then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetHyperlink(itemLink(e.item))
            GameTooltip:Show()
        elseif e.kind == "unclear" then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(e.name, 1, 0.82, 0)
            GameTooltip:AddLine(L["Ein Klick auf einen Vorschlag korrigiert den Namen in der Liste und merkt die Korrektur für kommende Listen."],
                0.85, 0.85, 0.85, true)
            GameTooltip:Show()
        elseif e.kind == "raider" and e.was then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(e.name, 1, 0.82, 0)
            GameTooltip:AddLine(L["In der Liste als %s, korrigiert."]:format(e.was), 0.85, 0.85, 0.85, true)
            if ns.SoftResAlias(e.was) then
                GameTooltip:AddLine(L["Die Korrektur gilt auch für kommende Listen. \"/amisia sr vergessen %s\" nimmt sie zurück, ohne Namen vergisst es alle gemerkten Korrekturen."]:format(e.was),
                    0.85, 0.85, 0.85, true)
            end
            GameTooltip:Show()
        end
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Every field of a pooled row is set here, so nothing of an earlier entry stays.
local function fillRow(r, e)
    local ctx = page and page.ctx
    local raiderView = not ns.IsOfficerView()
    r.b:SetText("")
    r.c:SetText("")
    local shownChips = 0
    if e.kind == "item" then
        r.a:SetText(itemText(e.item))
        r.c:SetText(e.text)
    elseif e.kind == "raider" then
        local was = e.was
        r.a:SetText((ctx and coloured(ctx, e.name) or e.name) .. (was and (GREY .. L[" (Liste: %s)|r"]:format(was)) or ""))
        r.b:SetText(e.over and (RED .. e.n .. "|r") or tostring(e.n))
        r.c:SetText(e.text)
    else
        r.a:SetText(e.label)
        if e.kind == "unclear" then
            for i, name in ipairs(e.suggest or {}) do
                if i > MAX_CHIPS then break end
                local chip = r.chips[i]
                chip.label:SetText(name)
                W.FitChip(chip, nil, CHIP_MAX_W)
                chip.from, chip.to = e.name, name
                chip:SetOn(false)
                chip:Show()
                shownChips = i
            end
        else
            r.c:SetText(e.text or "")
        end
    end
    for i = shownChips + 1, MAX_CHIPS do
        local chip = r.chips[i]
        chip.from, chip.to = nil, nil
        chip:Hide()
    end
    if raiderView and e.mine then r.sel:Show() else r.sel:Hide() end
end

ns.RegisterPanel{ key = "softres", label = L["Soft-Reserves"], icon = "Interface\\Icons\\INV_Scroll_03", order = 40, group = "raid",
    create = function(parent)
        local f = W.Page(parent)
        page = f
        -- the head row: the list, import and clear on the right; then the check; then the views with
        -- remind and post (officers) on the right
        f:Bands({ "row", "line", "row" })
        f.state = W.Text(f, T.FONT.body)
        f.clear = W.Button(f, L["Löschen##Knopf"], 90, function() ns.ClearSoftRes() end)
        f.import = W.Button(f, L["Importieren"], 110, function() ns.ToggleSoftResFrame() end)
        W.FitChip(f.clear, 90)
        W.FitChip(f.import, 110)
        f:Place(1, { { f.state, fill = true } }, { f.import, f.clear })
        f.check = f:Line(2)
        f.views = {}
        f.views.items = W.Chip(f, "Items", 60, function() chooseView("items") end)
        f.views.raider = W.Chip(f, L["Raider##Spalte"], 60, function() chooseView("raider") end)
        f.views.check = W.Chip(f, L["Abgleich"], 70, function() chooseView("check") end)
        for _, c in pairs(f.views) do W.FitChip(c, 60) end
        f.post = W.Button(f, L["Im Raid posten"], 120, function()
            local n, why = ns.PostSoftResSummary()
            if not n and why then ns.msg(why) end
        end)
        f.remind = W.Button(f, L["Erinnern"], 110, function() ns.ConfirmSoftResReminders() end)
        W.FitChip(f.post, 120)
        W.Tooltip(f.remind, L["Erinnern"], L["Flüstert jedem im Raid ohne Reservierung einmal pro Liste, nach einer Rückfrage."])
        W.Tooltip(f.post, L["Im Raid posten"], L["Wie viele reserviert haben und wer noch nicht, in den Schlachtzugschat."])
        f:Place(3, { f.views.items, f.views.raider, f.views.check }, { f.remind, f.post })
        f:Footer({ "hint" })
        local _, heads = f:Columns(COLS)
        f.heads = { heads.a, heads.b, heads.c }
        f.list = f:List(ROWS, ROW_H, buildRow, fillRow)
        f.empty = f:Empty()
        return f
    end,
    refresh = function(f)
        local officer = ns.IsOfficerView()
        local ctx = context()
        f.ctx = ctx
        local sr = ctx.sr
        if sr then
            local old = ns.SoftResAge(sr) or 0
            local warn = old > (ns.Get("softres.warnDays") or 7)
            local reservers = ctx.check and ctx.check.reservers or 0
            f.state:SetText(L["%sListe vom %s:|r %d Reservierungen von %d %s%s"]:format(warn and ORANGE or "|cff4fbf7a",
                ns.SoftResShortDate(sr.date), sr.count or 0, reservers, plural(reservers, L["Raider##von"], L["Raidern##von"]),
                warn and L[", %d Tage alt"]:format(old) or ""))
        else
            f.state:SetText(GREY .. L["Keine Soft-Reserves geladen."] .. "|r")
        end
        f.check:SetText(checkLine(ctx))
        f.views.items:Show(); f.views.raider:Show()
        if officer then
            f.import:Show(); f.clear:Show()
            f.clear:SetEnabled(sr ~= nil)
            f.views.check:Show()
            local raid = IsInRaid() and sr ~= nil
            local open = raid and #ns.SoftResReminders(ctx.check) or 0
            f.remind:SetText(L["Erinnern (%d)"]:format(open))
            W.FitChip(f.remind, 110)
            f.remind:SetEnabled(raid and open > 0)
            f.post:SetEnabled(raid)
            f.remind:Show(); f.post:Show()
        else
            f.import:Hide(); f.clear:Hide()
            f.views.check:Hide()
            f.remind:Hide(); f.post:Hide()
        end
        f:Place(3, { f.views.items, f.views.raider, f.views.check }, { f.remind, f.post }, { shown = true })
        if not sr then
            f.empty:Set(L["Keine Soft-Reserves"], officer and L["Importieren nimmt eine softres.it-CSV oder Zeilen wie 'Name [Item-Link]'."]
                or L["Die Lootleitung hat noch keine Liste geladen."])
        end
        f.empty:SetShown(not sr)
        local shown = view
        if shown == "check" and not officer then shown = "items" end
        for key, chip in pairs(f.views) do chip:SetOn(key == shown) end
        for i, text in ipairs(HEADS[shown]) do f.heads[i]:SetText(text) end
        local me = ns.UnitFullName("player")
        local list
        if shown == "raider" then
            list = raiderRows(ctx, me)
        elseif shown == "check" then
            list = checkRows(ctx)
        else
            list = itemRows(ctx, me)
        end
        f.list:SetItems(list)
        if not sr then
            -- the empty state over the list says how to import
            f.hint:SetText("")
        elseif shown == "check" then
            f.hint:SetText(#list == 0 and L["Nichts zu prüfen."] or L["Vorschläge korrigieren den Namen und gelten auch für kommende Listen."])
        elseif shown == "items" then
            f.hint:SetText(L["Shift-Klick auf ein Item fügt den Link in den Chat ein."])
        else
            f.hint:SetText("")
        end
    end }

-- The roster changed: the check may have changed with it. A burst of updates (a 40-man raid
-- forming) makes one refresh half a second later.
local rosterPending = false
ns.OnEvent("GROUP_ROSTER_UPDATE", function()
    if rosterPending then return end
    rosterPending = true
    C_Timer.After(0.5, function()
        rosterPending = false
        local cur = ns.CurrentPage and ns.CurrentPage()
        if cur == "softres" or cur == "overview" then ns.Refresh() end
    end)
end)

ns.RegisterCard{ key = "softres", order = 20, fill = function(c)
    local sr = AmisiaDB and AmisiaDB.softres
    c.title:SetText(L["Soft-Reserves"])
    if not sr then
        c.line1:SetText(L["Keine Liste geladen"])
        if ns.IsOfficerView() then c:SetAction(L["Importieren"], function() ns.ToggleSoftResFrame() end) end
        return
    end
    c.line1:SetText(L["%d Reservierungen, vom %s"]:format(sr.count or 0, sr.date))
    local roster, label = ns.SoftResRoster()
    local chk = ns.SoftResCheck(sr, roster)
    local unclear = chk and #chk.unclear or 0
    local tail = unclear > 0 and L[" · %d %s unklar"]:format(unclear, plural(unclear, L["Name##Anzahl"], L["Namen##Anzahl"])) or ""
    if not label or not chk then
        c.line2:SetText("")
    elseif IsInRaid() then
        c.line2:SetText(L["%d von %d im Raid reserviert"]:format(#chk.ok, chk.roster) .. tail)
    else
        c.line2:SetText(L["Abgleich mit letztem Raid: %s"]:format(#chk.missing > 0 and L["%d ohne Reserve"]:format(#chk.missing)
            or L["alle reserviert"]) .. tail)
    end
    if ns.IsOfficerView() and unclear > 0 then
        c:SetAction(L["Prüfen"], function() ns.ShowSoftRes("check") end)
    else
        c:SetAction(L["Ansehen"], function() ns.ShowPage("softres") end)

    end
end }
