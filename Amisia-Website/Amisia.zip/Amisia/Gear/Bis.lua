-- Amisia best items for the own character: the three best options per slot from
-- the loaded data set (Gear.lua scores them with Amisia's own weights), held against what the
-- character wears, carries and keeps in the bank; exclusions by item, boss and place; what a place
-- still offers. Everything per character in AmisiaDB.bis. Nothing here reads combat data: only the
-- item stats the client shows in every tooltip, the own bags, bank, talents and professions.
local ADDON, ns = ...
local L = ns.L
local Gear = ns.Gear

local function itemInfo(x)
    local f = C_Item and C_Item.GetItemInfo
    if f then return f(x) end
    return nil
end
local function itemInstant(x)
    local f = C_Item and C_Item.GetItemInfoInstant
    if f then return f(x) end
    return nil
end

local MAX_WISH, NOTE_MAX = 50, 40
ns.BIS_MAX_WISH = MAX_WISH
local PICK_SPECS = 8          -- own picks (F-112): spec tables kept per character
-- the rows of the targets (Gear.SLOTS): the keys an own pick may have
local PICK_SLOT = {}
for _, sl in ipairs(Gear.SLOTS) do PICK_SLOT[sl.key] = true end
-- Weapon plans: auto (the larger sum of a two-hander and main hand plus off hand), only a
-- two-hander, two weapons, weapon and shield (or a held item).
ns.BIS_PLANS = { auto = L["automatisch"], ["2H"] = L["Zweihand"], DW = L["zwei Waffen"], SHIELD = L["Waffe und Schild"] }
ns.BIS_PLAN_ORDER = { "auto", "2H", "DW", "SHIELD" }

local stamp = 0          -- bumped by everything that changes a result; part of every cache key
-- bumped (with stamp) by what changes Gear.Best's lists: data, item stats and suffixes, settings,
-- talents, BiS changes; not by ownership, which only the targets' annotations read
local scoreStamp = 0
local function bump() stamp = stamp + 1 end
local function bumpAll() stamp = stamp + 1; scoreStamp = scoreStamp + 1 end
ns.BisBump = bumpAll
-- a change of the results only (the character sheet of Gear/Model.lua): Gear.Best's lists stay
ns.BisBumpResults = bump
-- The state counter: a page keeps what it showed until this changes.
function ns.BisStamp() return stamp end
-- only what changes scores (data, talents, settings; not what is owned): for results without ownership
function ns.BisScoreStamp() return scoreStamp end

---------------------------------------------------------------------------
-- Saved data and its move
---------------------------------------------------------------------------

local function numKey(k)
    local n = tonumber(k)
    if n and n > 0 and n % 1 == 0 then return n end
    return nil
end
local function strKey(k) return (type(k) == "string" and k ~= "") and k or nil end
local function trueVal(v) return v and true or nil end

-- Fixes a table in place: keys through keyOf, values through valOf; nil from either drops the entry.
local function fixSet(t, keyOf, valOf)
    if type(t) ~= "table" then return {} end
    local moves = {}
    for k, v in pairs(t) do
        local nk, nv = keyOf(k), valOf(v)
        if nk == nil or nv == nil then
            moves[#moves + 1] = { k }
        elseif nk ~= k or nv ~= v then
            moves[#moves + 1] = { k, nk, nv }
        end
    end
    for _, m in ipairs(moves) do
        t[m[1]] = nil
        if m[2] ~= nil then t[m[2]] = m[3] end
    end
    return t
end

local function cleanWish(e)
    if type(e) ~= "table" then return nil end
    e.t = tonumber(e.t) or 0
    e.prio = math.max(1, math.min(3, math.floor(tonumber(e.prio) or 2)))
    -- ns.CleanNote (Awards.lua): no bars or line breaks, cut without splitting a character
    e.note = ns.CleanNote(e.note, NOTE_MAX) or ""
    return e
end

-- The own run of a dungeon (Runs.lua, D-72): { inst, name, enc = { [encounter id] = true }, at,
-- left, reset }; anything else falls away.
local function cleanRun(r)
    if type(r) ~= "table" or not numKey(r.inst) then return nil end
    r.enc = fixSet(r.enc, numKey, trueVal)
    r.at = tonumber(r.at)
    r.left = tonumber(r.left)
    r.reset = tonumber(r.reset)
    if r.name ~= nil and type(r.name) ~= "string" then r.name = nil end
    return r
end

local function cleanChar(c)
    c.run = cleanRun(c.run)
    c.wish = fixSet(c.wish, numKey, cleanWish)
    -- more than 50: the oldest go
    local list = {}
    for id in pairs(c.wish) do list[#list + 1] = id end
    if #list > MAX_WISH then
        table.sort(list, function(a, b)
            local ta, tb = c.wish[a].t, c.wish[b].t
            if ta ~= tb then return ta > tb end
            return a < b
        end)
        for i = MAX_WISH + 1, #list do c.wish[list[i]] = nil end
    end
    local ex = type(c.ex) == "table" and c.ex or {}
    ex.item = fixSet(ex.item, numKey, trueVal)
    ex.boss = fixSet(ex.boss, strKey, trueVal)
    ex.place = fixSet(ex.place, strKey, trueVal)
    c.ex = ex
    c.bag = fixSet(c.bag, numKey, tonumber)
    c.bank = fixSet(c.bank, numKey, tonumber)
    c.bankAt = tonumber(c.bankAt)
    if c.spec ~= nil and type(c.spec) ~= "string" then c.spec = nil end
    if c.class ~= nil and type(c.class) ~= "string" then c.class = nil end
    -- the weapon plan: auto | 2H | DW | SHIELD
    if c.plan ~= nil and not ns.BIS_PLANS[c.plan] then c.plan = "auto" end
    -- the own picks (F-112, D-55): { [spec] = { [slot of Gear.SLOTS] = item id } }; an empty spec
    -- table falls away, at most PICK_SPECS specs
    if c.pick ~= nil then
        local pick = fixSet(c.pick, function(k) return (type(k) == "string" and k:find("^%a+$")) and k or nil end, function(t)
            if type(t) ~= "table" then return nil end
            fixSet(t, function(k) return PICK_SLOT[k] and k or nil end, numKey)
            return next(t) and t or nil
        end)
        local specs = {}
        for k in pairs(pick) do specs[#specs + 1] = k end
        table.sort(specs)
        for i = PICK_SPECS + 1, #specs do pick[specs[i]] = nil end
        c.pick = next(pick) and pick or nil
    end
end

-- Settings of the TBC data that WoW Forever has no use for: the content phase, and the source
-- switches for heroic dungeons (H) and reputation (F).
local function dropTbcSettings(root)
    local s = type(root.settings) == "table" and root.settings
    local bis = s and type(s.bis) == "table" and s.bis
    if not bis then return end
    bis.phase = nil
    if type(bis.sources) == "table" then
        bis.sources.H = nil
        bis.sources.F = nil
    end
end

-- Called on ADDON_LOADED (and whenever the table is missing): the shape of AmisiaDB.bis, checked
-- entries, wishes capped at 50; the guild wishes without numeric keys fall away, and so does a
-- guild list for another game. Running it twice changes nothing.
function ns.BisMigrate(root)
    dropTbcSettings(root)
    local b = type(root.bis) == "table" and root.bis or {}
    root.bis = b
    b.v = 1
    b.chars = type(b.chars) == "table" and b.chars or {}
    local drop = {}
    for k, c in pairs(b.chars) do
        if type(k) ~= "string" or type(c) ~= "table" then drop[#drop + 1] = k else cleanChar(c) end
    end
    for _, k in ipairs(drop) do b.chars[k] = nil end
    if b.guild ~= nil then
        if type(b.guild) ~= "table" or b.guild.game ~= "forever" then
            b.guild = nil
        else
            b.guild.list = fixSet(b.guild.list, numKey, function(v) return type(v) == "table" and v or nil end)
        end
    end
    bumpAll()
    return b
end

ns.OnEvent("ADDON_LOADED", function(name)
    if name == ADDON and AmisiaDB then ns.BisMigrate(AmisiaDB) end
end)

local function db()
    if not AmisiaDB then return nil end
    local b = AmisiaDB.bis
    if type(b) ~= "table" or type(b.chars) ~= "table" then b = ns.BisMigrate(AmisiaDB) end
    return b
end

local function hasSpec(class, key)
    for _, sp in ipairs(Gear.Specs(class)) do
        if sp.key == key then return true end
    end
    return false
end

-- The entry of the logged-in character, made on first use; its spec starts as the Forever planner's
-- choice for the class, when there is one. Unchecked: the check would build the weights at every alt's
-- first login (D-28); ns.BisSpec passes over a spec the weights do not have.
function ns.BisChar()
    local b = db()
    if not b then return nil end
    local key = ns.UnitFullName("player") or "?"
    local c = b.chars[key]
    if not c then
        local _, class = UnitClass("player")
        c = { class = class, wish = {}, ex = { item = {}, boss = {}, place = {} }, bag = {}, bank = {} }
        local g = AmisiaDB.settings and AmisiaDB.settings.gear
        local planned = class and type(g) == "table" and type(g.specs) == "table" and g.specs[class] or nil
        if type(planned) == "string" then c.spec = planned end
        b.chars[key] = c
    end
    return c
end

---------------------------------------------------------------------------
-- Spec: chosen, else guessed from the talent trees
---------------------------------------------------------------------------

-- Talent tree -> spec keys of the weights, the first that exists wins (a discipline priest falls
-- back to holy where the weights have no discipline; demonology plays like destruction here).
local TREE = {
    WARRIOR = { { "dps" }, { "dps" }, { "tank" } },
    PALADIN = { { "holy" }, { "tank" }, { "ret" } },
    HUNTER = { { "dps" }, { "dps" }, { "dps" } },
    ROGUE = { { "dps" }, { "dps" }, { "dps" } },
    PRIEST = { { "disc", "holy" }, { "holy" }, { "shadow" } },
    SHAMAN = { { "ele" }, { "enh" }, { "resto" } },
    MAGE = { { "arcane" }, { "fire" }, { "frost" } },
    WARLOCK = { { "affli" }, { "destro", "affli" }, { "destro" } },
    DRUID = { { "balance" }, { "feral" }, { "resto" } },
}

-- Points spent in a talent tree: C_SpecializationInfo.GetSpecializationInfo (7th return), else the
-- compatibility GetTalentTabInfo (5th); nil when the client tells nothing.
local function treePoints(i)
    local info = _G.C_SpecializationInfo
    local fn = type(info) == "table" and info.GetSpecializationInfo
    if type(fn) == "function" then
        local ok, _, _, _, _, _, _, pts = pcall(fn, i)
        pts = ok and ns.Plain(pts) or nil
        if type(pts) == "number" then return pts end
    end
    if type(_G.GetTalentTabInfo) == "function" then
        local ok, _, _, _, _, pts = pcall(_G.GetTalentTabInfo, i)
        pts = ok and ns.Plain(pts) or nil
        if type(pts) == "number" then return pts end
    end
    return nil
end

local guess, guessClass   -- cached guess (false: none), for the class it was made for
local function guessSpec(class)
    local best, bestPts = nil, 0
    for i, keys in ipairs(TREE[class] or {}) do
        local pts = treePoints(i)
        if pts and pts > bestPts then
            for _, key in ipairs(keys) do
                if hasSpec(class, key) then best, bestPts = key, pts break end
            end
        end
    end
    if best then return best end
    local first = Gear.Specs(class)[1]
    return first and first.key or false
end

-- The spec in use and whether it is guessed.
function ns.BisSpec()
    local _, class = UnitClass("player")
    local c = ns.BisChar()
    if c and c.spec and hasSpec(class, c.spec) then return c.spec, false end
    if guess == nil or guessClass ~= class then guess, guessClass = guessSpec(class), class end
    return guess or nil, true
end

-- Chooses a spec (nil: guess again).
function ns.BisSetSpec(key)
    local c = ns.BisChar()
    if not c then return end
    c.spec = key
    guess = nil
    ns.Fire("BIS_CHANGED")
end

-- The weapon plan of the own character (ns.BIS_PLANS); true, or nil and the reason.
function ns.BisSetPlan(plan)
    local c = ns.BisChar()
    if not c then return nil, L["Amisia ist noch nicht geladen."] end
    if not ns.BIS_PLANS[plan] then return nil, L["Waffenplan: auto, 2H, DW oder SHIELD."] end
    c.plan = plan
    ns.Fire("BIS_CHANGED")
    return true
end

---------------------------------------------------------------------------
-- Own professions
---------------------------------------------------------------------------

local PROF_BY_NAME, PROF_ID = Gear.PROF_BY_NAME, Gear.PROF_ID
local PROF_BY_ID = {}
for k, v in pairs(PROF_ID) do PROF_BY_ID[v] = k end

local skills   -- cached { tailoring = 375, [197] = 375 }, false when the client cannot tell
local function addSkill(out, key, rank)
    rank = tonumber(rank) or 0
    if not key then return end
    out[key] = math.max(out[key] or 0, rank)
    out[PROF_ID[key]] = out[key]
end

-- The own professions with skill, or nil when the client offers no skill list (the chip "nur
-- meine" then has no use). C_SkillInfo gives a table per line (SkillLineAttributes).
function ns.BisSkills()
    if skills ~= nil then return skills or nil end
    local out, lines = {}, Gear.SkillLines()
    for _, s in ipairs(lines or {}) do
        addSkill(out, PROF_BY_ID[s.skillID] or (type(s.name) == "string" and PROF_BY_NAME[s.name:lower()]), s.rank)
    end
    skills = lines and out or false
    return skills or nil
end

---------------------------------------------------------------------------
-- Options
---------------------------------------------------------------------------

-- The source switches of the page (window state settings.bis.sources): everything but random world
-- drops, the auction house and PvP vendors. settings.bis.srcRule 2: the world drops were switched
-- off once for the realistic sources (D-59); the player may switch them on again.
local function sourceState()
    local s = AmisiaDB and AmisiaDB.settings
    if not s then return { X = true, D = true, V = true, C = true, W = false, Q = true } end
    s.bis = type(s.bis) == "table" and s.bis or {}
    if type(s.bis.sources) ~= "table" then
        s.bis.sources = { X = true, D = true, V = true, C = true, W = false, Q = true, A = false, P = false }
    end
    if s.bis.srcRule ~= 2 then
        s.bis.sources.W, s.bis.srcRule = false, 2
    end
    return s.bis.sources
end

-- The scoring switches every option set carries: random suffixes, set plan, effort tie, BiS picks.
local function scoringOpts(o)
    o.suffix = ns.Get("bis.suffix") or "best"   -- l10n-ok: setting key
    o.picks = ns.Get("bis.picks") ~= false   -- l10n-ok: setting key
    o.sets = ns.Get("bis.sets") ~= false   -- l10n-ok: setting key
    o.tie = tonumber(ns.Get("bis.effortTie")) or 3   -- l10n-ok: setting key
    return o
end

-- set below (it needs the item rows): the own picks of the spec the options use, and those they
-- keep but do not use (code "plan": not with the weapon plan; "class", "slot": not wearable now)
local ownPicks

-- The options of the own character: class, spec (guessed), weighting kind, faction (A/H), level up
-- to the data's cap, source switches, professions ("all"/"mine") with the own skills, the
-- exclusions, the weapon plan, the scoring switches, (bis.hitCap) the hit still useful per row and
-- the own picks of the spec (own = { [slot] = id } in use, ownUnused = { [slot] = code }).
function ns.BisOpts()
    local c = ns.BisChar()
    local _, class = UnitClass("player")
    local spec, guessed = ns.BisSpec()
    local o = {
        class = class, spec = spec, guessed = guessed, kind = ns.Get("bis.kind") or "Speedrun",   -- l10n-ok: setting key
        faction = ns.OwnFaction(),
        level = math.max(1, math.min(tonumber(UnitLevel("player")) or 1, Gear.Cap())),
        sources = sourceState(),
        prof = ns.Get("bis.prof") or "all", skills = ns.BisSkills(),   -- l10n-ok: setting key
        exclude = c and c.ex or nil,
        plan = c and c.plan or "auto",
    }
    scoringOpts(o)
    o.cap = ns.BisHitCaps and ns.BisHitCaps(o) or nil
    o.own, o.ownUnused = ownPicks(c, o)
    -- the play style (F-124): only the own options carry it
    o.style = ns.PlayStyle and ns.PlayStyle.Context(o) or nil
    return o
end

-- The same calculation for any class, spec and level (the simulation, the planner table, the
-- catalog's level sets): no ownership, no exclusions unless opts.exclude, both factions unless
-- opts.faction, the own source switches unless opts.sources, no play style unless opts.style (a
-- ns.PlayStyle.Context). Returns Gear.Best's result.
function ns.BisFor(class, spec, level, opts)
    opts = opts or {}
    local o = {
        class = class, spec = spec or (Gear.Specs(class)[1] or {}).key, kind = opts.kind or ns.Get("bis.kind") or "Speedrun",   -- l10n-ok: setting key
        faction = opts.faction, level = math.max(1, math.min(tonumber(level) or 1, Gear.Cap())),
        sources = opts.sources or sourceState(), prof = "all", plan = opts.plan or "auto", exclude = opts.exclude,
    }
    scoringOpts(o)
    if opts.tie ~= nil then o.tie = opts.tie end
    if opts.picks ~= nil then o.picks = opts.picks end
    o.style = opts.style
    return Gear.Best(o)
end

local function sortedKeys(t, onlyTrue)
    local out = {}
    if type(t) ~= "table" then return "" end
    for k, v in pairs(t) do
        if not onlyTrue or v then out[#out + 1] = tostring(k) .. (onlyTrue and "" or ("=" .. tostring(v))) end
    end
    table.sort(out)
    return table.concat(out, ",")
end

local function capKey(cap)
    if type(cap) ~= "table" then return "" end
    local out = {}
    for row, c in pairs(cap) do
        out[#out + 1] = ("%s:%s:%s"):format(row, tostring(c.HIT and math.floor(c.HIT * 100 + 0.5)),
            tostring(c.SHIT and math.floor(c.SHIT * 100 + 0.5)))
    end
    table.sort(out)
    return table.concat(out, ",")
end

-- Everything a result depends on, as one string; st is the counter in it (default the stamp).
-- noOwn: without the own picks (Gear.Best does not read them)
local function optsKey(o, st, noOwn)
    local ex = o.exclude or {}
    return table.concat({ tostring(ns.Data("GEAR")), tostring(ns.BIS), st or stamp, tostring(o.class), tostring(o.spec), tostring(o.level),
        tostring(o.kind), tostring(o.faction), tostring(o.prof), sortedKeys(o.sources, true), sortedKeys(o.skills),
        sortedKeys(ex.item, true), sortedKeys(ex.boss, true), sortedKeys(ex.place, true), tostring(o.plan),
        tostring(o.suffix), tostring(o.sets), tostring(o.tie), tostring(o.picks), capKey(o.cap), noOwn and "" or sortedKeys(o.own),
        ns.PlayStyle and ns.PlayStyle.Key(o.style) or "" }, "|")
end

---------------------------------------------------------------------------
-- Ownership: worn (live), bags (scanned after bag changes), bank (while open, else the client's count)
---------------------------------------------------------------------------

local wornCache   -- { links = { [inv] = link }, ids = { [id] = inv } }, nil = read again
local function worn()
    if wornCache then return wornCache end
    local w = { links = {}, ids = {} }
    if GetInventoryItemLink then
        for _, sl in ipairs(Gear.SLOTS) do
            local link = ns.Plain(GetInventoryItemLink("player", sl.inv))
            if type(link) == "string" then
                w.links[sl.inv] = link
                local id = ns.ItemID(link)
                if id then w.ids[id] = sl.inv end
            end
        end
    end
    wornCache = w
    return w
end

local ownListeners = {}
-- fn() runs after the own items changed (worn, bags, bank).
function ns.BisOnOwned(fn) ownListeners[#ownListeners + 1] = fn end
local function ownedChanged()
    bump()
    for _, fn in ipairs(ownListeners) do
        local ok, err = pcall(fn)
        if not ok then ns.ReportError(err) end
    end
end

-- "worn", "bag", "bank" or nil.
function ns.BisOwned(item)
    local id = tonumber(item) or ns.ItemID(item)
    if not id then return nil end
    if worn().ids[id] then return "worn" end
    local c = ns.BisChar()
    if c and c.bag[id] then return "bag" end
    if c and c.bank[id] then return "bank" end
    -- without a bank visit: the client's count with the bank against the one without
    local count = C_Item and C_Item.GetItemCount
    if type(count) == "function" then
        local ok, inBags = pcall(count, id)
        local ok2, all = pcall(count, id, true)
        inBags, all = ok and ns.Plain(inBags), ok2 and ns.Plain(all)
        if type(all) == "number" and type(inBags) == "number" and all > inBags then return "bank" end
    end
    return nil
end

-- Kept are items of the data, wishes and anything wearable; no materials, no quest items.
local function keepId(id, c)
    if Gear.Item(id) or (c and c.wish[id]) then return true end
    local _, _, _, loc, _, classID = itemInstant(id)
    if type(loc) ~= "string" or loc == "" or not (classID == 2 or classID == 4) then return false end
    return Gear.GROUP[(loc:gsub("^INVTYPE_", ""))] ~= nil
end

local function readContainers(bags, c)
    local C = _G.C_Container
    local numSlots = type(C) == "table" and C.GetContainerNumSlots
    local itemID = type(C) == "table" and C.GetContainerItemID
    if type(numSlots) ~= "function" or type(itemID) ~= "function" then return nil end
    local out = {}
    for _, bag in ipairs(bags) do
        for slot = 1, tonumber(numSlots(bag)) or 0 do
            local id = itemID(bag, slot)
            if type(id) == "number" and keepId(id, c) then out[id] = true end
        end
    end
    return out
end

-- Stores the ids seen now (time of the sighting); what is gone falls away. True when the set changed.
local function applySeen(seen, set)
    local t, changed = time(), false
    for id in pairs(seen) do
        if not set[id] then seen[id] = nil; changed = true end
    end
    for id in pairs(set) do
        if not seen[id] then changed = true end
        seen[id] = t
    end
    return changed
end

local function bagList()
    local out = {}
    for b = 0, tonumber(_G.NUM_BAG_SLOTS) or 4 do out[#out + 1] = b end
    return out
end

local bagPending = false
local function scanBags()
    bagPending = false
    local c = ns.BisChar()
    local set = c and readContainers(bagList(), c)
    if set and applySeen(c.bag, set) then ownedChanged() end
end
ns.BisScanBags = scanBags

-- Bag events come in bursts: one scan a second at most.
local function scheduleBags()
    if bagPending then return end
    bagPending = true
    C_Timer.After(1, scanBags)
end

-- The bank's containers: the purchased tabs of the character bank (C_Bank; there is no bank -1).
function ns.BankTabs()
    local B = _G.C_Bank
    local kind = Enum and Enum.BankType and Enum.BankType.Character
    if type(B) ~= "table" or type(B.FetchPurchasedBankTabIDs) ~= "function" or kind == nil then return nil end
    local ok, tabs = pcall(B.FetchPurchasedBankTabIDs, kind)
    if not ok or type(tabs) ~= "table" then return nil end
    local out = {}
    for _, id in ipairs(tabs) do out[#out + 1] = id end
    return out
end

local bankOpen, bankPending = false, false
local function scanBank()
    bankPending = false
    if not bankOpen then return end
    local c = ns.BisChar()
    local list = c and ns.BankTabs()
    local set = list and readContainers(list, c)
    if not set then return end
    c.bankAt = time()
    if applySeen(c.bank, set) then ownedChanged() end
end
local function scheduleBank()
    if bankPending or not bankOpen then return end
    bankPending = true
    C_Timer.After(0.2, scanBank)
end

ns.OnEvent("BANKFRAME_OPENED", function() bankOpen = true; scanBank() end)
ns.OnEvent("BANKFRAME_CLOSED", function() bankOpen = false end)
ns.OnEvent("PLAYERBANKSLOTS_CHANGED", scheduleBank)
ns.OnEvent("BAG_UPDATE_DELAYED", function()
    scheduleBags()
    -- Forever's bank tabs are bags: their changes come as bag updates
    if bankOpen then scheduleBank() end
end)
-- The worn items are read anew at once; the listeners run once at the next frame (a gear set swap
-- fires one event per slot in the same frame).
local equipDue = false
ns.OnEvent("PLAYER_EQUIPMENT_CHANGED", function()
    wornCache = nil
    bump()
    if equipDue then return end
    equipDue = true
    C_Timer.After(0, function()
        equipDue = false
        ownedChanged()
    end)
end)
ns.OnEvent("PLAYER_ENTERING_WORLD", function()
    wornCache, bankOpen = nil, false
    bump()
    scheduleBags()
end)

---------------------------------------------------------------------------
-- Scoring one item against what is worn
---------------------------------------------------------------------------

local SLOT_OF = Gear.CAP_ROW
local KIND_OF = Gear.GROUP_PLACE
local SLOT_NAME = {}
local SLOT_INV = {}
local SECOND_ROW_OF = { FINGER1 = "FINGER2", TRINKET1 = "TRINKET2" }   -- the rows one group fills twice
for _, sl in ipairs(Gear.SLOTS) do SLOT_NAME[sl.key], SLOT_INV[sl.key] = sl.name, sl.inv end
ns.BIS_SLOT_NAME = SLOT_NAME

local function linkGroup(link)
    local _, _, _, loc = itemInstant(link)
    return type(loc) == "string" and Gear.GROUP[(loc:gsub("^INVTYPE_", ""))] or nil
end

-- Scores of what is worn, per slot, for one weighting: kept until the gear or the weighting changes.
local ctxCache, ctxKey
local function context(o)
    local key = table.concat({ tostring(ns.Data("GEAR")), stamp, tostring(o.class), tostring(o.spec), tostring(o.kind), tostring(o.level),
        capKey(o.cap) }, "|")
    if ctxKey == key then return ctxCache end
    local w = worn()
    local ctx, partial = { slot = {} }, false
    for _, sl in ipairs(Gear.SLOTS) do
        local link = w.links[sl.inv]
        local v = 0
        if link then
            v = Gear.ScoreLink(link, sl.key, o)
            if not v then v, partial = 0, true end
        end
        ctx.slot[sl.key] = v
    end
    local s = ctx.slot
    ctx.ring = math.min(s.FINGER1, s.FINGER2)
    ctx.trinket = math.min(s.TRINKET1, s.TRINKET2)
    ctx.twoWorn = w.links[16] and linkGroup(w.links[16]) == "2H" or false
    if not partial then ctxCache, ctxKey = ctx, key end
    return ctx
end

-- The hit cap: hit rating counts up to this much hit in percent against a target two levels
-- higher (Classic's 6 % for weapons and spells, to be confirmed in game).
local HIT_CAP, SPELL_HIT_CAP = 6, 6
local CR_HIT_MELEE, CR_HIT_SPELL = 6, 8
ns.BIS_HIT_CAP = HIT_CAP

local function plainNumber(f, ...)
    if type(f) ~= "function" then return nil end
    local ok, v = pcall(f, ...)
    v = ok and tonumber(ns.Plain(v)) or nil
    return v
end

-- The own hit in percent from the character sheet: melee/ranged and spell; nil where the client
-- has no API for it.
function ns.BisOwnHit()
    local melee = plainNumber(GetCombatRatingBonus, CR_HIT_MELEE)
    local spell = plainNumber(GetCombatRatingBonus, CR_HIT_SPELL)
    if melee then melee = melee + (plainNumber(GetHitModifier) or 0) end
    if spell then spell = spell + (plainNumber(GetSpellHitModifier) or 0) end
    return melee, spell
end

local capCache, capKeyOf
-- The hit still useful per row (bis.hitCap): the cap minus the own hit without the item worn in
-- that row, { [row] = { HIT = %, SHIT = % } }; nil when the switch is off or the client cannot say
-- (hit then counts without a cap).
function ns.BisHitCaps(o)
    if not ns.Get("bis.hitCap") then return nil end   -- l10n-ok: setting key
    local melee, spell = ns.BisOwnHit()
    if not melee and not spell then return nil end
    local w = worn()
    local key = table.concat({ tostring(w), tostring(o.level), tostring(melee), tostring(spell) }, "|")
    if capKeyOf == key then return capCache end
    local caps = {}
    for _, sl in ipairs(Gear.SLOTS) do
        local link = w.links[sl.inv]
        local s = link and Gear.ReadStats(link) or {}
        -- worn hit converted as Gear.lua's terms do: generic hit at the melee rate for the melee
        -- side and at the spell rate for the spell side
        local m = ((s.HIT or 0) + (s.MHIT or 0)) * Gear.RatingPerPoint("HIT", o.level)
        local sp = ((s.HIT or 0) + (s.SHIT or 0)) * Gear.RatingPerPoint("SHIT", o.level)
        caps[sl.key] = { HIT = melee and math.max(0, HIT_CAP - (melee - m)) or nil,
            SHIT = spell and math.max(0, SPELL_HIT_CAP - (spell - sp)) or nil }
    end
    capCache, capKeyOf = caps, key
    return caps
end

-- The worn scores per slot for the options, as a copy: { slot = { [slotKey] = score }, two = a
-- two-hander is worn }. The dungeon chain equips items on it virtually.
function ns.BisWornScores(o)
    local ctx = context(o or ns.BisOpts())
    local slot = {}
    for k, v in pairs(ctx.slot) do slot[k] = v end
    return { slot = slot, two = ctx.twoWorn }
end

-- The least change of the whole output (percent) that counts as an upgrade (bis.minTotal, D-54).
local function minTotal() return tonumber(ns.Get("bis.minTotal")) or 0.3 end   -- l10n-ok: setting key
local function isUpTotal(total) return type(total) == "number" and total > 0.05 and total >= minTotal() - 1e-9 end

local ownSize   -- defined with the model below

-- Whether a gain (score points of the own spec) is worth calling an upgrade: at least bis.minTotal
-- percent of the spec's whole output (Gear/Model.lua); without the model more than a point and two
-- percent of the worn item's score.
function ns.BisIsUpgrade(gain, mine)
    if type(gain) ~= "number" then return false end
    local size = ownSize and ownSize()
    if size and size > 0 then return isUpTotal(gain / size * 100) end
    return gain > math.max(1, math.abs(mine or 0) * 2 / 100)
end

-- The weaker of two rows (the first on a tie).
local function weakerOf(ctx, a, b)
    return (ctx.slot[a] or 0) <= (ctx.slot[b] or 0) and a or b
end

-- gain, mine, switch, against for an item of a group scored score, in the row slotKey; against
-- lists the rows compared with (the weaker ring or trinket, both hands for a two-hander).
local function gainFor(slotKey, group, id, score, ctx)
    local mine, against
    if slotKey == "FINGER1" or slotKey == "FINGER2" then
        mine, against = ctx.ring, { weakerOf(ctx, "FINGER1", "FINGER2") }
    elseif slotKey == "TRINKET1" or slotKey == "TRINKET2" then
        mine, against = ctx.trinket, { weakerOf(ctx, "TRINKET1", "TRINKET2") }
    elseif slotKey == "MAINHAND" then
        if group == "2H" then
            mine, against = ctx.slot.MAINHAND + ctx.slot.OFFHAND, { "MAINHAND", "OFFHAND" }
        elseif ctx.twoWorn then
            return nil, ctx.slot.MAINHAND, true, { "MAINHAND" }
        else
            mine, against = ctx.slot.MAINHAND, { "MAINHAND" }
        end
    elseif slotKey == "OFFHAND" then
        if ctx.twoWorn then return nil, ctx.slot.MAINHAND, true, { "MAINHAND" } end
        mine, against = ctx.slot.OFFHAND, { "OFFHAND" }
    else
        mine, against = ctx.slot[slotKey] or 0, { slotKey }
    end
    if id and worn().ids[id] then return 0, mine, false, against end
    return score - mine, mine, false, against
end

local function rowType(id)
    local row = Gear.Item(id)
    if row and row[1] ~= "" then return row[1], row[2], row[3], row end
    local _, _, _, loc, _, classID, sub = itemInstant(id)
    if type(loc) ~= "string" or loc == "" then return nil end
    return (loc:gsub("^INVTYPE_", "")), classID, sub, row
end

-- The slot group of an item ("HEAD", "FINGER", "2H", "1H", "SHIELD", ...), or nil when it is no gear.
function ns.BisGroup(id)
    local loc = rowType(id)
    return loc and Gear.GROUP[loc] or nil
end

---------------------------------------------------------------------------
-- Own picks (F-112, D-55): per spec and row the item the player chose as the row's target. It
-- takes option 1 of its row wherever a target is used and beats a BiS pick; the tooltip's
-- "Upgrade für dich" still compares the score with what is worn. Amisia never changes a pick by
-- itself and never sends one.
---------------------------------------------------------------------------

-- the groups a row takes (an armour row: its own group)
local PICK_FIT = { MAINHAND = { ["2H"] = true, ["1H"] = true, MH = true }, OFFHAND = { ["1H"] = true, OHW = true, SHIELD = true, HELD = true },
    FINGER1 = { FINGER = true }, FINGER2 = { FINGER = true }, TRINKET1 = { TRINKET = true }, TRINKET2 = { TRINKET = true },
    RANGED = { RANGED = true } }
local PICK_TWIN = { FINGER1 = "FINGER2", FINGER2 = "FINGER1", TRINKET1 = "TRINKET2", TRINKET2 = "TRINKET1" }

-- Whether an item may be the own pick of a row for the options: true, or nil, the reason (German)
-- and a code ("slot", "noitem", "notgear", "class"). An item the data does not list counts by the
-- client's item type.
local function pickFits(slotKey, id, o)
    if not PICK_SLOT[slotKey] then return nil, L["Unbekannter Slot."], "slot" end
    local loc, classID, sub, row = rowType(id)
    if not loc then return nil, L["Kein Item."], "noitem" end
    local group = Gear.GROUP[loc]
    if not group or not (classID == 2 or classID == 4) then return nil, L["Keine Ausrüstung."], "notgear" end
    local fit = PICK_FIT[slotKey] or { [slotKey] = true }
    if not fit[group] then return nil, L["Passt nicht in %s."]:format(SLOT_NAME[slotKey] or slotKey), "slot" end
    local cannot = L["Das kann dein Charakter nicht tragen."]
    if not o.class or not Gear.Usable(o.class, { loc, classID, sub or 0 }, o.level, o.spec) then return nil, cannot, "class" end
    if row and (row[8] or 0) > 0 and not Gear.HasClassBit(row[8], o.class) then return nil, cannot, "class" end
    if slotKey == "OFFHAND" and group == "1H" and not Gear.CanDualWield(o.class, o.level, o.spec) then return nil, cannot, "class" end
    return true
end

-- The own picks the options use: those that fit their row and the weapon plan (a two-hander in
-- the weapon hand only with "auto" or "2H", and the shield hand then has none; a one-hander not
-- with "2H"; an off-hand weapon not with "SHIELD", a shield or held item not with "DW").
ownPicks = function(c, o)
    local stored = c and type(c.pick) == "table" and o.spec and c.pick[o.spec]
    if type(stored) ~= "table" or not next(stored) or not Gear.Available() then return nil, nil end
    local used, unused = {}, {}
    for slotKey, id in pairs(stored) do
        local ok, _, code = pickFits(slotKey, id, o)
        if ok then used[slotKey] = id else unused[slotKey] = code end
    end
    local plan = o.plan or "auto"
    local mh = used.MAINHAND and ns.BisGroup(used.MAINHAND)
    local oh = used.OFFHAND and ns.BisGroup(used.OFFHAND)
    local function drop(k) used[k], unused[k] = nil, "plan" end
    if (mh == "2H" and plan ~= "auto" and plan ~= "2H") or (mh and mh ~= "2H" and plan == "2H") then
        drop("MAINHAND")
        mh = nil
    end
    if oh then
        local weapon = oh == "1H" or oh == "OHW"
        if plan == "2H" or mh == "2H" or (weapon and plan == "SHIELD") or (not weapon and plan == "DW") then drop("OFFHAND") end
    end
    return next(used) and used or nil, next(unused) and unused or nil
end

-- The own pick of a row for a spec (default the one in use), also one the options do not use; nil
-- without.
function ns.BisPick(slotKey, spec)
    local c = ns.BisChar()
    spec = spec or ns.BisSpec()
    local t = c and type(c.pick) == "table" and spec and c.pick[spec]
    return type(t) == "table" and t[slotKey] or nil
end

-- Makes item (an id, a link or a number as text) the own pick of a row for the spec in use; nil
-- lifts it. true, or nil and the reason (German): the item must fit the row and the character
-- must be able to wear it. A ring or trinket is the pick of one of its two rows only.
function ns.BisSetPick(slotKey, item)
    local c = ns.BisChar()
    if not c then return nil, L["Amisia ist noch nicht geladen."] end
    if not PICK_SLOT[slotKey] then return nil, L["Unbekannter Slot."] end
    local spec = ns.BisSpec()
    if not spec then return nil, L["Keine Gewichtung."] end
    if item == nil then
        local t = type(c.pick) == "table" and c.pick[spec]
        if t and t[slotKey] then
            t[slotKey] = nil
            if not next(t) then c.pick[spec] = nil end
            if not next(c.pick) then c.pick = nil end
            ns.Fire("BIS_CHANGED", "pick")
        end
        return true
    end
    local id = type(item) == "number" and item or ns.ItemID(item)
    if not id and type(item) == "string" then id = tonumber(item:match("^%s*(%d+)%s*$")) end
    if not id or id <= 0 or id % 1 ~= 0 then return nil, L["Kein Item."] end
    local _, class = UnitClass("player")
    local ok, why = pickFits(slotKey, id, { class = class, spec = spec,
        level = math.max(1, math.min(tonumber(UnitLevel("player")) or 1, Gear.Cap())) })
    if not ok then return nil, why end
    c.pick = type(c.pick) == "table" and c.pick or {}
    c.pick[spec] = type(c.pick[spec]) == "table" and c.pick[spec] or {}
    local t = c.pick[spec]
    local twin = PICK_TWIN[slotKey]
    if twin and t[twin] == id then t[twin] = nil end
    t[slotKey] = id
    ns.Fire("BIS_CHANGED", "pick")
    return true
end

-- The ids of the own picks the options use, as a set (empty without).
function ns.BisOwnPickSet(o)
    local out = {}
    for _, id in pairs((o or ns.BisOpts()).own or {}) do out[id] = true end
    return out
end

-- Whether an item is an own pick of its rows, and whether an own pick other than it is worn in a
-- row it is compared against (then nothing else is an upgrade there, as with a worn BiS pick).
local function ownState(o, id, slotKey, against)
    local own = o.own
    if type(own) ~= "table" then return false, false end
    local second = SECOND_ROW_OF[slotKey]
    local mine = own[slotKey] == id or (second ~= nil and own[second] == id) or (slotKey == "MAINHAND" and own.OFFHAND == id)
    -- suppressed only where an own pick is worn in the compared slot itself, whichever ring or
    -- trinket row it was stored for
    local links, ownWorn = worn().links, false
    local picked = {}
    for _, p in pairs(own) do picked[p] = true end
    for _, key in ipairs(against or {}) do
        local wid = ns.ItemID(links[SLOT_INV[key]])
        if wid and wid ~= id and picked[wid] then ownWorn = true end
    end
    return mine and true or false, ownWorn
end

-- BiS picks for the own character (Gear.PicksFor with the options' plan and exclusions; none with
-- o.picks == false): the pick an item is in its rows (slotKey, and the second ring or trinket row),
-- and whether a pick other than the item is worn in a row it is compared against. A pick is the
-- slot's target: the pick itself counts as an upgrade until it is worn, and while a pick is worn
-- nothing else is an upgrade for that row (gain at most 0).
local SECOND_ROW = { FINGER1 = "FINGER2", TRINKET1 = "TRINKET2" }

-- The line of a pick for explanations and tooltips: "BiS-Empfehlung: <note> (<source>)".
function ns.BisPickText(p)
    if type(p) ~= "table" then return nil end
    local note = type(p.note) == "string" and p.note ~= "" and (": " .. p.note) or ""
    local src = type(p.src) == "string" and p.src ~= "" and (" (" .. p.src .. ")") or ""
    return L["BiS-Empfehlung"] .. note .. src
end
local function pickState(o, id, slotKey, against)
    if o.picks == false or not o.class then return nil, false end
    local picks = Gear.PicksFor(o.class, o.spec, o.level, o.plan, o.exclude)
    if not next(picks) then return nil, false end
    local pick
    for _, key in ipairs({ slotKey, SECOND_ROW[slotKey] }) do
        if picks[key] and picks[key].item == id then pick = picks[key] end
    end
    local wornIds = worn().ids
    local pickWorn = false
    for _, key in ipairs(against or {}) do
        local p = picks[key]
        if p and p.item ~= id and wornIds[p.item] then pickWorn = true end
    end
    return pick, pickWorn
end

-- Everything about one item for the own character: { id, s, w, kind, group, slotKey, score, gain,
-- mine, switch, pick, pickWorn } or { reason, code }.
local function evaluate(item, o)
    if not Gear.Available() then return { reason = L["Für diesen Client gibt es keine Ausrüstungsdaten."], code = "nodata" } end
    local id = tonumber(item) or ns.ItemID(item)
    if not id then return { reason = L["Kein Item."], code = "noitem" } end
    o = o or ns.BisOpts()
    local loc, classID, sub, row = rowType(id)
    local group = loc and Gear.GROUP[loc]
    if not group or not (classID == 2 or classID == 4) then return { id = id, reason = L["Keine Ausrüstung."], code = "notgear" } end
    local cannot = { id = id, reason = L["Das kann dein Charakter nicht tragen."], code = "class" }
    if not o.class or not Gear.Usable(o.class, { loc, classID, sub or 0 }, o.level, o.spec) then return cannot end
    if row and (row[8] or 0) > 0 and not Gear.HasClassBit(row[8], o.class) then return cannot end
    local s
    if type(item) == "string" and item:find("item:", 1, true) then s = Gear.ReadStats(item) end
    if not s then
        local failed
        s, failed = Gear.Stats(id)
        if not s then return { id = id, reason = L["Werte fehlen noch."], code = failed and "nostats" or "loading" } end
    end
    if s.CLASSES and not s.CLASSES[o.class] then return cannot end
    local w = Gear.Weights(o.class, o.spec, o.kind, o.level)
    if not w then return { id = id, reason = L["Keine Gewichtung."], code = "noweights" } end
    local kind = KIND_OF[group]
    local slotKey = SLOT_OF[group]
    local cap = o.cap and o.cap[Gear.CAP_ROW[group] or slotKey]
    local score = Gear.Score(s, w, o.level, kind, o.class, cap)
    local gain, mine, switch, against = gainFor(slotKey, group, id, score, context(o))
    local pick, pickWorn = pickState(o, id, slotKey, against)
    local own, ownWorn = ownState(o, id, slotKey, against)
    return { id = id, s = s, w = w, kind = kind, group = group, slotKey = slotKey, score = score, gain = gain, mine = mine,
        switch = switch, row = row, against = against, cap = cap, pick = pick, pickWorn = pickWorn, own = own, ownWorn = ownWorn }
end

-- What an item (id or link; a link counts its random suffix) brings the own character:
-- gain, slotKey, mine, score; or nil, reason (German), code ("switch" with the slot as 4th value,
-- "nodata", "noitem", "notgear", "class", "loading", "nostats", "noweights").
function ns.BisGain(item, opts)
    local ev = evaluate(item, opts)
    if ev.reason then return nil, ev.reason, ev.code end
    if ev.switch then return nil, L["Waffenwechsel"], "switch", ev.slotKey end
    -- a worn BiS pick or own pick is the row's target: nothing else is an upgrade there
    if ev.pickWorn or ev.ownWorn then return math.min(ev.gain, 0), ev.slotKey, ev.mine, ev.score end
    return ev.gain, ev.slotKey, ev.mine, ev.score
end

---------------------------------------------------------------------------
-- The model: the change in percent of the spec's whole output (Gear/Model.lua, D-54)
---------------------------------------------------------------------------

local ROLE_WORD = { dps = L["Schaden"], heal = L["Heilung"], tank = L["Überleben"] }

-- The own state per spec, kept until the gear, the level, the sheet or the options change:
-- { p, st, approx, worn (Model.WornItems), w (the bracket's weights), size }.
local ownCache = {}
local function ownKey(o)
    return table.concat({ tostring(worn()), tostring(o.level), ns.Model.SheetCount(), tostring(o.plan), tostring(o.kind),
        tostring(ns.Data("GEAR")) }, "|")
end
local function ownOf(o, specKey)
    local Model = ns.Model
    if not (Model and Model.Available()) or not o.class or not specKey then return nil end
    local p = Model.Params(o.class, specKey)
    if not p then return nil end
    Model.Sheet()   -- reads the sheet when it is due (and bumps the stamp then)
    local key = ownKey(o)
    local c = ownCache[specKey]
    if c and c.key == key then return c end
    local st, approx = Model.OwnState(o.class, specKey, p, o.plan)
    if not st then return nil end
    local wornNow, partial = Model.WornItems()
    c = { key = ownKey(o), p = p, st = st, approx = approx, worn = wornNow,
        w = Gear.Weights(o.class, specKey, o.kind, o.level) }
    c.size = Model.Change(o.class, p, o.kind, st, {}, {}, c.w).size
    -- a worn item without stats yet would count as an empty slot: asked again next time
    if not partial then ownCache[specKey] = c end
    return c
end

local sizeStamp, sizeValue
ownSize = function()
    if sizeStamp == stamp then return sizeValue end
    local ok, o = pcall(ns.BisOpts)
    local c = ok and o and ownOf(o, o.spec)
    sizeStamp, sizeValue = stamp, c and c.size or nil
    return sizeValue
end

-- Set bonuses an exchange breaks and completes: two lists of { stats } (bonuses without stats are
-- not counted).
local function setSwap(outIds, inId)
    local before = {}
    for id in pairs(worn().ids) do
        local sid = Gear.SetOf(id)
        if sid then before[sid] = (before[sid] or 0) + 1 end
    end
    local after = {}
    for sid, n in pairs(before) do after[sid] = n end
    for _, id in ipairs(outIds) do
        local sid = Gear.SetOf(id)
        if sid then after[sid] = (after[sid] or 0) - 1 end
    end
    local sid = inId and Gear.SetOf(inId)
    if sid then after[sid] = (after[sid] or 0) + 1 end
    local lost, won = {}, {}
    for set, n1 in pairs(after) do
        local n0 = before[set] or 0
        if n1 ~= n0 then
            for thr, stats in pairs(Gear.SetBonusesOf(set)) do
                if stats then
                    if n0 >= thr and n1 < thr then lost[#lost + 1] = { stats }
                    elseif n1 >= thr and n0 < thr then won[#won + 1] = { stats } end
                end
            end
        end
    end
    return lost, won
end

-- The model's change for an evaluated item in spec specKey: Model.Change's result and the own
-- state (ownOf), or nil.
local function modelChange(ev, o, specKey)
    local c = ownOf(o, specKey)
    if not c then return nil end
    if worn().ids[ev.id] then
        return { total = 0, main = 0, surv = c.p.model ~= "tank" and 0 or nil, threat = c.p.model == "tank" and 0 or nil,
            gain = 0, size = c.size, after = c.st }, c
    end
    local outItems, outIds = {}, {}
    for _, key in ipairs(ev.against or {}) do
        local it = c.worn[SLOT_INV[key]]
        if it then
            outItems[#outItems + 1] = { it[1], it[2] }
            local id = ns.ItemID(it[3])
            if id then outIds[#outIds + 1] = id end
        end
    end
    local inItems = { { ev.s, ev.kind } }
    local lost, won = setSwap(outIds, ev.id)
    for _, b in ipairs(lost) do outItems[#outItems + 1] = b end
    for _, b in ipairs(won) do inItems[#inItems + 1] = b end
    return ns.Model.Change(o.class, c.p, o.kind, c.st, outItems, inItems, c.w), c
end

-- What it brings when the stats outS leave a worn item and inS come (an enchantment, F-128): the
-- model's change in percent of the whole output (nil without the model) and the change of the
-- weighted score (for the order without the model). place: "2H", "MH", "OH", "RANGED" or nil, where
-- weapon damage goes.
function ns.BisStatsChange(outS, inS, place, opts)
    local o = opts or ns.BisOpts()
    local w = o.class and Gear.Weights(o.class, o.spec, o.kind, o.level)
    local score
    if w then
        score = Gear.Score(inS, w, o.level, place, o.class) - Gear.Score(outS, w, o.level, place, o.class)
    end
    local c = ownOf(o, o.spec)
    if not c then return nil, score end
    local mc = ns.Model.Change(o.class, c.p, o.kind, c.st, { { outS, place } }, { { inS, place } }, c.w)
    return mc and mc.total, score
end

-- "+1,6 %", "-0,4 %", "+12 %" (whole numbers from 10 on).
local function pctText(x)
    local a = math.abs(x)
    return (x < 0 and "-" or "+") .. Gear.Num(a, a < 10 and 1 or 0) .. " %"
end
ns.UpgradePct = pctText

-- The percent of an upgrade as shown everywhere: { total } (the whole output), else { pct } (the
-- slot's score, an answer of an older Amisia: alt), 999 or nothing: "neu".
function ns.UpgradePctText(e)
    if type(e) ~= "table" then return L["neu"] end
    if type(e.total) == "number" then return pctText(e.total) end
    if type(e.pct) ~= "number" or e.pct == 999 then return L["neu"] end
    return ("%+d %%"):format(e.pct) .. (e.alt and L[" (alt)"] or "")
end
-- The order of such entries: whole-output percents first, then old slot percents.
function ns.UpgradeSortValue(e)
    if type(e.total) == "number" then return e.total end
    if e.pct == 999 then return 1e6 end
    return -1e6 + (tonumber(e.pct) or 0)
end

-- The spec of an upgrade as the tooltip names it: "Verstärkung" or "Verstärkung, geraten".
local function specText(u)
    local sp = Gear.SpecInfo(u.class, u.spec)
    local name = sp and L[sp.name] or tostring(u.spec)
    return u.guessed and L["%s, geraten"]:format(name) or name
end

-- The level an item needs when it is above the own one (C_Item.GetItemInfo, fifth value), else nil.
local function laterLevel(item)
    local info = C_Item and C_Item.GetItemInfo
    if type(info) ~= "function" then return nil end
    local ok, _, _, _, _, minLevel = pcall(info, item)
    minLevel = ok and tonumber(ns.Plain(minLevel)) or nil
    local level = tonumber(ns.Plain(UnitLevel("player")))
    if minLevel and level and minLevel > level then return minLevel end
    return nil
end

-- The one comparison with the worn gear every display uses (tooltip, roll frames, quest rewards,
-- the roll window, the answers to "Wer braucht das?"): { gain, pct, mine, score, slotKey, up,
-- against = { worn links }, weaker, later } or nil, reason (German), code as ns.BisGain ("switch"
-- with the slot as 4th value). pct is the gain in percent of the worn score, nil for an empty slot;
-- weaker says a ring or trinket is compared with the weaker of the two worn; later is the level the
-- item needs when it is above the own (then it is no upgrade yet); pick is the BiS pick when the item
-- is one (then it is an upgrade until worn), pickWorn says a pick is worn in the compared row (then
-- nothing else is an upgrade there).
function ns.UpgradeOf(item, opts)
    local o = opts or ns.BisOpts()
    local ev = evaluate(item, o)
    if ev.reason then return nil, ev.reason, ev.code end
    if ev.switch then return nil, L["Waffenwechsel"], "switch", ev.slotKey end
    local mine = ev.mine or 0
    local u = { gain = ev.gain, mine = mine, score = ev.score, slotKey = ev.slotKey, against = {},
        weaker = (ev.group == "FINGER" or ev.group == "TRINKET") or nil, class = o.class, spec = o.spec,
        guessed = o.guessed or nil }
    if mine > 0 then u.pct = math.floor(ev.gain / mine * 100 + 0.5) end
    local mc, own = modelChange(ev, o, o.spec)
    if mc then
        u.total, u.main, u.surv, u.threat, u.approx = mc.total, mc.main, mc.surv, mc.threat, own.approx or nil
        local sp = Gear.SpecInfo(o.class, o.spec)
        u.role = sp and sp.role or nil
    end
    local w = worn()
    for _, key in ipairs(ev.against or {}) do
        local link = w.links[SLOT_INV[key]]
        if link then u.against[#u.against + 1] = link end
    end
    u.later = laterLevel(type(item) == "string" and item or ev.id)
    u.pick, u.pickWorn = ev.pick, ev.pickWorn or nil
    -- better: the comparison alone (a pick counts as better until worn); up: and wearable now
    if u.total then u.better = isUpTotal(u.total) else u.better = ns.BisIsUpgrade(ev.gain, mine) end
    u.better = (not ev.pickWorn and (ev.pick ~= nil or u.better)) and true or false
    u.up = (u.better and not u.later and not w.ids[ev.id]) and true or false
    return u
end

-- The same item for the other specs of the own class: { { name, total }, ... } in the weights' order.
function ns.UpgradeOthers(item, opts)
    local o = opts or ns.BisOpts()
    local ev = evaluate(item, o)
    if ev.reason or ev.switch then return {} end
    local out = {}
    for _, sp in ipairs(Gear.Specs(o.class)) do
        if sp.key ~= o.spec then
            local mc = modelChange(ev, o, sp.key)
            if mc then out[#out + 1] = { name = L[sp.name], total = mc.total } end
        end
    end
    return out
end

-- The short text of a comparison for an item mark: "+12%", "neu" (an empty slot), "ab 62" (a level
-- above the own) or "-8%"; nil when there is nothing to say.
function ns.UpgradeShort(u)
    if type(u) ~= "table" or type(u.gain) ~= "number" then return nil end
    if u.later then return u.gain > 0 and L["ab %d"]:format(u.later) or nil end
    if u.total then return (pctText(u.total):gsub(" %%$", "%%")) end
    if u.pct then return ("%+d%%"):format(u.pct) end
    if u.up then return L["neu"] end
    return nil
end

-- The model's answer for an item on the own values (D-54): "Gesamt: +1,6 % Schaden (deine Werte vom
-- Charakterbogen)", then the main values with what the exchange moves ("Angriffskraft: 300 -> 310");
-- {} without the model.
function ns.BisExplainModel(item, opts)
    local o = opts or ns.BisOpts()
    -- the sheet is the own character's: not for the simulation of another class or level
    local own = ns.BisOpts()
    if o.class ~= own.class or o.level ~= own.level then return {} end
    local ev = evaluate(item, o)
    if ev.reason or ev.switch then return {} end
    local mc, c = modelChange(ev, o, o.spec)
    if not mc then return {} end
    local sp = Gear.SpecInfo(o.class, o.spec)
    local role = ROLE_WORD[sp and sp.role] or L["Schaden"]
    local lines = { (c.approx and L["Gesamt: %s %s (ungefähr, Grundwerte und Ausrüstung)"]
        or L["Gesamt: %s %s (deine Werte vom Charakterbogen)"]):format(pctText(mc.total), role) }
    for _, v in ipairs(ns.Model.Values(o.class, c.p, c.st, mc.after)) do lines[#lines + 1] = ("%s: %s"):format(v[1], v[2]) end
    return lines
end

-- The score of an item explained as German lines: what it scores against what is worn, then every
-- part ("30 Stärke x 2,0 = 60").
function ns.BisExplain(item, opts)
    local o = opts or ns.BisOpts()
    local ev = evaluate(item, o)
    if ev.reason then return { ev.reason } end
    local sp = Gear.SpecInfo(o.class, o.spec)
    local who = (sp and L[sp.name] or tostring(o.spec)) .. (o.guessed and L[" (geraten)"] or "")
    local lines = {}
    if ev.switch then
        lines[1] = L["%s · %s: Wertung %s, Waffenwechsel gegen die Zweihandwaffe (%s)"]:format(who, SLOT_NAME[ev.slotKey],
            Gear.Num(ev.score), Gear.Num(ev.mine or 0))
    else
        lines[1] = L["%s · %s: Wertung %s, angelegt %s, %s"]:format(who, SLOT_NAME[ev.slotKey], Gear.Num(ev.score),
            Gear.Num(ev.mine or 0), Gear.UnitText(ev.gain, ev.w))
    end
    for _, p in ipairs(Gear.ScoreParts(ev.s, ev.w, o.level, ev.kind, o.class, ev.cap)) do
        lines[#lines + 1] = Gear.PartText(p)
    end
    if ev.s.SC then lines[#lines + 1] = L["Werte berechnet (noch nicht gescannt)"] end
    local fx = Gear.EffectText(ev.id)
    if fx then lines[#lines + 1] = L["Effekt nicht gewertet: %s"]:format(fx) end
    if ev.pick then lines[#lines + 1] = ns.BisPickText(ev.pick) end
    if (ev.s.HIT or ev.s.MHIT or ev.s.SHIT) and not ev.cap then lines[#lines + 1] = L["Trefferwertung zählt ohne Obergrenze"] end
    return lines
end

-- The parts of a score by key (the stats of an item for the options), and the evaluation. item is
-- an id, a link or an option of ns.BisTargets / Gear.Best ({ id = ..., suffix = ..., setb = ... }
-- or { id, score, suffix = ..., setb = ... }): an option counts the random suffix and the share of
-- the set bonus its ranking counted.
local function partsOf(item, o)
    local opt = type(item) == "table" and item or nil
    local ev = evaluate(opt and (opt.id or opt[1]) or item, o)
    if ev.reason then return nil, ev end
    if opt and (opt.suffix or opt.setb) then
        local s = ev.s
        local variants = opt.suffix and Gear.SuffixStats(ev.id)
        if variants and variants[opt.suffix] then s = variants[opt.suffix] end
        if opt.setb then
            local c = {}
            for k, v in pairs(s) do c[k] = v end
            c.SETB = opt.setb
            s = c
        end
        ev.s = s
        ev.score = Gear.Score(s, ev.w, o.level, ev.kind, o.class, ev.cap)
    end
    local by = {}
    for _, p in ipairs(Gear.ScoreParts(ev.s, ev.w, o.level, ev.kind, o.class, ev.cap)) do
        if not p.over then by[p.key] = p end
    end
    return by, ev
end

-- a against b (ids, links or options of ns.BisTargets, see partsOf): { lines = { "+24 Stärke
-- (+48)", ... } largest first, diff = score of a minus b, text = "Option 1 liegt 21 vorn, vor allem
-- durch Stärke." } or nil, reason. names (optional): { "Option 1", "Option 2" } for the sentence.
function ns.BisCompare(a, b, opts, names)
    local o = opts or ns.BisOpts()
    local pa, ea = partsOf(a, o)
    if not pa then return nil, ea.reason end
    local pb, eb = partsOf(b, o)
    if not pb then return nil, eb.reason end
    local rows = {}
    local keys = {}
    for k in pairs(pa) do keys[k] = true end
    for k in pairs(pb) do keys[k] = true end
    for k in pairs(keys) do
        local x, y = pa[k], pb[k]
        local dp = (x and x.points or 0) - (y and y.points or 0)
        if math.abs(dp) >= 0.5 then
            local p = x or y
            local amount
            if k == "SPEED" then
                amount = ("%s s"):format(Gear.Num(((x and x.value) or 0) - ((y and y.value) or 0), 1))
            elseif p.amount and p.amount:find("%%") then
                -- a rating part: its percent is points / weight
                local function pct(q) return (q and q.weight ~= 0) and q.points / q.weight or 0 end
                local d = pct(x) - pct(y)
                amount = ("%s%s %%"):format(d >= 0 and "+" or "", Gear.Num(d, 1))
            else
                local d = ((x and x.value) or 0) - ((y and y.value) or 0)
                amount = ("%s%s"):format(d >= 0 and "+" or "", Gear.Num(d))
            end
            rows[#rows + 1] = { key = k, points = dp, text = ("%s %s (%+d)"):format(amount, p.label, math.floor(dp + 0.5)) }
        end
    end
    table.sort(rows, function(r1, r2)
        if math.abs(r1.points) ~= math.abs(r2.points) then return math.abs(r1.points) > math.abs(r2.points) end
        return r1.key < r2.key
    end)
    local lines = {}
    for _, r in ipairs(rows) do lines[#lines + 1] = r.text end
    local diff = ea.score - eb.score
    local na, nb = (names and names[1]) or L["Das erste"], (names and names[2]) or L["das zweite"]
    local lead = rows[1]
    for _, r in ipairs(rows) do
        if (diff >= 0) == (r.points >= 0) then lead = r break end
    end
    local text
    if math.abs(diff) < 0.5 then
        text = L["%s und %s liegen gleichauf."]:format(na, nb)
    elseif diff > 0 then
        text = L["%s liegt %d vorn%s."]:format(na, math.floor(diff + 0.5),
            lead and L[", vor allem durch %s"]:format((pa[lead.key] or pb[lead.key]).label) or "")
    else
        text = L["%s liegt %d vorn%s."]:format(nb:gsub("^%l", string.upper), math.floor(-diff + 0.5),
            lead and L[", vor allem durch %s"]:format((pb[lead.key] or pa[lead.key]).label) or "")
    end
    return { lines = lines, diff = diff, text = text }
end

-- Why the weights are as they are: the spec's reason, its unit and the reference character of the
-- bracket ("Bezug Level 30: 410 Angriffskraft, 22 Waffen-DPS, 14 % Krit").
local REF_LABEL = { AP = L["Angriffskraft"], wDPS = L["Waffen-DPS"], crit = L["% Krit"], SP = L["Zauberschaden"],
    HEAL = L["Heilung"], mana = "Mana", HP = L["Gesundheit"], armor = L["Rüstung"], avoid = L["% Vermeidung"],
    spell = L["Grundschaden des Bezugszaubers"] }
local REF_ORDER = { "AP", "SP", "HEAL", "HP", "wDPS", "crit", "mana", "armor", "avoid", "spell" }
function ns.BisWhy(o)
    o = o or ns.BisOpts()
    local sp = Gear.SpecInfo(o.class, o.spec)
    if not sp then return {} end
    local lines = {}
    if sp.why then lines[#lines + 1] = L[sp.why] end
    local w = Gear.Weights(o.class, o.spec, o.kind, o.level)
    local unit = Gear.Unit(w)
    if unit then lines[#lines + 1] = L["Ein Punkt Wertung ist so viel wert wie 1 %s."]:format(Gear.UNIT_LABELS[unit]) end
    local brackets = ns.GEAR_WEIGHTS and ns.GEAR_WEIGHTS.brackets or {}
    local idx
    for i, upper in ipairs(brackets) do
        if o.level <= upper then idx = i break end
    end
    local ref = type(sp.ref) == "table" and sp.ref[idx or #brackets]
    if type(ref) == "table" then
        local parts = {}
        for _, k in ipairs(REF_ORDER) do
            local v = tonumber(ref[k])
            if v then parts[#parts + 1] = ("%s %s"):format(Gear.Num(v), REF_LABEL[k]) end
        end
        lines[#lines + 1] = L["Bezug Level %d: %s"]:format(brackets[idx or #brackets] or o.level, table.concat(parts, ", "))
    end
    return lines
end

---------------------------------------------------------------------------
-- Targets: the best three per slot
---------------------------------------------------------------------------

local function emptyResult()
    local r = { plan = "1H", missing = 0, total = 0, upgrades = 0, mine = {}, state = {} }
    for _, sl in ipairs(Gear.SLOTS) do r[sl.key] = {} end
    return r
end

local function wishOf(c, id) return c and c.wish[id] ~= nil or false end

-- An option for an own pick: the entry of the slot's ranking when it is there (with its random
-- suffix and set share), else scored now as Gear.Best scores a row (the best seen suffix; an item
-- the data does not list counts with the client's stats, unknown = true); loading while the client
-- has no stats yet.
local function ownEntry(slotKey, id, o, list)
    for _, e in ipairs(list or {}) do
        if e[1] == id then
            local copy = Gear.Copy(e)
            copy.own, copy.pick = true, nil
            return copy
        end
    end
    local group = ns.BisGroup(id)
    local e = { id, 0, own = true, unknown = Gear.Item(id) == nil or nil }
    local s = Gear.Stats(id)
    local w = Gear.Weights(o.class, o.spec, o.kind, o.level)
    if not s or not w then
        e.loading = true
        return e
    end
    local place = Gear.WeaponPlace(slotKey, group)
    local cap = o.cap and o.cap[Gear.CAP_ROW[group] or slotKey]
    local v = Gear.Score(s, w, o.level, place, o.class, cap)
    local variants = o.suffix ~= "base" and Gear.SuffixStats(id)
    if variants then
        for sfx, vs in pairs(variants) do
            local x = Gear.Score(vs, w, o.level, place, o.class, cap)
            if x > v then v, e.suffix = x, sfx end
        end
    end
    e[2], e.sc = v, s.SC or nil
    return e
end

-- An own pick stays its row's target when the play style leaves it out (F-124), marked outside.
local function markOwn(e, o)
    if o.style and e[1] and ns.PlayStyle.Blocks(e[1], o) then e.outside = true end
    return e
end

local function without(list, a, b)
    local out = {}
    for _, e in ipairs(list or {}) do
        if e[1] ~= a and e[1] ~= b then out[#out + 1] = e end
    end
    return out
end

local function front(e, list)
    local out = { e }
    for _, x in ipairs(list) do
        if x[1] ~= e[1] then out[#out + 1] = x end
    end
    return out
end

-- Gear.Best's lists with the own picks of the options first in their rows (D-55): { [slot] = list,
-- plan = "2H"/"1H", rank = { [slot] = the slot's ranking without the own pick (both rings or both
-- trinkets: the one list) } }. A two-hand pick makes the plan two-hand, a one-hand or off-hand pick
-- one-hand; Gear.Best's lists are never changed.
local function applyOwn(best, o)
    local own = o.own
    local two = best.plan == "2H"
    if own then
        if own.MAINHAND then two = ns.BisGroup(own.MAINHAND) == "2H"
        elseif own.OFFHAND then two = false end
    end
    local MH, OH = best.MAINHAND, best.OFFHAND
    if two ~= (best.plan == "2H") then
        if two then MH, OH = best.altMainhand or {}, {} else MH, OH = best.altMainhand or {}, best.altOffhand or {} end
    end
    local out = { plan = two and "2H" or "1H", rank = {} }
    for _, sl in ipairs(Gear.SLOTS) do
        local k = sl.key
        local base = (k == "MAINHAND" and MH) or (k == "OFFHAND" and OH) or best[k] or {}
        out[k] = base
        out.rank[k] = (k == "FINGER2" and (best.FINGER1 or {})) or (k == "TRINKET2" and (best.TRINKET1 or {})) or base
    end
    if not own then return out end
    for k, id in pairs(own) do
        if k ~= "FINGER1" and k ~= "FINGER2" and k ~= "TRINKET1" and k ~= "TRINKET2" then
            out[k] = front(markOwn(ownEntry(k, id, o, out.rank[k]), o), out[k])
        end
    end
    -- the same weapon in both hands only when it is the pick of both
    if own.MAINHAND and own.OFFHAND ~= own.MAINHAND then out.OFFHAND = without(out.OFFHAND, own.MAINHAND) end
    -- two rings and two trinkets: one list; an item is the target of one row only
    for _, pair in ipairs({ { "FINGER1", "FINGER2" }, { "TRINKET1", "TRINKET2" } }) do
        local a, b = pair[1], pair[2]
        local pa, pb = own[a], own[b]
        if pa or pb then
            local full = best[a] or {}
            local rowA = pa and front(markOwn(ownEntry(a, pa, o, full), o), without(full, pb)) or without(best[a], pb)
            -- from the whole list: the top item a pick displaced from the first row stays a target
            local rowB = without(full, rowA[1] and rowA[1][1], pa)
            if pb then rowB = front(markOwn(ownEntry(b, pb, o, full), o), rowB) end
            out[a], out[b] = rowA, rowB
        end
    end
    return out
end

local targetKey, targetRes
local bestKey, bestRes, bestWaits   -- Gear.Best's result, kept while the options and the scoreStamp stay
local targetOwnStamp   -- the stamp at which targetRes was made with the own options, else nil
-- Per slot up to three options { id, score, gain, mine, owned, wished, worn, upgrade, switch },
-- best first; r.state[slot] "done" (option 1 worn), "bag"/"bank" (option 1 owned, not worn),
-- "switch", "upgrade", "none" or nil (no option); r.mine[slot] the worn score; r.upgrades; the
-- weapon plan as Gear.Best has it. Kept until anything it depends on changes.
function ns.BisTargets(opts)
    if not Gear.Available() then return emptyResult() end
    local o = opts or ns.BisOpts()
    if not o.class then return emptyResult() end
    local key = optsKey(o)
    if key == targetKey then
        if not opts then targetOwnStamp = stamp end
        return targetRes
    end
    -- read only below: the annotations go into new tables. Kept only when no item was still
    -- waiting for its stats (the client may have them by the next call).
    local bkey = optsKey(o, scoreStamp, true)
    local best = bestRes
    if bkey ~= bestKey or bestWaits ~= Gear.StatsWaits() then
        local w0 = Gear.StatsWaits()
        best = Gear.Best(o)
        bestWaits = Gear.StatsWaits()
        bestKey, bestRes = (bestWaits == w0) and bkey or nil, best
    end
    local r = emptyResult()
    local lists = applyOwn(best, o)
    r.plan, r.missing, r.total = lists.plan, best.missing, best.total
    r.twoHandScore, r.oneHandScore = best.twoHandScore, best.oneHandScore
    r.dwScore, r.shieldScore, r.planWanted, r.sets = best.dwScore, best.shieldScore, best.planWanted, best.sets
    -- the own picks in use and those kept but not used (F-112), each slot's ranking (ns.BisRanking)
    r.own, r.ownUnused, r.rank = o.own, o.ownUnused, lists.rank
    local ctx = context(o)
    local c = ns.BisChar()
    for _, sl in ipairs(Gear.SLOTS) do
        local list, out = lists[sl.key] or {}, r[sl.key]
        for i = 1, math.min(3, #list) do
            local id, score = list[i][1], list[i][2]
            local row = Gear.Item(id)
            local group = row and Gear.GROUP[row[1]] or ns.BisGroup(id)
            local gain, mine, switch = gainFor(sl.key, group, id, score, ctx)
            local owned = ns.BisOwned(id)
            local src = list[i]
            -- a BiS pick and an own pick are the row's target: an upgrade until worn
            out[i] = { id = id, score = score, gain = gain, mine = mine, owned = owned, worn = owned == "worn",
                wished = wishOf(c, id), switch = switch or nil,
                upgrade = (not switch and owned ~= "worn" and (src.pick ~= nil or src.own or ns.BisIsUpgrade(gain, mine))) or false,
                sc = src.sc, suffix = src.suffix, easier = src.easier, set = src.set, setb = src.setb,
                effort = src.effort, pick = src.pick, own = src.own or nil, unknown = src.unknown, loading = src.loading,
                outside = src.outside }
        end
        -- a BiS pick or own pick worn in the row: it is the target, nothing else is an upgrade there
        if out[1] and (out[1].pick or out[1].own) and out[1].worn then
            for i = 2, #out do out[i].upgrade = false end
        end
        r.mine[sl.key] = ctx.slot[sl.key]
        local first = out[1]
        local state
        if first then
            if first.worn then state = "done"
            elseif first.switch then state = "switch"
            elseif first.owned then state = first.owned
            elseif first.upgrade then state = "upgrade"
            else state = "none" end
            if first.upgrade then r.upgrades = r.upgrades + 1 end
        end
        r.state[sl.key] = state
    end
    targetKey, targetRes = key, r
    targetOwnStamp = (not opts) and stamp or nil
    return r
end

local hiddenKey, hiddenRes
-- What the play style keeps out of the own targets (F-124): { n, list = { { id, slot, why } } }, the
-- items among the first three options of each row without the play style that it leaves out (why:
-- the keys of the switches, ns.PlayStyle.WhyText). Kept until the options or the scores change.
function ns.BisStyleHidden(o)
    o = o or ns.BisOpts()
    local none = { n = 0, list = {} }
    if not o.style or not o.class or not Gear.Available() then return none end
    local plain = Gear.Copy(o)
    plain.style = nil
    local key = optsKey(plain, scoreStamp, true) .. "|" .. ns.PlayStyle.Key(o.style)
    if key == hiddenKey then return hiddenRes end
    local w0 = Gear.StatsWaits()
    local best = Gear.Best(plain)
    local out, seen = { n = 0, list = {} }, {}
    for _, sl in ipairs(Gear.SLOTS) do
        local list = best[sl.key] or {}
        for i = 1, math.min(3, #list) do
            local id = list[i][1]
            if not seen[id] then
                seen[id] = true
                local ok, why = ns.PlayStyle.ItemPasses(id, o)
                if not ok then
                    out.n = out.n + 1
                    out.list[#out.list + 1] = { id = id, slot = sl.key, why = why }
                end
            end
        end
    end
    if Gear.StatsWaits() == w0 then hiddenKey, hiddenRes = key, out end
    return out
end

-- The targets of the own character when they are at hand for the current state, else nil; never
-- computes them.
function ns.BisTargetsCached()
    if targetOwnStamp ~= nil and targetOwnStamp == stamp then return targetRes end
    return nil
end

-- How far the targets are got (F-113), kept with the result: { slot = { [slotKey] = "done" (the
-- target worn, or a worn item the target does not beat), "bag" (the target in bag or bank, not
-- worn), "todo" (a target still to get), "none" (no target) }, done, bag, todo, none, total }. The
-- shield hand beside a planned two-hander is done once the two-hander is worn.
function ns.BisProgress(res)
    res = res or ns.BisTargets()
    if res.progress then return res.progress end
    local p = { slot = {}, done = 0, bag = 0, todo = 0, none = 0, total = #Gear.SLOTS }
    local w = worn()
    for _, sl in ipairs(Gear.SLOTS) do
        local st = res.state[sl.key]
        local v
        if st == "done" then
            v = "done"
        elseif st == "bag" or st == "bank" then
            v = "bag"
        elseif st == "upgrade" or st == "switch" then
            v = "todo"
        elseif st == "none" then
            v = w.links[sl.inv] and "done" or "todo"
        elseif sl.key == "OFFHAND" and res.plan == "2H" then
            v = p.slot.MAINHAND == "done" and "done" or "none"
        else
            v = "none"
        end
        p.slot[sl.key] = v
        p[v] = p[v] + 1
    end
    res.progress = p
    return p
end

-- The ranking of a row for the own character (F-112): the best n (10) items of Gear.Best's list for
-- the row, with the own sources and exclusions and without the own pick moved ahead, best first:
-- { { id, score, gain, mine, owned, worn, upgrade, switch, own (the own pick), pick, suffix, setb } },
-- and how many the list holds. Both rings (both trinkets) share one list. Kept with the targets.
function ns.BisRanking(slotKey, n)
    n = n or 10
    local res = ns.BisTargets()
    res.ranked = res.ranked or {}
    local key = slotKey .. ":" .. n
    local kept = res.ranked[key]
    if kept then return kept[1], kept[2] end
    local list = res.rank and res.rank[slotKey] or {}
    local o = ns.BisOpts()
    local ctx = context(o)
    local mine = res.own and res.own[slotKey] or ns.BisPick(slotKey)
    local out = {}
    for i = 1, math.min(n, #list) do
        local src = list[i]
        local id = src[1]
        local gain, worth, switch = gainFor(slotKey, ns.BisGroup(id), id, src[2], ctx)
        local owned = ns.BisOwned(id)
        out[i] = { id = id, score = src[2], gain = gain, mine = worth, owned = owned, worn = owned == "worn",
            switch = switch or nil, own = mine == id or nil, pick = src.pick, suffix = src.suffix, setb = src.setb,
            upgrade = (not switch and owned ~= "worn" and ns.BisIsUpgrade(gain, worth)) or false }
    end
    res.ranked[key] = { out, #list }
    return out, #list
end

-- "Bestes auf Stufe N" (F-111): the simulation's result for the class, spec, weighting, level and
-- weapon plan with every source on, no exclusions and no own picks (both factions, all professions),
-- as the sum of option 1 per row. Kept until the scores change.
local ALL_SOURCES = { X = true, Q = true, D = true, C = true, V = true, W = true, A = true, P = true }
local bestSumKey, bestSum
local function bestAt(o)
    local key = table.concat({ tostring(ns.Data("GEAR")), tostring(ns.BIS), scoreStamp, tostring(o.class), tostring(o.spec),
        tostring(o.level), tostring(o.kind), tostring(o.plan) }, "|")
    if key == bestSumKey then return bestSum end
    local w0 = Gear.StatsWaits()
    local b = ns.BisFor(o.class, o.spec, o.level, { sources = ALL_SOURCES, plan = o.plan, kind = o.kind })
    local total = 0
    for _, sl in ipairs(Gear.SLOTS) do
        local e = b[sl.key] and b[sl.key][1]
        if e then total = total + e[2] end
    end
    -- kept only when no item was still waiting for its stats
    if Gear.StatsWaits() == w0 then bestSumKey, bestSum = key, total end
    return total
end

-- The score head of the goals window (F-111, D-11: Amisia's own score): { score (the sum of the
-- rows' scores with the targets: a target that is no upgrade and no pick leaves the worn item;
-- a two-hander counts once), now (the worn ones), gain, best (bestAt), level, stats = { { key,
-- label, points, value, pct, rating, text, up } } the changes targets against worn by weight, fx
-- (targets with an equip effect the score does not count) }. Kept with the targets.
function ns.BisSummary(res, o)
    res = res or ns.BisTargets()
    if res.summary then return res.summary end
    o = o or ns.BisOpts()
    local out = { score = 0, now = 0, gain = 0, best = 0, level = o.level, stats = {}, fx = 0 }
    if not o.class or not Gear.Available() then return out end
    local ctx = context(o)
    local links = worn().links
    local adds, drops = {}, {}
    local mainFellBack = false
    -- each row's worn item and score; a ring or trinket target worn in the other slot of its pair
    -- is that row's item, the other worn one belongs to the other row
    local rowCur, rowLink = {}, {}
    for _, sl in ipairs(Gear.SLOTS) do rowCur[sl.key], rowLink[sl.key] = ctx.slot[sl.key] or 0, links[sl.inv] end
    for _, pair in ipairs({ { "FINGER1", "FINGER2" }, { "TRINKET1", "TRINKET2" } }) do
        local a, b = pair[1], pair[2]
        local ta, tb = res[a] and res[a][1], res[b] and res[b][1]
        local ia, ib = ns.ItemID(rowLink[a]), ns.ItemID(rowLink[b])
        local aElsewhere = ta and ib == ta.id and ia ~= ta.id
        local bElsewhere = tb and ia == tb.id and ib ~= tb.id
        if aElsewhere or bElsewhere then
            rowCur[a], rowCur[b] = rowCur[b], rowCur[a]
            rowLink[a], rowLink[b] = rowLink[b], rowLink[a]
        end
    end
    for _, sl in ipairs(Gear.SLOTS) do
        local k, cur = sl.key, rowCur[sl.key]
        out.now = out.now + cur
        local first = res[k] and res[k][1]
        local use = first and not first.loading and (first.own or first.pick or first.upgrade or first.switch or first.owned)
        if use then
            if first.worn then
                out.score = out.score + cur
            else
                out.score = out.score + first.score
                adds[#adds + 1] = first
                if rowLink[k] then drops[#drops + 1] = rowLink[k] end
                -- a two-hander puts the worn shield hand away too
                if k == "MAINHAND" and res.plan == "2H" and links[17] then drops[#drops + 1] = links[17] end
            end
        elseif k == "OFFHAND" and res.plan == "2H" then
            if mainFellBack then out.score = out.score + cur end
        else
            out.score = out.score + cur
            if k == "MAINHAND" then mainFellBack = true end
        end
    end
    out.gain = out.score - out.now
    out.best = bestAt(o)
    -- the changes: every part of the targets less every part of the worn items they replace
    local diff = {}
    local function addParts(item, sign)
        local by, ev = partsOf(item, o)
        if not by then return end
        if sign > 0 and Gear.EffectText(ev.id) then out.fx = out.fx + 1 end
        for key, p in pairs(by) do
            if key ~= "SPEED" then
                local d = diff[key]
                if not d then
                    d = { key = key, label = p.label, points = 0, value = 0, pct = 0,
                        rating = type(p.amount) == "string" and p.amount:find("%%") ~= nil }
                    diff[key] = d
                end
                d.points = d.points + sign * p.points
                d.value = d.value + sign * (p.value or 0)
                if d.rating and p.weight ~= 0 then d.pct = d.pct + sign * p.points / p.weight end
            end
        end
    end
    for _, e in ipairs(adds) do addParts(e, 1) end
    for _, link in ipairs(drops) do addParts(link, -1) end
    for _, d in pairs(diff) do
        if math.abs(d.points) >= 0.5 then
            local sign = d.points >= 0 and "+" or "-"
            if d.rating then
                d.text = ("%s %s%s %%"):format(d.label, sign, Gear.Num(math.abs(d.pct), 1))
            else
                d.text = ("%s %s%s"):format(d.label, sign, Gear.Num(math.abs(d.value)))
            end
            d.up = d.points > 0
            out.stats[#out.stats + 1] = d
        end
    end
    table.sort(out.stats, function(a, b)
        if math.abs(a.points) ~= math.abs(b.points) then return math.abs(a.points) > math.abs(b.points) end
        return a.key < b.key
    end)
    res.summary = out
    return out
end

-- The hint under a worn own pick (F-112): the best item of the row's ranking when it beats the pick
-- by at least bis.minGain percent: { id, pct, gain } or nil. Amisia never takes it over by itself.
function ns.BisOvertaken(slotKey)
    local res = ns.BisTargets()
    local first = res[slotKey] and res[slotKey][1]
    if not (first and first.own and first.worn) then return nil end
    -- against the pick's own score (a ring's gain would be held against the weaker worn ring)
    local base = first.score or 0
    for _, e in ipairs((ns.BisRanking(slotKey, 10))) do
        if e.id ~= first.id and not e.worn then
            local gain = (e.score or 0) - base
            if ns.BisIsUpgrade(gain, base) then
                return { id = e.id, gain = gain, pct = base > 0 and math.floor(gain / base * 100 + 0.5) or nil }
            end
            return nil
        end
    end
    return nil
end

---------------------------------------------------------------------------
-- Exclusions
---------------------------------------------------------------------------

-- kind "item" (id or link), "boss" (name as in the source) or "place" ("I:<instance>", "Z:<map>",
-- "N:<name>"). on false lifts it. true or nil, reason.
function ns.BisExclude(kind, key, on)
    local c = ns.BisChar()
    if not c then return nil, L["Amisia ist noch nicht geladen."] end
    if on == nil then on = true end
    local set
    if kind == "item" then
        key = tonumber(key) or ns.ItemID(key)
        if not key then return nil, L["Kein Item."] end
        set = c.ex.item
    elseif kind == "boss" then
        if type(key) ~= "string" or key == "" then return nil, L["Kein Boss."] end
        set = c.ex.boss
    elseif kind == "place" then
        if type(key) ~= "string" or not key:find("^[IZN]:.") then return nil, L["Kein Ort."] end
        set = c.ex.place
    else
        return nil, L["Unbekannte Art."]
    end
    set[key] = on and true or nil
    ns.Fire("BIS_CHANGED")
    return true
end

-- Lifts every exclusion; returns how many there were.
function ns.BisClearExcludes()
    local c = ns.BisChar()
    if not c then return 0 end
    local n = 0
    for _, set in pairs(c.ex) do
        for k in pairs(set) do set[k] = nil; n = n + 1 end
    end
    ns.Fire("BIS_CHANGED")
    return n
end

-- How many exclusions there are.
function ns.BisExcludeCount()
    local c = ns.BisChar()
    local n = 0
    for _, set in pairs(c and c.ex or {}) do
        for _ in pairs(set) do n = n + 1 end
    end
    return n
end

---------------------------------------------------------------------------
-- Here: what a place still offers
---------------------------------------------------------------------------

-- The player's place: in an instance its id and name; outside the map and its parents up to the
-- continent.
local function currentPlace()
    local name, itype, _, _, _, _, _, instID = GetInstanceInfo()
    name, itype, instID = ns.Plain(name), ns.Plain(itype), ns.Plain(instID)
    if type(itype) == "string" and itype ~= "none" and type(instID) == "number" and instID > 0 then
        local keys = { ["I:" .. instID] = true }
        if type(name) == "string" and name ~= "" then keys["N:" .. name] = true end
        return { key = "I:" .. instID, keys = keys, text = type(name) == "string" and name or nil }
    end
    local map = C_Map and C_Map.GetBestMapForUnit and ns.Plain(C_Map.GetBestMapForUnit("player"))
    local keys, first, text = {}, nil, nil
    for _ = 1, 10 do
        if type(map) ~= "number" or map <= 0 then break end
        local info = C_Map.GetMapInfo and C_Map.GetMapInfo(map)
        if type(info) ~= "table" or (tonumber(info.mapType) or 3) <= 2 then break end
        keys["Z:" .. map] = true
        if not first then first, text = map, info.name end
        map = info.parentMapID
    end
    if not first then return nil end
    return { key = "Z:" .. first, keys = keys, text = text }
end
-- The player's place as "Hier" finds it ({ key, keys, text }), or nil; nothing is listed.
ns.BisCurrentPlace = currentPlace

local placesCache, placesFor
-- The raids and dungeons of the data for the place picker: { { key, text, raid } }, raids first.
function ns.BisPlaces()
    local d = ns.Data("GEAR")
    if not d then return {} end
    if placesFor == d and placesCache then return placesCache end
    local seen, out = {}, {}
    for _, rec in ipairs(d.S) do
        if rec[1] == "X" or rec[1] == "D" then
            local base = Gear.PlaceOf(rec)
            if base then
                if not seen[base] then
                    seen[base] = true
                    out[#out + 1] = { key = base, text = Gear.PlaceName(rec) or base, raid = rec[1] == "X" }
                end
            end
        end
    end
    table.sort(out, function(a, b)
        if a.raid ~= b.raid then return a.raid end
        if a.text ~= b.text then return a.text < b.text end
        return a.key < b.key
    end)
    placesCache, placesFor = out, d
    return out
end

local function placeFor(key)
    local text
    for _, p in ipairs(ns.BisPlaces()) do
        if p.key == key then text = p.text end
    end
    return { key = key, keys = { [key] = true }, text = text }
end

local hereKey, herePlace, hereList
-- place, list: the place (current, or placeKey from the picker) and its items that are upgrades or
-- wishes for the options, { id, rec, score, gain, mine, owned, wished, upgrade, switch }, by gain
-- with owned items at the bottom. place.loading counts items still waiting for their stats.
function ns.BisHere(placeKey, opts)
    local place = placeKey and placeFor(placeKey) or currentPlace()
    if not place or not Gear.Available() then return place, {} end
    local o = opts or ns.BisOpts()
    if not o.class then return place, {} end
    -- a place picked by hand needs no zone switch (F-124): it would leave nothing there
    if placeKey and o.style and o.style.on.zone then
        local copy = Gear.Copy(o)
        copy.style = ns.PlayStyle.Without(o.style, "zone")
        o = copy
    end
    local key = optsKey(o) .. "|" .. place.key
    if key == hereKey then return herePlace, hereList end
    local d = ns.Data("GEAR")
    -- the sources at this place first, then the items that have one
    local at = {}
    for n, rec in ipairs(d.S) do
        local p = Gear.PlaceOf(rec)
        if p and place.keys[p] then at[n] = rec end
    end
    local c = ns.BisChar()
    local exItem = o.exclude and o.exclude.item or {}
    local list, loading = {}, 0
    if next(at) then
        for id, row in pairs(d.I) do
            local hit
            for i = Gear.FIRST_SOURCE, #row do
                local rec = at[row[i]]
                if rec and Gear.SourceOk(rec, o, row) then hit = rec break end
            end
            -- the reputation of "Jetzt holbar" (F-124)
            if hit and o.style and not ns.PlayStyle.ItemOk(id, o.style) then hit = nil end
            if hit and not exItem[id] then
                if (row[4] or 0) <= o.level then
                    local ev = evaluate(id, o)
                    if ev.code == "loading" then loading = loading + 1 end
                    if not ev.reason then
                        local wished = wishOf(c, id)
                        -- an own pick is the row's target (D-55): one not worn counts, while one is
                        -- worn nothing else does
                        local up = not ev.switch and not ev.ownWorn
                            and ((ev.own and not worn().ids[id]) or ns.BisIsUpgrade(ev.gain, ev.mine))
                        if up or wished then
                            list[#list + 1] = { id = id, rec = hit, slotKey = ev.slotKey, score = ev.score, gain = ev.gain, mine = ev.mine,
                                owned = ns.BisOwned(id), wished = wished, upgrade = up or false, switch = ev.switch or nil }
                        end
                    end
                end
            end
        end
    end
    table.sort(list, function(a, b)
        local oa, ob = a.owned and 1 or 0, b.owned and 1 or 0
        if oa ~= ob then return oa < ob end
        local ga, gb = a.gain or -1e9, b.gain or -1e9
        if ga ~= gb then return ga > gb end
        return a.id < b.id
    end)
    place.loading = loading
    hereKey, herePlace, hereList = key, place, list
    return place, list
end

---------------------------------------------------------------------------
-- What changes a result
---------------------------------------------------------------------------

local function talentsChanged() guess = nil; bumpAll() end
ns.OnEvent("CHARACTER_POINTS_CHANGED", talentsChanged)
ns.OnEvent("PLAYER_TALENT_UPDATE", talentsChanged)
ns.OnEvent("ACTIVE_TALENT_GROUP_CHANGED", talentsChanged)
ns.OnEvent("PLAYER_LEVEL_UP", bump)
-- every skill-up (weapon skills too) fires this: a new result only when a profession's rank changed
local function sameSkills(a, b)
    if type(a) ~= "table" or type(b) ~= "table" then return a == b end
    for k, v in pairs(a) do if b[k] ~= v then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
ns.OnEvent("SKILL_LINES_CHANGED", function()
    local old = skills
    skills = nil
    if old == nil or not sameSkills(old, ns.BisSkills() or false) then bump() end
end)
-- the window sizes and other ui.* settings change no result (each Ctrl + wheel notch over the goals
-- window is one); an own pick changes no score, only the targets (D-55)
ns.Listen("SETTING", function(path)
    if type(path) == "string" and path:find("^ui%.") then return end
    bumpAll()
end)
ns.Listen("BIS_CHANGED", function(kind)
    guess = nil
    -- an own pick or the play style changes no score, only which items count
    if kind == "pick" or kind == "style" then bump() else bumpAll() end
end)
Gear.OnData(bumpAll)
-- a suffix the collector adds changes Gear.Best's lists (the targets pick it up with the next stamp)
local suffixNoted = Gear.SuffixNoted
function Gear.SuffixNoted(id)
    suffixNoted(id)
    scoreStamp = scoreStamp + 1
end

---------------------------------------------------------------------------
-- Tooltip line
---------------------------------------------------------------------------

local TIP_GREEN = { 0.31, 0.82, 0.42 }
local TIP_GREY = { 0.56, 0.53, 0.64 }
local TIP_ORANGE = { 1, 0.6, 0.2 }
local TIP_PARTS = 4             -- explanation lines on Shift
local TIP_CACHE_MAX = 200       -- links kept per state
local WARM_GAP = 2              -- seconds between two deferred target computations

-- The rows an item of a group competes for in the targets.
local RANK_SLOTS = { FINGER = { "FINGER1", "FINGER2" }, TRINKET = { "TRINKET1", "TRINKET2" },
    ["2H"] = { "MAINHAND" }, ["1H"] = { "MAINHAND", "OFFHAND" }, MH = { "MAINHAND" }, OHW = { "OFFHAND" },
    SHIELD = { "OFFHAND" }, HELD = { "OFFHAND" } }

-- The targets are never computed inside a hover: when they are missing, once after it (at most
-- every WARM_GAP seconds), so the next hover has them.
local warmPending, warmAt = false, nil
local function warmTargets()
    if warmPending then return end
    warmPending = true
    local t = GetTime and GetTime() or 0
    local wait = warmAt and math.max(0, WARM_GAP - (t - warmAt)) or 0
    C_Timer.After(wait, function()
        warmPending = false
        warmAt = GetTime and GetTime() or 0
        if ns.BisTargetsCached() then return end
        local ok, err = pcall(ns.BisTargets)
        if not ok then ns.ReportError(err) end
    end)
end

-- Rank (1-3) and row of an item among the cached targets.
local function targetRank(res, id, group)
    for _, slotKey in ipairs(RANK_SLOTS[group] or { SLOT_OF[group] }) do
        for i, e in ipairs(res[slotKey] or {}) do
            if e.id == id then return i, slotKey end
        end
    end
    return nil
end

-- The line (and on Shift the explanation) for one link: { { text, color }, ... }, plus whether it
-- was made without the targets and whether it may be kept (not while stats are still loading).
-- "statt Helm B", "statt Ring (schwächerer Ring)", "statt Axt + Schild": what an item is compared with.
local function againstText(u)
    local names = {}
    for _, link in ipairs(u.against) do
        names[#names + 1] = link:match("|h%[(.-)%]|h") or ns.ItemName(ns.ItemID(link))
    end
    if #names == 0 then return nil end
    local text = L["statt %s"]:format(table.concat(names, " + "))
    if u.weaker then
        text = text .. (u.slotKey == "FINGER1" and L[" (schwächerer Ring)"] or L[" (schwächerer Schmuck)"])
    end
    return text
end

-- The enchantment on a worn item as its tooltip names it ("Rüstung +10"), or nil.
local enchantCache = {}
local function enchantOf(link)
    if type(link) ~= "string" or not link:find("item:%d+:%d") then return nil end
    local v = enchantCache[link]
    if v ~= nil then return v or nil end
    v = false
    -- the client's template with its magic characters escaped (a locale's "(", "-" or "." would
    -- else break the match)
    local pattern = ns.TemplatePattern(ENCHANTED_TOOLTIP_LINE)
    local ok, tip = pcall(function() return C_TooltipInfo and C_TooltipInfo.GetHyperlink and C_TooltipInfo.GetHyperlink(link) end)
    if pattern and ok and type(tip) == "table" then
        for _, line in ipairs(tip.lines or {}) do
            local text = type(line.leftText) == "string" and line.leftText or nil
            local name = text and text:match(pattern)
            if name then v = name break end
        end
    end
    enchantCache[link] = v
    return v or nil
end
-- Test hook: the enchantment reader.
ns._bis = { enchantOf = enchantOf }

-- The parts of the change on Shift: "Schaden +2,0 %, Überleben -0,4 %" or, for a tank, "Überleben +1,1
-- %, Bedrohung +0,3 %".
local function partsText(u)
    if u.threat then return L["Überleben %s, Bedrohung %s"]:format(pctText(u.main), pctText(u.threat)) end
    if u.surv then return ("%s %s, %s %s"):format(ROLE_WORD[u.role] or L["Schaden"], pctText(u.main), L["Überleben"], pctText(u.surv)) end
    return nil
end

-- The values the change moves, "Angriffskraft 512 -> 522", from the model (at most TIP_PARTS).
local function valueLines(link, max)
    local o = ns.BisOpts()
    local ev = evaluate(link, o)
    if ev.reason or ev.switch then return {} end
    local mc, c = modelChange(ev, o, o.spec)
    if not mc then return {} end
    local out = {}
    for _, v in ipairs(ns.Model.Values(o.class, c.p, c.st, mc.after, true)) do
        if #out >= max then break end
        out[#out + 1] = ("%s: %s"):format(v[1], v[2])
    end
    return out
end

local function tipLines(link, id, shift)
    local u, _, code = ns.UpgradeOf(link)
    if not u then
        if code == "switch" then return { { L["Waffenwechsel für dich"], TIP_GREY } }, false, true end
        return {}, false, code ~= "loading"
    end
    local gain, slotKey = u.gain, u.slotKey
    local compare = ns.Get("bis.compare") ~= false   -- l10n-ok: setting key
    local c = ns.BisChar()
    local isWorn = worn().ids[id] ~= nil
    -- a BiS pick is the slot's target: an upgrade until worn; while one is worn nothing else is
    local up = not isWorn and u.better
    local text, color, noTargets = nil, TIP_GREY, false
    local vs = up               -- the worn item goes under an upgrade or a "Kein Upgrade" line
    local points = math.floor(gain + 0.5)
    local slotName = SLOT_NAME[slotKey] or ""
    local spec = u.spec and specText(u)
    local role = ROLE_WORD[u.role] or L["Schaden"]
    local approx = u.approx and L[" (ungefähr)"] or ""
    if up then
        local head = u.later and L["Upgrade für dich ab Stufe %d"]:format(u.later) or L["Upgrade für dich"]
        if spec then head = ("%s (%s)"):format(head, spec) end
        local where = #u.against > 0 and slotName or L["%s, Platz leer"]:format(slotName)
        if compare and u.total then
            text = ("%s: %s %s (%s)%s"):format(head, pctText(u.total), role, where, approx)
        elseif compare and u.pct then
            text = ("%s: %+d %% (%+d, %s)"):format(head, u.pct, points, slotName)
        else
            text = ("%s: %s"):format(head, where)
        end
        color = u.later and TIP_ORANGE or TIP_GREEN
    else
        local res = ns.BisTargetsCached()
        local rank, rankSlot
        if res then
            local loc = rowType(id)
            rank, rankSlot = targetRank(res, id, loc and Gear.GROUP[loc])
        else
            noTargets = true
            warmTargets()
        end
        if rank then
            text = (isWorn and L["angelegt, Option %d für %s"] or L["Option %d für %s"]):format(rank, SLOT_NAME[rankSlot] or "")
        elseif not isWorn and ns.Get("bis.tooltipNone") then   -- l10n-ok: setting key
            vs = true
            local head = spec and ("%s (%s)"):format(L["Kein Upgrade für dich"], spec) or L["Kein Upgrade für dich"]
            if compare and u.total then
                text = ("%s: %s %s%s"):format(head, pctText(u.total), role, approx)
            elseif compare and u.pct then
                text = ("%s: %+d, %+d %%"):format(head, points, u.pct)
            else
                text = head
            end
        end
    end
    if not text and u.pick then text, color = L["BiS-Empfehlung für dich (%s)"]:format(slotName), TIP_GREEN end
    if not text then return {}, noTargets, true end
    if c and c.wish[id] then text = text .. L[" · auf deiner Wunschliste"] end
    local out = { { text, color } }
    if u.pick then out[#out + 1] = { ns.BisPickText(u.pick), TIP_GREEN } end
    local against = compare and vs and againstText(u)
    if against then out[#out + 1] = { against, TIP_GREY } end
    if shift and compare then
        local parts = u.total and partsText(u)
        if parts then out[#out + 1] = { parts, TIP_GREY } end
        if u.pct then out[#out + 1] = { L["Slot: %+d %%"]:format(u.pct), TIP_GREY } end
        if ns.Get("bis.otherSpecs") ~= false then   -- l10n-ok: setting key
            local others = {}
            for _, e in ipairs(ns.UpgradeOthers(link)) do others[#others + 1] = ("%s %s"):format(e.name, pctText(e.total)) end
            if #others > 0 then out[#out + 1] = { L["Andere Spezialisierungen: %s"]:format(table.concat(others, ", ")), TIP_GREY } end
        end
        for _, line in ipairs(valueLines(link, TIP_PARTS)) do out[#out + 1] = { line, TIP_GREY } end
        local first = u.against[1]
        local ench = first and enchantOf(first)
        if ench then out[#out + 1] = { L["Verzauberung bleibt am alten Item: %s"]:format(ench), TIP_GREY } end
        if u.approx then out[#out + 1] = { L["Ungefähr: der Charakterbogen wird erst außerhalb des Kampfs gelesen."], TIP_GREY } end
    elseif shift then
        local ex = ns.BisExplain(link)
        for i = 2, math.min(#ex, TIP_PARTS + 1) do out[#out + 1] = { ex[i], TIP_GREY } end
    end
    return out, noTargets, true
end

-- Lines per link and Shift state, kept until anything changes (the stamp); an entry made without
-- the targets is made again once they are there.
local tipCache, tipCacheStamp, tipCacheN = {}, nil, 0
local placeOnly = {}            -- the place line alone (upgrade line off), per text

-- On Shift the place of the item (Map.lua's "Fundort" line, cached there per item and state), or
-- nil; an error goes to the error handler and leaves the other lines.
local function placeLine(id, shift)
    if not shift or not ns.MapTooltipLine then return nil end
    local ok, line = pcall(ns.MapTooltipLine, id)
    if not ok then
        ns.ReportError(line)
        return nil
    end
    return line
end

-- Whether the client's item type alone says an item is no gear (as evaluate's "notgear"), without
-- building the gear data: not when the client does not know it or a BiS pick has its row (ns.BIS.PI).
local function notGear(id)
    local B = ns.BIS
    if type(B) == "table" and type(B.PI) == "table" and B.PI[id] then return false end
    local _, _, _, loc, _, classID = itemInstant(id)
    if type(loc) ~= "string" then return false end
    local group = loc ~= "" and Gear.GROUP[(loc:gsub("^INVTYPE_", ""))]
    return not (group and (classID == 2 or classID == 4))
end

function ns.BisTooltipLines(link)
    if not Gear.Available() then return nil end
    local id = ns.ItemID(link)
    if not id then return nil end
    local shift = IsShiftKeyDown and IsShiftKeyDown() and true or false
    local place = placeLine(id, shift)
    if tipCacheStamp ~= stamp or tipCacheN >= TIP_CACHE_MAX then
        tipCache, tipCacheStamp, tipCacheN, placeOnly = {}, stamp, 0, {}
    end
    if not ns.Get("bis.tooltip") then   -- l10n-ok: setting key
        if not place then return nil end
        local only = placeOnly[place]
        if not only then
            only = { { place, TIP_GREY } }
            placeOnly[place] = only
        end
        return only
    end
    local key = shift and (link .. "|S") or link
    local e = tipCache[key]
    if e and e.noTargets and ns.BisTargetsCached() then e = nil end
    if not e then
        local lines, noTargets, keep
        if notGear(id) then
            lines, noTargets, keep = {}, false, true
        else
            lines, noTargets, keep = tipLines(link, id, shift)
        end
        e = { lines = lines, noTargets = noTargets }
        if keep then
            tipCache[key] = e
            tipCacheN = tipCacheN + 1
        end
    end
    if not place then return e.lines end
    -- the place goes under the lines, kept with them until it changes
    if e.place ~= place then
        local full = {}
        for i, l in ipairs(e.lines) do full[i] = l end
        full[#full + 1] = { place, TIP_GREY }
        e.place, e.full = place, full
    end
    return e.full
end

ns.OnItemTooltip("bis", function(tip, link)   -- l10n-ok: command word / internal key
    local lines = ns.BisTooltipLines(link)
    if not lines or #lines == 0 then return false end
    for _, l in ipairs(lines) do tip:AddLine(l[1], l[2][1], l[2][2], l[2][3]) end
    return true
end)

---------------------------------------------------------------------------
-- Wishlist
---------------------------------------------------------------------------

local PRIO_TEXT = { [3] = L["hoch"], [2] = L["mittel"], [1] = L["niedrig"] }
ns.BIS_PRIO_TEXT = PRIO_TEXT

local function clampPrio(p)
    p = math.floor(tonumber(p) or 2)
    return math.max(1, math.min(3, p))
end

local function itemName(id, link)
    local name = itemInfo(id)
    if type(name) == "string" and name ~= "" then return name end
    name = type(link) == "string" and link:match("|h%[(.-)%]|h")
    return name or ("Item " .. id)
end

-- Whether the own class can wear an item, by its type alone (at the data's level cap, so plate
-- for a level 30 warrior counts). Unknown to the client: no item.
local function wearable(id)
    local _, _, _, instLoc = itemInstant(id)
    if instLoc == nil and not Gear.Item(id) then return nil, L["Kein Item."] end
    local loc, classID, sub, row = rowType(id)
    local group = loc and Gear.GROUP[loc]
    local _, class = UnitClass("player")
    local cannot = L["Das kann dein Charakter nicht tragen."]
    if not group or not (classID == 2 or classID == 4) then return nil, cannot end
    if class and not Gear.Usable(class, { loc, classID, sub or 0 }, Gear.Cap(), (ns.BisSpec())) then return nil, cannot end
    if class and row and (row[8] or 0) > 0 and not Gear.HasClassBit(row[8], class) then return nil, cannot end
    return true
end

-- Adds a wish (id or link) or changes its priority (3 high, 2 medium, 1 low) and note.
-- Returns the entry, or nil and the reason.
function ns.WishAdd(item, prio, note)
    local c = ns.BisChar()
    if not c then return nil, L["Amisia ist noch nicht geladen."] end
    local id = tonumber(item) or ns.ItemID(item)
    if not id or id <= 0 or id % 1 ~= 0 then return nil, L["Kein Item."] end
    local e = c.wish[id]
    if not e then
        local ok, why = wearable(id)
        if not ok then return nil, why end
        local n = 0
        for _ in pairs(c.wish) do n = n + 1 end
        if n >= MAX_WISH then return nil, L["Die Wunschliste ist voll (%d)."]:format(MAX_WISH) end
        e = { t = time(), prio = clampPrio(prio), note = ns.CleanNote(note, NOTE_MAX) or "" }
        c.wish[id] = e
    else
        if prio ~= nil then e.prio = clampPrio(prio) end
        if note ~= nil then e.note = ns.CleanNote(note, NOTE_MAX) or "" end
    end
    ns.Fire("BIS_CHANGED")
    return e
end

function ns.WishRemove(item)
    local c = ns.BisChar()
    local id = tonumber(item) or ns.ItemID(item)
    if not c or not id or not c.wish[id] then return nil end
    c.wish[id] = nil
    ns.Fire("BIS_CHANGED")
    return true
end

function ns.WishSetPrio(item, prio)
    local c = ns.BisChar()
    local id = tonumber(item) or ns.ItemID(item)
    local e = c and id and c.wish[id]
    if not e then return nil end
    e.prio = clampPrio(prio)
    ns.Fire("BIS_CHANGED")
    return e
end

-- The wishes { id, e, owned, slot (German), src (best source, short), name, excluded }, by priority,
-- then name.
function ns.Wishes()
    local c = ns.BisChar()
    local out = {}
    if not c then return out end
    local o = Gear.Available() and ns.BisOpts() or nil
    for id, e in pairs(c.wish) do
        local loc = rowType(id)
        local group = loc and Gear.GROUP[loc]
        local slotKey = group and SLOT_OF[group]
        local src
        if o then
            local rec = Gear.Sources(id, o)[1] or Gear.Sources(id)[1]
            src = rec and Gear.SourceText(rec, true) or nil
        end
        out[#out + 1] = { id = id, e = e, owned = ns.BisOwned(id), slot = slotKey and SLOT_NAME[slotKey] or nil, slotKey = slotKey,
            src = src, name = itemName(id), excluded = c.ex.item[id] or nil }
    end
    table.sort(out, function(a, b)
        if a.e.prio ~= b.e.prio then return a.e.prio > b.e.prio end
        if a.name ~= b.name then return a.name < b.name end
        return a.id < b.id
    end)
    return out
end

-- The wishes as text for the website's wishlist tab: "#AMISIA 2 <name>", one WL line per wish
-- (priority down, then item id; the note is the last field and may hold spaces), "#END". Not part of
-- the raid export.
function ns.WishExportText()
    local c = ns.BisChar()
    local name = ns.ExportName(ns.UnitFullName("player") or "?")
    local lines = { "#AMISIA 2 " .. name }
    local ids = {}
    for id in pairs(c and c.wish or {}) do ids[#ids + 1] = id end
    table.sort(ids, function(a, b)
        local pa, pb = c.wish[a].prio or 2, c.wish[b].prio or 2
        if pa ~= pb then return pa > pb end
        return a < b
    end)
    for _, id in ipairs(ids) do
        local e = c.wish[id]
        -- WL <itemID> <prio 1-3> <epoch> <name> [<note>]
        local note = tostring(e.note or ""):gsub("|", ""):gsub("%c", " "):match("^%s*(.-)%s*$")
        lines[#lines + 1] = ("WL %d %d %d %s%s"):format(id, clampPrio(e.prio), tonumber(e.t) or 0, name, note ~= "" and (" " .. note) or "")
    end
    lines[#lines + 1] = "#END"
    return table.concat(lines, "\n")
end

-- Self clean-up (bis.wishAutoRemove): a wish that is worn, in the bags or in the bank goes.
local function cleanWishes()
    if not ns.Get("bis.wishAutoRemove") then return end   -- l10n-ok: setting key
    local c = ns.BisChar()
    if not c or not next(c.wish) then return end
    local gone = {}
    for id in pairs(c.wish) do
        if ns.BisOwned(id) then gone[#gone + 1] = id end
    end
    if #gone == 0 then return end
    table.sort(gone)
    for _, id in ipairs(gone) do
        c.wish[id] = nil
        ns.msg(L["%s von deiner Wunschliste genommen, du hast das Item."]:format(itemName(id)))
    end
    ns.Fire("BIS_CHANGED")
end
ns.BisOnOwned(cleanWishes)

-- The own loot line ("You receive loot: ...") takes a wish off at once and reads the bags.
ns.OnEvent("CHAT_MSG_LOOT", function(text)
    text = ns.Plain(text)
    if type(text) ~= "string" then return end
    local who, id = ns.ParseLoot(text)
    if not who or not ns.SameName(who, ns.UnitFullName("player")) then return end
    local c = ns.BisChar()
    if c and c.wish[id] and ns.Get("bis.wishAutoRemove") then   -- l10n-ok: setting key
        c.wish[id] = nil
        ns.msg(L["%s von deiner Wunschliste genommen, du hast das Item."]:format(itemName(id)))
        ns.Fire("BIS_CHANGED")
    end
    -- gear read at once; herbs and ore wait for the next bag update
    if c and keepId(id, c) then scanBags() end
end)

---------------------------------------------------------------------------
-- Toast: a wish or an upgrade drops
---------------------------------------------------------------------------

local TOAST_SECONDS, TOAST_MAX, TOAST_AGAIN = 8, 3, 120
local TOAST_Y = -60
local QUALITY = ns.Theme.QUALITY_HEX
local GOLD = { 0.89, 0.72, 0.34 }
local toastFrame, current
local waiting = {}        -- toasts after the shown one, oldest first
local lastToast = {}      -- item id -> time of its last toast
local token = 0

local showNext

local function closeToast()
    token = token + 1
    current = nil
    if toastFrame then
        toastFrame.id, toastFrame.link, toastFrame.slotKey, toastFrame.hover = nil, nil, nil, false
        toastFrame:Hide()
    end
    showNext()
end

local function buildToast()
    -- the client's tooltip ground and border (TooltipBackdropTemplate); the flat ground with a gold
    -- frame of before when the template is missing or lacks its NineSlice. Made without a name so a
    -- rejected try leaves no frame under it; the name is set after the probe.
    local ok, f = pcall(CreateFrame, "Button", nil, UIParent, "TooltipBackdropTemplate")
    if ok and f and not f.NineSlice then
        f:Hide()
        f:ClearAllPoints()
        ok = false
    end
    if ok and f then
        _G.AmisiaBisToast = f
    else
        f = CreateFrame("Button", "AmisiaBisToast", UIParent)
        local bg = f:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0.055, 0.04, 0.08, 0.94)
        for _, e in ipairs({ { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 },
                             { "TOPLEFT", "BOTTOMLEFT", 1, nil }, { "TOPRIGHT", "BOTTOMRIGHT", 1, nil } }) do
            local t = f:CreateTexture(nil, "BORDER")
            t:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 0.7)
            t:SetPoint(e[1]); t:SetPoint(e[2])
            if e[3] then t:SetWidth(e[3]) end
            if e[4] then t:SetHeight(e[4]) end
        end
    end
    f:SetSize(320, 58)
    -- high up, 60-118 px below the top: clear of the award dialog and the roll window (from about
    -- 124 px down on the smallest screen) and above the client's error line (122 px down)
    f:SetPoint("TOP", UIParent, "TOP", 0, TOAST_Y)
    -- above the main window and the roll windows; only the mouse, never the keyboard
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(36, 36)
    f.icon:SetPoint("LEFT", 11, 0)
    f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local function line(template, y)
        local fs = f:CreateFontString(nil, "OVERLAY", template)
        fs:SetPoint("TOPLEFT", 56, y)
        fs:SetWidth(256)
        fs:SetJustifyH("LEFT")
        fs:SetWordWrap(false)
        return fs
    end
    f.title = line("GameFontNormal", -7)
    f.item = line("GameFontHighlightSmall", -24)
    f.source = line("GameFontDisableSmall", -39)
    f:SetScript("OnEnter", function(self)
        self.hover = true
        if self.link and GameTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetHyperlink(self.link)
            GameTooltip:Show()
        end
    end)
    f:SetScript("OnLeave", function(self)
        self.hover = false
        if GameTooltip then GameTooltip:Hide() end
    end)
    f:SetScript("OnClick", function(self, button)
        if button == "RightButton" then closeToast() return end
        if self.link and IsShiftKeyDown and IsShiftKeyDown() then
            -- into the open chat box, else a chat box opened with it (a modified click only
            -- inserts into one that is open)
            local util = type(ChatFrameUtil) == "table" and ChatFrameUtil or {}
            local insert = util.InsertLink
            if not (type(insert) == "function" and insert(self.link)) then
                local open = util.OpenChat
                if type(open) == "function" then open(self.link) end
            end
            return
        end
        local slotKey = self.slotKey
        closeToast()
        if ns.ShowGear then ns.ShowGear("goals", slotKey) end
    end)
    f:Hide()
    return f
end

local function expire(my)
    if my ~= token or not toastFrame then return end
    if toastFrame.hover or toastFrame:IsMouseOver() then
        C_Timer.After(1, function() expire(my) end)
        return
    end
    closeToast()
end

local function show(entry)
    toastFrame = toastFrame or buildToast()
    local f = toastFrame
    token = token + 1
    current = entry
    f.id, f.link, f.slotKey, f.hover = entry.id, entry.link, entry.slotKey, false
    local _, link, q, _, _, _, _, _, _, icon = itemInfo(entry.id)
    if not icon then icon = select(5, itemInstant(entry.id)) end
    q = q or ns.LinkQuality(entry.link) or 4
    f.icon:SetTexture(icon or 134400)
    if entry.why == "wish" then
        f.title:SetText(L["Wunsch droppt!"])
        f.title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
    else
        f.title:SetText(L["Upgrade für dich"])
        f.title:SetTextColor(0.31, 0.82, 0.42)
    end
    local extra = ""
    if entry.slotKey and entry.total and ns.Get("bis.compare") ~= false then   -- l10n-ok: setting key
        extra = (" %s (%s)"):format(pctText(entry.total), SLOT_NAME[entry.slotKey] or "")
    elseif entry.gain and entry.slotKey and entry.pct and ns.Get("bis.compare") ~= false then   -- l10n-ok: setting key
        extra = (" %+d %% (%+d, %s)"):format(entry.pct, math.floor(entry.gain + 0.5), SLOT_NAME[entry.slotKey] or "")
    elseif entry.gain and entry.slotKey then
        extra = (" %+d (%s)"):format(math.floor(entry.gain + 0.5), SLOT_NAME[entry.slotKey] or "")
    end
    f.item:SetText(("|c%s%s|r%s"):format(QUALITY[q] or QUALITY[4], itemName(entry.id, entry.link or link), extra))
    f.source:SetText(entry.src or "")
    f:Show()
    if entry.why == "wish" and ns.Get("bis.toastSound") and type(PlaySound) == "function" and SOUNDKIT and SOUNDKIT.RAID_WARNING then   -- l10n-ok: setting key
        pcall(PlaySound, SOUNDKIT.RAID_WARNING)
    end
    local my = token
    C_Timer.After(TOAST_SECONDS, function() expire(my) end)
end

showNext = function()
    if current then return end
    local entry = table.remove(waiting, 1)
    if entry then show(entry) end
end

-- Shows a toast for an item: why "wish" or "upgrade", the link (for the name and the shift-click)
-- and where it was seen. One at a time; at most three at once, the oldest waiting one goes.
function ns.BisToast(id, why, link, src)
    id = tonumber(id) or ns.ItemID(id)
    if not id then return end
    local entry = { id = id, why = why, link = link, src = src }
    local u = ns.UpgradeOf(link or id)
    entry.slotKey = u and SLOT_NAME[u.slotKey] and u.slotKey or nil
    entry.gain = u and u.gain or nil
    entry.pct = u and u.pct or nil
    entry.total = u and u.total or nil
    if not entry.slotKey then
        local loc = rowType(id)
        local group = loc and Gear.GROUP[loc]
        entry.slotKey = group and SLOT_OF[group] or nil
    end
    waiting[#waiting + 1] = entry
    while (current and 1 or 0) + #waiting > TOAST_MAX do table.remove(waiting, 1) end
    showNext()
end

-- Test and page hook: the shown toast's item and the waiting ones.
function ns.BisToastState()
    local q = {}
    for i, e in ipairs(waiting) do q[i] = e.id end
    return { shown = current and current.id or nil, queue = q, frame = toastFrame }
end

local function inPvP()
    local kind
    if type(IsInInstance) == "function" then
        local _, t = IsInInstance()
        kind = ns.Plain(t)
    else
        local _, t = GetInstanceInfo()
        kind = ns.Plain(t)
    end
    return kind == "pvp" or kind == "arena"
end

-- One item seen dropping: a toast when it is a wish, else when it is an upgrade (bis.toastUpgrade);
-- never for an owned item, never twice in two minutes, never in battlegrounds and arenas.
local function consider(link, src)
    link = ns.Plain(link)
    local id = ns.ItemID(link)
    if not id then return end
    local t = time()
    if lastToast[id] and t - lastToast[id] < TOAST_AGAIN then return end
    if ns.BisOwned(id) then return end
    local c = ns.BisChar()
    local why
    if c and c.wish[id] then
        why = "wish"
    elseif ns.Get("bis.toastUpgrade") and Gear.Available() then   -- l10n-ok: setting key
        local u = ns.UpgradeOf(link)
        if u and u.up then why = "upgrade" end
    end
    if not why then return end
    lastToast[id] = t
    ns.BisToast(id, why, link, src)
end

-- Every trigger runs protected: an error goes to the error handler, never into the client's event.
local function guarded(fn)
    return function(...)
        if not ns.Get("bis.toast") or inPvP() then return end   -- l10n-ok: setting key
        local ok, err = pcall(fn, ...)
        if not ok then ns.ReportError(err) end
    end
end

local function plainString(v)
    v = ns.Plain(v)
    return (type(v) == "string" and v ~= "") and v or nil
end

ns.OnEvent("LOOT_OPENED", guarded(function()
    for slot = 1, (GetNumLootItems and ns.Plain(GetNumLootItems()) or 0) do
        local link = GetLootSlotLink and plainString(GetLootSlotLink(slot))
        if link then
            local src
            if type(ns.LootSourceName) == "function" then
                local ok, name = pcall(ns.LootSourceName, slot)
                src = ok and plainString(name) or nil
            end
            consider(link, (src and src ~= "?") and src or L["Lootfenster"])
        end
    end
end))

ns.OnEvent("START_LOOT_ROLL", guarded(function(rollID)
    rollID = ns.Plain(rollID)
    if type(rollID) ~= "number" or type(_G.GetLootRollItemLink) ~= "function" then return end
    local ok, link = pcall(_G.GetLootRollItemLink, rollID)
    if ok then consider(plainString(link), L["Würfeln"]) end
end))

-- item links in a chat line: coloured links, as the client sends them
local function eachLink(text, fn)
    for link in text:gmatch("|c%x%x%x%x%x%x%x%x|Hitem:.-|h|r") do fn(link) end
end

-- The loot lead's announcement: a numbered item line in the raid chat ("1. [Item] SR: ..."), or a
-- raid warning with an item link (a roll start). Secret text (a boss fight on Forever) is skipped.
local function onRaidChat(text)
    if ns.ChatLocked() then return end
    text = plainString(text)
    if not text or not text:find("^%d+%. |c") then return end
    eachLink(text, function(link) consider(link, L["Ansage"]) end)
end
ns.OnEvent("CHAT_MSG_RAID", guarded(onRaidChat))
ns.OnEvent("CHAT_MSG_RAID_LEADER", guarded(onRaidChat))
ns.OnEvent("CHAT_MSG_RAID_WARNING", guarded(function(text)
    if ns.ChatLocked() then return end
    text = plainString(text)
    if text then eachLink(text, function(link) consider(link, L["Ansage"]) end) end
end))

---------------------------------------------------------------------------
-- Page, settings, commands
---------------------------------------------------------------------------

local VIEW_OF = { goals = "goals", ziele = "goals", here = "here", hier = "here", wish = "wish", wunsch = "wish",
    wunschliste = "wish", guild = "guild", gilde = "guild", dungeons = "dungeons", dungeon = "dungeons", sim = "sim",
    simulation = "sim" }

-- Opens the gear page in a view ("goals", "here", "wish", "guild" or the German words) with a slot
-- chosen. The page reads settings.bis.view, settings.bis.slot and settings.bis.place; "here" starts
-- at the player's own place again. "dungeons" (a view until the planner got its own page) opens the
-- dungeons page.
function ns.ShowGear(view, slotKey)
    local v = VIEW_OF[tostring(view or ""):lower()]
    if v == "dungeons" then
        if ns.ShowPage then ns.ShowPage("dungeons") end
        return
    end
    local s = AmisiaDB and AmisiaDB.settings
    if s then
        s.bis = type(s.bis) == "table" and s.bis or {}
        s.bis.view = v or s.bis.view or "goals"
        if v == "here" then s.bis.place = nil end
        if slotKey then s.bis.slot = slotKey end
    end
    if ns.ShowPage then ns.ShowPage("gear") end
end

-- /amisia bis item <link>: the explanation in the own chat, with the client's raw stats.
function ns.BisItemReport(arg)
    arg = tostring(arg or "")
    local id = ns.ItemID(arg) or tonumber(arg)
    if not id then
        ns.msg(L["Aufruf: /amisia bis item <Item-Link>"])
        return
    end
    if not Gear.Available() then
        ns.msg(L["Für diesen Client gibt es keine Ausrüstungsdaten."])
        return
    end
    local item = arg:find("item:", 1, true) and arg or id
    for _, line in ipairs(ns.BisExplain(item)) do ns.msg(line) end
    for _, line in ipairs(ns.BisExplainModel(item)) do ns.msg(line) end
    -- what the client itself answered, so a stat name Amisia does not know shows up
    local raw = C_Item.GetItemStats(type(item) == "string" and item or ("item:" .. id))
    if type(raw) == "table" then
        local parts = {}
        for k, v in pairs(raw) do parts[#parts + 1] = (Gear.STAT[k] and "" or "|cffe0a344?|r") .. k .. "=" .. tostring(v) end
        table.sort(parts)
        ns.msg("Client: " .. table.concat(parts, " "))
    end
end

ns.RegisterSettings{ key = "bis", label = L["Ausrüstung und Wünsche"], order = 45, group = "gear", pages = { "gear" }, available = function() return Gear.Available() end, items = {   -- l10n-ok: command word / internal key
    { key = "bis.tooltip", type = "toggle", label = L["Tooltip-Zeile \"Upgrade für dich\""], default = true, tip = L["Der Item-Tooltip zeigt, um wie viel Prozent das Item besser ist als dein angelegtes."] },   -- l10n-ok: setting key
    { key = "bis.compare", type = "toggle", label = L["Mit angelegter Ausrüstung vergleichen (Prozent)"], default = true,   -- l10n-ok: setting key
      tip = L["Prozent und verglichenes Item im Tooltip, Markierung an Würfelfenstern und Questbelohnungen, Upgrade-Spalte im Roll-Fenster."] },
    { key = "bis.tooltipNone", type = "toggle", label = L["Auch \"Kein Upgrade\" im Tooltip zeigen"], default = false, tip = L["Der Tooltip sagt auch, wenn ein Item für dich kein Upgrade ist."] },   -- l10n-ok: setting key
    { key = "bis.minTotal", type = "slider", label = L["Upgrade erst ab (Prozent mehr Leistung)"], default = 0.3, min = 0, max = 5, step = 0.1,   -- l10n-ok: setting key
      fmt = function(v) return ns.Num(v, 1) end,
      expert = true, tip = L["Ein Item zählt erst als Upgrade, wenn es deinen Schaden, deine Heilung oder dein Überleben (je nach Spezialisierung) um mindestens so viel Prozent erhöht. Gilt für Tooltip, Tabelle und Hinweise."] },
    { key = "bis.otherSpecs", type = "toggle", label = L["Andere Spezialisierungen im Tooltip (Shift)"], default = true,   -- l10n-ok: setting key
      tip = L["Mit Shift zeigt der Tooltip, was das Item den anderen Spezialisierungen deiner Klasse bringt."] },
    { key = "bis.toast", type = "toggle", label = L["Hinweis, wenn ein Wunsch droppt"], default = true,   -- l10n-ok: setting key
      tip = L["Aus dem Lootfenster, beim Würfeln und aus der Loot-Ansage im Schlachtzugschat."] },
    { key = "bis.toastUpgrade", type = "toggle", label = L["Hinweis auch für andere Upgrades"], default = true, tip = L["Der Drop-Hinweis kommt auch für Upgrades, die nicht auf deiner Wunschliste stehen."] },   -- l10n-ok: setting key
    { key = "bis.toastSound", type = "toggle", label = L["Ton beim Wunsch-Hinweis"], default = true, tip = L["Spielt einen Ton zum Drop-Hinweis."] },   -- l10n-ok: setting key
    { key = "bis.wishAutoRemove", type = "toggle", label = L["Erhaltene Wünsche von der Liste nehmen"], default = true, tip = L["Bekommst du ein Item deiner Wunschliste, wird es von der Liste genommen."] },   -- l10n-ok: setting key
    { key = "bis.suffix", type = "choice", label = L["Zufallsboni"], default = "best",   -- l10n-ok: setting key
      values = { { "best", L["bester gesehener"] }, { "base", L["nur Grundwerte"] } },
      tip = L["Items mit Zufallsbonus (\"...des Adlers\") zählen mit dem besten Bonus, den Amisia an ihnen gesehen hat."] },
    { key = "bis.sets", type = "toggle", label = L["Setboni werten"], default = true, tip = L["Setboni zählen in der Wertung mit."] },   -- l10n-ok: setting key
    { key = "bis.picks", type = "toggle", label = L["BiS-Empfehlungen zeigen"], default = true,   -- l10n-ok: setting key
      tip = L["Von Hand gepflegte beste Items, die die Wertung allein verfehlt (Procs, Effekte), stehen in ihrem Slot zuerst."] },
    { key = "bis.hitCap", type = "toggle", label = L["Trefferwertung nur bis zur Grenze"], default = true,   -- l10n-ok: setting key
      tip = L["Trefferwertung über 6 % zählt nicht, gerechnet mit deinem Trefferwert aus dem Charakterfenster."] },
    { key = "bis.effortTie", type = "slider", label = L["Gleichstand für Aufwand (Prozent)"], default = 3, min = 0, max = 10, step = 1,   -- l10n-ok: setting key
      expert = true, tip = L["Liegen Optionen so nah an der besten, kommt die leichter zu bekommende zuerst."] },
    { key = "bis.prof", type = "choice", label = L["Hergestellte Items"], default = "all",   -- l10n-ok: setting key
      values = { { "all", L["alle"] }, { "mine", L["nur meine Berufe"] } }, tip = L["Welche hergestellten Items als Ziel in Frage kommen: alle oder nur die deiner eigenen Berufe."] },
    { key = "bis.kind", type = "choice", label = L["Gewichtung"], default = "Speedrun",   -- l10n-ok: setting key
      values = { { "Speedrun", "Speedrun" }, { "Hardcore", "Hardcore" } },
      tip = L["Speedrun bewertet Schaden höher, Hardcore Ausdauer und Rüstung."] },
    { key = "bis.upgradeDot", type = "toggle", label = L["Upgrade-Punkt in der Tabelle"], default = true,   -- l10n-ok: setting key
      tip = L["Grüner Punkt an Items, die besser sind als das, was du trägst."] },
    { key = "bis.slotClick", type = "toggle", label = L["Rechtsklick auf Slots im Charakterfenster"], default = true,   -- l10n-ok: setting key
      tip = L["Ein Rechtsklick auf einen Slot im Charakterfenster zeigt die besten Items für diesen Slot (bei Items mit Benutzen-Effekt Alt+Rechtsklick)."] },
}}

-- The item at the start of a command (a link, else an item id) and the rest.
local function splitItem(rest)
    local s, e = rest:find("|c%x%x%x%x%x%x%x%x|Hitem:.-|h|r")
    if not s then s, e = rest:find("|Hitem:.-|h.-|h") end
    if s then return rest:sub(s, e), rest:sub(e + 1):match("^%s*(.-)%s*$") end
    local id, more = rest:match("^(%d+)%s*(.-)%s*$")
    if id then return tonumber(id), more end
    return nil, rest
end

local PRIO_WORD = { hoch = 3, high = 3, mittel = 2, medium = 2, niedrig = 1, low = 1, ["3"] = 3, ["2"] = 2, ["1"] = 1 }

ns.RegisterSlash("wunsch", { en = "wish", args = L["[<Link> [hoch|mittel|niedrig] [Notiz] | weg <Link>]"],
    desc = L["Wunschliste: Item merken, ändern oder entfernen"],
    run = function(rest)
        rest = rest or ""
        if rest == "" then
            ns.ShowGear("wish")
            return
        end
        local word, after = rest:match("^(%S+)%s*(.*)$")
        word = word and word:lower()
        if word == "weg" or word == "remove" then   -- l10n-ok: command word / internal key
            local item = splitItem(after)
            local id = tonumber(item) or ns.ItemID(item)
            if id and ns.WishRemove(id) then
                ns.msg(L["%s von deiner Wunschliste entfernt."]:format(type(item) == "string" and item or itemName(id)))
            else
                ns.msg(L["Das steht nicht auf deiner Wunschliste."])
            end
            return
        end
        local item, more = splitItem(rest)
        if not item then
            ns.msg(L["Aufruf: /amisia wunsch <Item-Link> [hoch|mittel|niedrig] [Notiz]"])
            return
        end
        local prio
        local first, tail = more:match("^(%S+)%s*(.-)$")
        if first and PRIO_WORD[first:lower()] then prio, more = PRIO_WORD[first:lower()], tail end
        local e, why = ns.WishAdd(item, prio, more ~= "" and more or nil)
        if not e then
            ns.msg(why)
            return
        end
        local id = tonumber(item) or ns.ItemID(item)
        ns.msg(L["%s auf deiner Wunschliste (%s%s)."]:format(type(item) == "string" and item or itemName(id), PRIO_TEXT[e.prio],
            e.note ~= "" and (", " .. e.note) or ""))
    end })

local PLAN_WORD = { auto = "auto", ["2h"] = "2H", zweihand = "2H", dw = "DW", zwei = "DW", schild = "SHIELD",
    shield = "SHIELD" }

-- /amisia bis vergleich <Link> <Link>: the two items against each other in the own chat.
function ns.BisCompareReport(arg)
    local a, rest = splitItem(tostring(arg or ""))
    local b = rest and splitItem(rest)
    if not a or not b then
        ns.msg(L["Aufruf: /amisia bis vergleich <Item-Link> <Item-Link>"])
        return
    end
    if not Gear.Available() then
        ns.msg(L["Für diesen Client gibt es keine Ausrüstungsdaten."])
        return
    end
    local cmp, why = ns.BisCompare(a, b, nil, { L["Das erste"], L["das zweite"] })
    if not cmp then
        ns.msg(why)
        return
    end
    ns.msg(cmp.text)
    for i = 1, math.min(6, #cmp.lines) do ns.msg("  " .. cmp.lines[i]) end
end

-- /amisia bis gewichte: the weights of the own spec at the own level with their reason.
function ns.BisWeightsReport()
    if not Gear.Available() then
        ns.msg(L["Für diesen Client gibt es keine Ausrüstungsdaten."])
        return
    end
    local o = ns.BisOpts()
    local w = Gear.Weights(o.class, o.spec, o.kind, o.level)
    if not w then
        ns.msg(L["Keine Gewichtung."])
        return
    end
    for _, line in ipairs(ns.BisWhy(o)) do ns.msg(line) end
    local parts = {}
    for k, v in pairs(w) do
        if type(v) == "number" and v ~= 0 and not k:find("^SPDREF_") and k ~= "OHDPS" then
            parts[#parts + 1] = { k = k, v = v }
        end
    end
    table.sort(parts, function(x, y)
        if x.v ~= y.v then return x.v > y.v end
        return x.k < y.k
    end)
    local out = {}
    for _, p in ipairs(parts) do
        out[#out + 1] = ("%s %s"):format(Gear.STAT_LABELS[p.k] or p.k, Gear.Num(p.v, p.v < 1 and 2 or 1))
    end
    ns.msg(L["Gewichte (%s, Level %d): %s"]:format(o.kind, o.level, table.concat(out, ", ")))
    local melee, spell = ns.BisOwnHit()
    if melee or spell then
        ns.msg(L["Treffer laut Charakterfenster: %s %% (Waffen), %s %% (Zauber), Grenze %d %%"]:format(
            melee and Gear.Num(melee, 1) or "?", spell and Gear.Num(spell, 1) or "?", ns.BIS_HIT_CAP))
    else
        ns.msg(L["Trefferwertung zählt ohne Obergrenze (der Client nennt den eigenen Trefferwert nicht)."])
    end
end

ns.RegisterSlash("bis", { aliases = { "ziele", "ausruestung" },   -- l10n-ok: command word / internal key
    args = L["[hier | item <Link> | aus <Link> | zurueck | vergleich <Link> <Link> | gewichte | plan <auto|2h|dw|schild> | sim | gross]"],
    desc = L["beste Ausrüstung für deinen Charakter"],
    run = function(rest)
        local sub, arg = rest:match("^(%S+)%s*(.*)$")
        sub = sub and sub:lower()
        if sub == "item" then ns.BisItemReport(arg) return end
        if not Gear.Available() then
            ns.msg(L["Für diesen Client gibt es keine Ausrüstungsdaten."])
            return
        end
        if not sub then
            ns.ShowGear("goals")
        elseif sub == "hier" or sub == "here" then   -- l10n-ok: command word / internal key
            ns.ShowGear("here")
        elseif sub == "aus" or sub == "exclude" then   -- l10n-ok: command word / internal key
            local ok, why = ns.BisExclude("item", arg)
            if ok then
                ns.msg(L["%s ausgeschlossen. /amisia bis zurueck hebt alle Ausschlüsse auf."]:format(ns.ItemID(arg) and arg or ("Item " .. arg)))
            else
                ns.msg(why)
            end
        elseif sub == "zurueck" or sub == "reset" then
            local n = ns.BisClearExcludes()
            ns.msg(n == 1 and L["1 Ausschluss aufgehoben."] or L["%d Ausschlüsse aufgehoben."]:format(n))
        elseif sub == "vergleich" or sub == "compare" then
            ns.BisCompareReport(arg)
        elseif sub == "gewichte" or sub == "weights" then
            ns.BisWeightsReport()
        elseif sub == "plan" then
            local want = PLAN_WORD[(arg or ""):lower()]
            if not want then
                ns.msg(L["Aufruf: /amisia bis plan auto|2h|dw|schild"])
                return
            end
            local ok, why = ns.BisSetPlan(want)
            ns.msg(ok and L["Waffenplan: %s."]:format(ns.BIS_PLANS[want]) or why)
        elseif sub == "sim" or sub == "simulation" then
            ns.ShowGear("sim")
        elseif sub == "gross" or sub == "gro\195\159" or sub == "big" then   -- l10n-ok: typed words
            if ns.ShowGoalsFrame then ns.ShowGoalsFrame() end
        else
            ns.msg(L["Aufruf: /amisia bis [hier | item <Link> | aus <Link> | zurueck | vergleich <Link> <Link> | gewichte | plan <auto|2h|dw|schild> | sim | gross]"])
        end
    end })
