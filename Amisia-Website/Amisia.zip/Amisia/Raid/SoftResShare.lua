-- Amisia soft-reserves shared with the raid (F-107, spec 2026-10-17 part A, D-53). An officer in the
-- officer view with a list he took himself (AmisiaDB.softres without "from") announces it: "SV <import
-- epoch> <hash> <reservations>" into the raid 10 s after a change, every 240 s and soon after someone
-- joins. A client with another state asks by whisper "SQ <epoch> <own hash>"; the officer answers
-- with the whole list as blob "SR" (key "<list date>:<epoch>"; three or more askers within 2 s: one
-- send into the raid). Only a verified officer of the own guild in the own group is listened to, a
-- list is taken only when asked for and checked whole, and its hash must be the one announced.
-- Raiders and officers without an own list take it (AmisiaDB.softres with "from" = the officer);
-- an officer with an own list in the officer view gets it only as an offer (memory, until /reload)
-- and takes it with "Liste übernehmen" on the page. The newest import wins (equal: the smaller name).
-- "SV <epoch> - 0" after clearing: who holds that officer's list of that epoch clears it too.
local ADDON, ns = ...
ns.Load(function()
local L = ns.L

local SV_EVERY = 240           -- an officer repeats his state this often
local SV_GAP = 10              -- and not more often than this after a change
local ANSWER_AFTER = 2         -- requests within this go out together
local ANSWER_RAID = 3          -- this many requesters: one send into the raid
local ANSWER_EVERY = 30        -- one blob per asker and list state this often
local MAX_RAIDERS, MAX_ITEMS, MAX_HARD = 100, 2000, 200
local MAX_NAME, MAX_NOTE, MAX_ID = 48, 60, 9999999

local lastSV                   -- { at, h, t }: the last own announcement
local asks = {}
local answered = {}            -- asker -> { h, t }: the last blob sent to him
local wanted = {}              -- officer name -> { at, h }: the list asked for
local offer                    -- { from, at, h, sr }: a newer list for an officer with his own
local stats = { sent = 0, taken = 0, offered = 0, refused = 0, cleared = 0 }

local function now() return GetTime() end
local function shareOn() return ns.Get("softres.share") and true or false end

local report = ns.ReportError

local homeRaid = ns.HomeRaid

-- The list this client may announce: its own (not one received), in the officer view.
local function ownList()
    local sr = AmisiaDB and AmisiaDB.softres
    if not sr or sr.from or not ns.IsOfficerView() then return nil end
    if (tonumber(sr.count) or 0) == 0 and not (type(sr.hard) == "table" and next(sr.hard)) then return nil end
    if type(sr.at) ~= "number" then sr.at = ns.ServerTime() end
    return sr
end

---------------------------------------------------------------------------
-- The list as it travels: names sorted, a name's items sorted with doubles repeated
---------------------------------------------------------------------------
local function sortedNames(sr)
    local set, out = {}, {}
    for _, names in pairs(sr.byItem or {}) do
        for _, name in ipairs(names) do
            if not set[name] then set[name] = true; out[#out + 1] = name end
        end
    end
    table.sort(out)
    return out
end

-- { v = 1, at, d, sid, r = { { n, c, i, o, p } }, h = { { id, to, note } } } of a stored list.
local function payloadOf(sr)
    local items = {}
    for item, names in pairs(sr.byItem or {}) do
        for _, name in ipairs(names) do
            items[name] = items[name] or {}
            for _ = 1, ns.SoftResTimes(sr, item, name) do items[name][#items[name] + 1] = item end
        end
    end
    local r = {}
    for _, name in ipairs(sortedNames(sr)) do
        table.sort(items[name])
        -- what a receiver would refuse stays home: a class that names none, a note not clean, a bad +1
        local c, o, p = (sr.classes or {})[name], (sr.notes or {})[name], (sr.plus or {})[name]
        if type(c) ~= "string" or ns.SoftResClean(c, 20) ~= c or not ns.SoftResClassToken(c) then c = nil end
        if type(o) ~= "string" or ns.SoftResClean(o, MAX_NOTE) ~= o then o = nil end
        if type(p) ~= "number" or p % 1 ~= 0 or p < 1 or p > 99 then p = nil end
        r[#r + 1] = { n = name, c = c, i = items[name], o = o, p = p }
    end
    local h, ids = {}, {}
    for id in pairs(type(sr.hard) == "table" and sr.hard or {}) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        local to, note = sr.hard[id].to, sr.hard[id].note
        to = (type(to) == "string" and ns.SoftResClean(to, MAX_NAME) == to) and to or ""
        note = (type(note) == "string" and ns.SoftResClean(note, MAX_NOTE) == note) and note or ""
        h[#h + 1] = { id, to, note }
    end
    return { v = 1, at = sr.at, d = sr.date, sid = sr.sid, r = r, h = h }
end

-- The hash of a list: what travels, in one text.
local function hashOf(sr)
    local p = payloadOf(sr)
    local lines = { tostring(p.d or "") .. "|" .. tostring(p.sid or "") }
    for _, e in ipairs(p.r) do
        local ids = {}
        for k, id in ipairs(e.i) do ids[k] = tostring(id) end
        lines[#lines + 1] = table.concat({ e.n, e.c or "", table.concat(ids, ","), e.o or "", tostring(e.p or "") }, "|")
    end
    for _, x in ipairs(p.h) do lines[#lines + 1] = ("H|%d|%s|%s"):format(x[1], x[2], x[3]) end
    return ns.Checksum(table.concat(lines, "\n"))
end
ns.SoftResHash = hashOf

local function count(sr) return tonumber(sr.count) or 0 end

-- A received list checked whole, as a stored list; nil when anything is off.
local function checkList(tbl, at)
    if type(tbl) ~= "table" or tbl.v ~= 1 or tbl.at ~= at or type(tbl.r) ~= "table" or type(tbl.h) ~= "table" then return nil end
    if type(tbl.d) ~= "string" or not tbl.d:match("^%d%d%d%d%-%d%d%-%d%d$") then return nil end
    if tbl.sid ~= nil and (type(tbl.sid) ~= "string" or #tbl.sid > 40 or not tbl.sid:match("^[%w%-_]+$")) then return nil end
    local function clean(s, max) return type(s) == "string" and ns.SoftResClean(s, max) == s end
    local sr = { version = 3, date = tbl.d, raw = "", byItem = {}, times = {}, renamed = {}, reminded = {}, src = "shared",
                 sid = tbl.sid, at = at, notes = {}, classes = {}, plus = {}, hard = {}, count = 0 }
    local seen, total = {}, 0
    if #tbl.r > MAX_RAIDERS or #tbl.h > MAX_HARD then return nil end
    for k, e in ipairs(tbl.r) do
        if type(e) ~= "table" or not clean(e.n, MAX_NAME) or e.n:find("[%d,;:]") or seen[e.n] then return nil end
        if k > 1 and tbl.r[k - 1].n >= e.n then return nil end
        seen[e.n] = true
        if e.c ~= nil and (not clean(e.c, 20) or not ns.SoftResClassToken(e.c)) then return nil end
        if e.o ~= nil and not clean(e.o, MAX_NOTE) then return nil end
        if e.p ~= nil and (type(e.p) ~= "number" or e.p % 1 ~= 0 or e.p < 1 or e.p > 99) then return nil end
        if type(e.i) ~= "table" or #e.i == 0 then return nil end
        local prev = 0
        for _, id in ipairs(e.i) do
            total = total + 1
            if total > MAX_ITEMS or type(id) ~= "number" or id % 1 ~= 0 or id < 1 or id > MAX_ID or id < prev then return nil end
            if id == prev then
                sr.times[id] = sr.times[id] or {}
                sr.times[id][e.n] = (sr.times[id][e.n] or 1) + 1
            else
                sr.byItem[id] = sr.byItem[id] or {}
                sr.byItem[id][#sr.byItem[id] + 1] = e.n
            end
            prev = id
        end
        sr.classes[e.n], sr.notes[e.n], sr.plus[e.n] = e.c, e.o, e.p
    end
    local prevHard = 0
    for _, x in ipairs(tbl.h) do
        if type(x) ~= "table" then return nil end
        local id, to, note = x[1], x[2], x[3]
        if type(id) ~= "number" or id % 1 ~= 0 or id <= prevHard or id > MAX_ID then return nil end
        if not (to == "" or clean(to, MAX_NAME)) or not (note == "" or clean(note, MAX_NOTE)) then return nil end
        sr.hard[id] = { to = to, note = note }
        prevHard = id
    end
    for _, names in pairs(sr.byItem) do table.sort(names) end
    sr.count = total
    return sr
end

---------------------------------------------------------------------------
-- Sending
---------------------------------------------------------------------------
local refusedHash             -- the hash of an own list a receiver would refuse (said once)

-- Announces the own list. The receivers keep 8 s between two SV of a sender (Comm's KIND_GAP): a
-- new list or a clear waits for SV_GAP after the last one, so none is dropped there.
local function sendSV()
    if not shareOn() or not homeRaid() then lastSV = nil return end
    local sr = ownList()
    if not sr then return end
    local h = hashOf(sr)
    local t = now()
    if lastSV then
        if t - lastSV.t < SV_GAP then return end
        if lastSV.at == sr.at and lastSV.h == h and t - lastSV.t < SV_EVERY then return end
    end
    if refusedHash == h then return end
    if not checkList(payloadOf(sr), sr.at) then
        -- an entry the receivers would refuse (a list of an older version): nothing goes out
        refusedHash = h
        ns.msg(L["Soft-Reserves: diese Liste lässt sich nicht teilen (ungültige Einträge). Bitte neu einfügen."])
        return
    end
    if ns.CommSend("SV", { tostring(sr.at), h, tostring(count(sr)) }, "RAID", nil, { ttl = 60, key = "SV" }) then
        lastSV = { at = sr.at, h = h, t = t }
    end
end

-- The batched answers (PointsSync and LootPrio use them too): ns.AnswerBatch(send) gives ask(), which
-- runs send() ANSWER_AFTER s after the first request, so requests within it go out together.
function ns.AnswerBatch(send)
    local waiting = false
    return function()
        if waiting then return end
        waiting = true
        C_Timer.After(ANSWER_AFTER, function()
            waiting = false
            local ok, err = pcall(send)
            if not ok then ns.ReportError(err) end
        end)
    end
end

-- Answers the askers who with send(chan, target, opts): ANSWER_RAID or more get one send into the
-- raid, the others a whisper each (queue key "<kind>:<sender>").
function ns.AnswerAskers(who, kind, send)
    if #who >= ANSWER_RAID then
        send("RAID", nil, { ttl = 600, low = true })
        return
    end
    for _, s in ipairs(who) do send("WHISPER", s, { ttl = 600, key = kind .. ":" .. s, low = true }) end
end

local function sendList()
    local sr = ownList()
    local who = {}
    for s, at in pairs(asks) do
        -- an asker of a list replaced since he asked waits for the next SV (he would refuse it)
        if sr and at == sr.at then who[#who + 1] = s end
    end
    asks = {}
    if not sr or not shareOn() then return end
    -- one answer per asker and state in ANSWER_EVERY (an asker repeating SQ gets no blob each time)
    local h, t = hashOf(sr), now()
    local fresh = {}
    for _, w in ipairs(who) do
        local last = answered[w]
        if not (last and last.h == h and t - last.t < ANSWER_EVERY) then
            fresh[#fresh + 1] = w
            answered[w] = { h = h, t = t }
        end
    end
    who = fresh
    if #who == 0 then return end
    local key = ("%s:%d"):format(sr.date, sr.at)
    local tbl = payloadOf(sr)
    local function send(chan, target, opts)
        local ok, why = ns.CommSendBlob("SR", key, tbl, chan, target, opts)
        if ok then
            stats.sent = stats.sent + 1
        elseif why == L["Daten zu groß."] then
            ns.msg(L["Soft-Reserves: Liste zu groß zum Teilen."])
        end
    end
    ns.AnswerAskers(who, "SR", send)
end

local askList = ns.AnswerBatch(sendList)

-- After an import: announce at once (the window's "Übernehmen", "/amisia sr <code>"). Whether the
-- list goes to the raid.
function ns.SoftResShareNow()
    if not shareOn() or not homeRaid() or not ownList() then return false end
    if lastSV then lastSV.h = nil end
    local ok, err = pcall(sendSV)
    if not ok then report(err) end
    return true
end

-- The own list was cleared: the raid hears it once ("-"), so the copies of it go too (after SV_GAP
-- since the last SV, which the receivers' gap would drop otherwise).
local clearGen = 0
function ns.SoftResShareCleared(sr)
    offer = nil
    if not sr or sr.from or not lastSV or lastSV.at ~= sr.at or not homeRaid() then return end
    clearGen = clearGen + 1
    local gen, at = clearGen, sr.at
    local function send()
        if gen ~= clearGen or not homeRaid() then return end
        local wait = lastSV and (SV_GAP - (now() - lastSV.t)) or 0
        if wait > 0 then C_Timer.After(wait + 0.1, send) return end
        if ns.CommSend("SV", { tostring(at), "-", "0" }, "RAID", nil, { ttl = 60, key = "SV" }) then
            lastSV = { at = at, h = "-", t = now() }
        end
    end
    send()
end

---------------------------------------------------------------------------
-- Receiving
---------------------------------------------------------------------------
-- Whether a list (from, at) beats the one held (sr): newer wins, equal by the smaller name.
local function beats(from, at, sr)
    if not sr then return true end
    local held = tonumber(sr.at) or 0
    if at ~= held then return at > held end
    return from < (sr.from or "")
end

-- Whether this client takes lists only as offers (an officer with his own list).
-- An officer keeps his own list in the raider view too (only a player without the officer rank, by
-- a roster that can be read, takes a newer list over an own one).
local function offerOnly()
    local sr = AmisiaDB and AmisiaDB.softres
    if sr == nil or sr.from ~= nil then return false end
    if ns.IsOfficerView() then return true end
    return ns.IsVerifiedOfficer(ns.UnitFullName("player")) ~= false
end

-- The offer, while it still beats the own list (an own import after it makes it old).
local function liveOffer()
    if not offer or not offerOnly() then return nil end
    if not beats(offer.from, offer.at, AmisiaDB.softres) then offer = nil return nil end
    return offer
end

ns.CommOn("SV", function(sender, f, chan)
    if chan ~= "RAID" then return end
    local name = ns.TrustName(sender)
    if not name then return end
    local at, h = tonumber(f[1]), f[2]
    ns.TrustWait(name, "officer", function(ok)
        if not ok or not ns.InMyGroup(name) then return end
        local sr = AmisiaDB and AmisiaDB.softres
        if h == "-" then
            if offer and offer.from == name and offer.at == at then offer = nil; ns.Refresh() end
            if sr and sr.from == name and sr.at == at then
                AmisiaDB.softres = nil
                stats.cleared = stats.cleared + 1
                ns.MarkSoftResLoot()
                if ns.SoftResImportChanged then ns.SoftResImportChanged() end
                if ns.Refresh then ns.Refresh() end
            end
            return
        end
        if sr and sr.from == name and sr.at == at and sr.hash == h then return end
        if offerOnly() then
            if offer and offer.from == name and offer.at == at and offer.h == h then return end
            if not beats(name, at, sr) or (offer and offer.from ~= name and not beats(name, at, { at = offer.at, from = offer.from })) then return end
        elseif sr and not (sr.from == name and sr.at == at) and not beats(name, at, sr) then
            return
        end
        wanted[name] = { at = at, h = h }
        ns.CommSend("SQ", { tostring(at), (sr and sr.hash) or "-" }, "WHISPER", sender,
            { jitter = 2.75, ttl = 60, key = "SQ:" .. name })
    end)
end)

ns.CommOn("SQ", function(sender, f, chan)
    if chan ~= "WHISPER" or not shareOn() then return end
    local name = ns.TrustName(sender)
    if not name then return end
    ns.TrustWait(name, "member", function(ok)
        if not ok or not ns.InMyGroup(name) then return end
        local sr = ownList()
        if not sr or sr.at ~= tonumber(f[1]) then return end
        asks[sender] = sr.at
        askList()
    end)
end)

ns.CommOnBlob("SR", function(sender, tbl, chan, key)
    local name = ns.TrustName(sender)
    if not name then return end
    ns.TrustWait(name, "officer", function(ok)
        local want = wanted[name]
        if not ok or not ns.InMyGroup(name) or not want then
            stats.refused = stats.refused + 1
            return
        end
        local sr = checkList(tbl, want.at)
        if not sr or key ~= ("%s:%d"):format(sr.date, sr.at) or hashOf(sr) ~= want.h then
            stats.refused = stats.refused + 1
            return
        end
        wanted[name] = nil
        sr.from, sr.hash = name, want.h
        if offerOnly() then
            offer = { from = name, at = sr.at, h = want.h, sr = sr }
            stats.offered = stats.offered + 1
            ns.msg(L["Soft-Reserves: %s hat eine neuere Liste geteilt (%d Reservierungen). Auf der Seite Soft-Reserves \"Liste übernehmen\"."]:format(name, sr.count))
        else
            AmisiaDB.softres = sr
            stats.taken = stats.taken + 1
            ns.MarkSoftResLoot()
            if ns.SoftResImportChanged then ns.SoftResImportChanged() end
        end
        if ns.Refresh then ns.Refresh() end
    end)
end)

-- The offered list for the page: { from, at, n }, or nil.
function ns.SoftResOffer()
    local o = liveOffer()
    return o and { from = o.from, at = o.at, n = o.sr.count } or nil
end

-- Takes the offered list in place of the own one (the page's "Liste übernehmen").
function ns.TakeSoftResOffer()
    if not liveOffer() then return false end
    AmisiaDB.softres = offer.sr
    offer = nil
    lastSV = nil
    stats.taken = stats.taken + 1
    ns.MarkSoftResLoot()
    if ns.SoftResImportChanged then ns.SoftResImportChanged() end
    if ns.Refresh then ns.Refresh() end
    return true
end

function ns.SoftResShareStats() return stats end

-- someone joined: the next tick announces again (within SV_GAP)
local members = 0
ns.OnEvent("GROUP_ROSTER_UPDATE", function()
    local n = GetNumGroupMembers() or 0
    if n > members and lastSV then lastSV.h = nil end
    members = n
end)

C_Timer.NewTicker(5, ns.Perf.Wrap("Ticker SoftResShare", function()
    local ok, err = pcall(sendSV)
    if not ok then report(err) end
end))
end)
