-- Amisia awards: the book of what the master looter hands out, and how a hand-out gets in.
--
-- The book: every award has a fixed id (12 hex characters, unique in its raid) so the ledger
-- recognises the same award on a second import. A deleted award moves to s.gone as a tombstone
-- with deleted = epoch, so s.awards only ever holds living awards and the export can tell the
-- site what vanished. Every change fires DATA_CHANGED and lands on an undo stack of 20 steps that
-- lives until logout.
--
-- The hand-out: remembered when GiveMasterLoot runs and written as an award once the client
-- confirms it: the loot chat line for that player and item, or the loot slot being emptied.
-- Without confirmation it is dropped after a few seconds. Every loot slot keeps its own open
-- hand-out, so a second one before the first is confirmed does not push the first out. A hand-out
-- to the bank or disenchant character of the settings is written with to = "bank" or "de".
local ADDON, ns = ...
ns.Load(function()
local L = ns.L

local GetItemInfo = C_Item.GetItemInfo

local VALID_KIND = { MS = true, OS = true, SR = true, ["-"] = true }
local VALID_TO = { player = true, bank = true, de = true }
local NOTE_MAX = 60
local UNDO_MAX = 20
local GONE = L["Vergabe nicht mehr vorhanden."]

local undo = {}   -- { op = "add"|"edit"|"delete"|"restore"|"rename", s, id, before = copy, item, name, ... }

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function copy(a)
    local c = {}
    for k, v in pairs(a) do c[k] = v end
    return c
end

-- Puts the fields of src into a, dropping what src does not have.
local function assign(a, src)
    for k in pairs(a) do a[k] = nil end
    for k, v in pairs(src) do a[k] = v end
end

-- A note without bars and line breaks, trimmed and cut to max bytes (default NOTE_MAX); the core's
-- (Core/Registry.lua, F-202: the gear module's wishes use it too).
local function cleanNote(text, max)
    return ns.CleanNote(text, tonumber(max) or NOTE_MAX)
end

local function idUsed(s, id)
    for _, a in ipairs(s.awards or {}) do if a.id == id then return true end end
    for _, a in ipairs(s.gone or {}) do if a.id == id then return true end end
    return false
end

-- A new id: the time and a random part, rolled again while the raid already has it.
local function newId(s, t)
    local id
    repeat
        id = ("%08x%04x"):format(t % 4294967296, math.random(0, 65535))
    until not idUsed(s, id)
    return id
end

-- The id of an award from 1.4: the same raid, name, item and time give the same id on every load.
local function legacyId(s, a)
    local key = table.concat({ tostring(s.id), tostring(a.name), tostring(a.item), tostring(a.t) }, "\t")
    local id, n = ns.Checksum(key):sub(1, 12), 0
    while idUsed(s, id) do
        n = n + 1
        id = ns.Checksum(key .. "\t" .. n):sub(1, 12)
    end
    return id
end

local function alive(s)
    for _, o in ipairs(ns.Sessions()) do
        if o == s then return true end
    end
    return false
end

-- Attendance for an award: a name already in the raid's members, or (in the running recording)
-- in the group, is noted; any other name is left alone, so a typo does not invent a raider.
local function noteWinner(s, name, t)
    if s.members[name] or (s == ns.Active() and ns.InGroup(name)) then
        ns.NoteMember(s, name, nil, t)
        return true
    end
    return false
end

---------------------------------------------------------------------------
-- Quiet changes and the sync report
---------------------------------------------------------------------------
local quiet = 0   -- > 0 inside ns.AwardsQuiet

-- Runs fn(...) for a change applied on behalf of someone else (the sync): no undo step, no note in
-- the chat, no report to the sync. Returns what fn returns; an error is raised after the count is
-- set back.
function ns.AwardsQuiet(fn, ...)
    quiet = quiet + 1
    local res = { pcall(fn, ...) }
    quiet = quiet - 1
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2, table.maxn(res))
end

function ns.AwardsIsQuiet() return quiet > 0 end

-- Reports a change to the sync (Sync.lua decides what it means).
local function report(op, s, info)
    if quiet == 0 and ns.SyncNote then ns.SyncNote(op, s, info) end
end

local dropPlus -- the plus-one tally of the frame (below) is out of date

local function push(entry)
    dropPlus()
    if quiet > 0 then return end
    undo[#undo + 1] = entry
    while #undo > UNDO_MAX do table.remove(undo, 1) end
end

local function changed()
    dropPlus()
    ns.Fire("DATA_CHANGED")
end

---------------------------------------------------------------------------
-- The book
---------------------------------------------------------------------------
-- The award with this id: the award, its index and whether it lies among the tombstones.
function ns.FindAward(s, id)
    if not s or not id then return nil end
    for i, a in ipairs(s.awards or {}) do
        if a.id == id then return a, i, false end
    end
    for i, a in ipairs(s.gone or {}) do
        if a.id == id then return a, i, true end
    end
    return nil
end

-- A new award in raid s: { name, item, kind, src, t, to, note, manual, id }. A bank or disenchant
-- award has kind "-" and, without a receiver, the name "-". id (12 hex, only the sync gives one)
-- is taken when the raid does not have it yet; otherwise a new one is rolled.
function ns.AddAwardTo(s, f)
    if type(s) ~= "table" or type(s.awards) ~= "table" then
        return nil, L["Keine Aufnahme: Vergaben werden nur in einer Raidinstanz mit Raidgruppe gespeichert."]
    end
    f = f or {}
    local item = tonumber(f.item)
    local to = VALID_TO[f.to] and f.to or "player"
    local name = f.name
    if to ~= "player" and (type(name) ~= "string" or name == "") then name = "-" end
    if type(name) ~= "string" or name == "" or not item then return nil, L["Name oder Item fehlt."] end
    local t = tonumber(f.t) or time()
    local id = f.id
    if type(id) ~= "string" or #id ~= 12 or not id:match("^%x+$") or idUsed(s, id) then id = newId(s, t) end
    local a = {
        id = id, name = name, item = item, t = t,
        kind = (to == "player" and VALID_KIND[f.kind]) and f.kind or "-",
        src = (type(f.src) == "string" and f.src ~= "") and f.src or "?",
        to = to, note = cleanNote(f.note), manual = f.manual and true or nil,
    }
    s.gone = s.gone or {}
    s.awards[#s.awards + 1] = a
    if to == "player" and not noteWinner(s, name, t) and s == ns.Active() and quiet == 0 then
        ns.msg(L["Hinweis: %s ist nicht in der Gruppe. Die Vergabe ist gespeichert, aber ohne Anwesenheit."]:format(name))
    end
    if not ns.KnownItem(item) then
        local _, ilink, q = GetItemInfo(item)
        ns.RememberItem(item, ilink, q)
    end
    -- only the running recording moves on; an old raid must not become resumable
    if s == ns.Active() then
        s.last = t
        -- a trade good handed out in the raid joins the material list
        if ns.LearnMat then
            local _, ilink, q = GetItemInfo(item)
            ns.LearnMat(item, ilink, q)
        end
    end
    push({ op = "add", s = s, id = a.id })
    changed()
    report("add", s, { a = a })
    return a
end

-- Changes { name, kind, note, to } of a living award. A new name keeps the first one in orig;
-- bank or disenchant means kind "-".
function ns.EditAward(s, id, f)
    local a, _, inGone = ns.FindAward(s, id)
    if not a or inGone then return nil, GONE end
    f = f or {}
    local before = copy(a)
    if f.to ~= nil and VALID_TO[f.to] then a.to = f.to end
    if a.to ~= "player" then
        a.kind = "-"
    elseif f.kind ~= nil and VALID_KIND[f.kind] then
        a.kind = f.kind
    end
    if f.name ~= nil then
        local name = ns.FullName(f.name)
        -- the bank or the disenchanter may go without a receiver, written as "-"
        if not name and a.to ~= "player" then name = "-" end
        if not name then
            assign(a, before)
            return nil, L["Name oder Item fehlt."]
        end
        if name ~= a.name then
            a.orig = a.orig or a.name
            a.name = name
            if a.to == "player" then noteWinner(s, name, a.t) end
        end
    end
    -- a player needs a name: back from the bank without a receiver is refused
    if a.to == "player" and a.name == "-" then
        assign(a, before)
        return nil, L["Name oder Item fehlt."]
    end
    if f.note ~= nil then a.note = cleanNote(f.note) end
    local same = true
    for k, v in pairs(a) do if before[k] ~= v then same = false end end
    for k, v in pairs(before) do if a[k] ~= v then same = false end end
    if same then return a end
    a.edited = time()
    push({ op = "edit", s = s, id = id, before = before })
    changed()
    -- the changed fields and what they were (false: no value), so the keeper can tell a conflict
    local fields, was = {}, {}
    for _, k in ipairs({ "name", "kind", "note", "to" }) do
        if a[k] ~= before[k] then
            -- (not "x == nil and false or x": that gives nil for nil)
            if a[k] == nil then fields[k] = false else fields[k] = a[k] end
            if before[k] == nil then was[k] = false else was[k] = before[k] end
        end
    end
    report("edit", s, { id = id, fields = fields, was = was })
    return a
end

-- Takes a living award out of the raid; it stays as a tombstone in s.gone.
local function remove(s, id)
    local a, i, inGone = ns.FindAward(s, id)
    if not a or inGone then return nil end
    table.remove(s.awards, i)
    a.deleted = time()
    s.gone = s.gone or {}
    s.gone[#s.gone + 1] = a
    return a
end

-- Brings a tombstone back into s.awards, in order of its time.
local function revive(s, id)
    local a, i, inGone = ns.FindAward(s, id)
    if not a or not inGone then return nil end
    table.remove(s.gone, i)
    a.deleted = nil
    local pos = #s.awards + 1
    for j, o in ipairs(s.awards) do
        if (o.t or 0) > (a.t or 0) then pos = j break end
    end
    table.insert(s.awards, pos, a)
    return a
end

function ns.DeleteAward(s, id)
    local a = remove(s, id)
    if not a then return nil, GONE end
    push({ op = "delete", s = s, id = id })
    changed()
    report("delete", s, { id = id })
    return a
end

function ns.RestoreAward(s, id)
    local a = revive(s, id)
    if not a then return nil, GONE end
    push({ op = "restore", s = s, id = id })
    changed()
    report("restore", s, { id = id })
    return a
end

-- Renames every living award of raid s from one name to another, as one undo step.
function ns.RenameAwards(s, from, to)
    to = ns.FullName(to)
    if not s or not to or type(from) ~= "string" or from == to then return 0 end
    local before, t = {}, time()
    for _, a in ipairs(s.awards or {}) do
        if a.name == from then
            before[#before + 1] = copy(a)
            a.orig = a.orig or a.name
            a.name = to
            a.edited = t
        end
    end
    if #before == 0 then return 0 end
    noteWinner(s, to, t)
    push({ op = "rename", s = s, before = before, from = from, to = to })
    changed()
    local ids = {}
    for i, b in ipairs(before) do ids[i] = b.id end
    report("rename", s, { from = from, to = to, ids = ids })
    return #before
end

-- Members of raid s that may be meant by a name not among them: the same character by
-- ns.SameName or the same first name, sorted. A name that is a member needs no suggestion.
function ns.NameSuggestions(s, name)
    local out = {}
    name = ns.FullName(name)
    if not s or not name then return out end
    local lower = name:lower()
    for m in pairs(s.members or {}) do
        if m:lower() == lower then return {} end
    end
    local first = name:match("^(%S+)"):lower()
    for m in pairs(s.members or {}) do
        if ns.SameName(m, name) or m:match("^(%S+)"):lower() == first then out[#out + 1] = m end
    end
    table.sort(out)
    return out
end

-- "bank" or "de" when the name is the bank or disenchant character of the settings.
function ns.IsSpecialName(name)
    if type(name) ~= "string" or name == "" then return nil end
    local bank, de = ns.Get("awards.bankName"), ns.Get("awards.deName")
    if type(bank) == "string" and bank ~= "" and ns.SameName(name, bank) then return "bank" end
    if type(de) == "string" and de ~= "" and ns.SameName(name, de) then return "de" end
    return nil
end

---------------------------------------------------------------------------
-- Undo
---------------------------------------------------------------------------
local VERB = { add = L["Hinzufügen"], edit = L["Ändern"], delete = L["Löschen"], restore = L["Wiederherstellen"] }

local function label(e)
    if e.op == "rename" then
        return L["Umbenennen von %s in %s (%d)"]:format(e.from, e.to, #e.before)
    end
    local a = ns.FindAward(e.s, e.id)
    local b = a or (e.before) or {}
    return L["%s von %s an %s"]:format(VERB[e.op] or e.op, ns.ItemName(b.item), tostring(b.name or "?"))
end

-- Whether step e can still be taken back: its raid exists and its award is where the step left it.
local function doable(e)
    if not alive(e.s) then return false end
    if e.op == "rename" then
        for _, b in ipairs(e.before) do
            local a, _, inGone = ns.FindAward(e.s, b.id)
            if a and not inGone then return true end
        end
        return false
    end
    local a, _, inGone = ns.FindAward(e.s, e.id)
    if not a then return false end
    if e.op == "delete" then return inGone end
    return not inGone
end

-- What the next undo would take back, or nil. Steps undo would skip are skipped here as well.
function ns.UndoLabel()
    for i = #undo, 1, -1 do
        if doable(undo[i]) then return label(undo[i]) end
    end
    return nil
end

-- Takes back the last change. A step whose raid or award no longer exists is skipped.
function ns.UndoAward()
    while #undo > 0 do
        local e = table.remove(undo)
        if doable(e) then
            local text = label(e)
            local done
            -- every step goes to the sync as the change it makes
            local reports = {}
            local function all(a)
                local note = a.note
                if note == nil then note = false end
                return { name = a.name, kind = a.kind, note = note, to = a.to }
            end
            if e.op == "add" or e.op == "restore" then
                done = remove(e.s, e.id)
                if done then reports[1] = { "delete", { id = e.id } } end
            elseif e.op == "delete" then
                done = revive(e.s, e.id)
                if done then reports[1] = { "restore", { id = e.id } } end
            elseif e.op == "edit" then
                local a, _, inGone = ns.FindAward(e.s, e.id)
                if a and not inGone then
                    local was = all(a)
                    -- the revision of the sync is no part of the step taken back
                    local v = a.v
                    assign(a, e.before)
                    a.v = v
                    -- stamped anew, so the site takes the reverted award as the newer state
                    a.edited = time()
                    done = a
                    reports[1] = { "edit", { id = e.id, fields = all(a), was = was } }
                end
            elseif e.op == "rename" then
                for _, b in ipairs(e.before) do
                    local a, _, inGone = ns.FindAward(e.s, b.id)
                    if a and not inGone then
                        local was = all(a)
                        local v = a.v
                        assign(a, b)
                        a.v = v
                        a.edited = time()
                        done = a
                        reports[#reports + 1] = { "edit", { id = b.id, fields = all(a), was = was } }
                    end
                end
            end
            if done then
                changed()
                for _, r in ipairs(reports) do report(r[1], e.s, r[2]) end
                return text
            end
        end
    end
    return nil
end

---------------------------------------------------------------------------
-- The move of 1.4 data: ids and to for every award, tombstone lists, and the export marks
-- carried over so an exported raid stays "done" instead of turning "changed".
---------------------------------------------------------------------------
function ns.MigrateAwards(DB)
    if (tonumber(DB.awardsVersion) or 0) >= 1 then return end
    DB.sessions = DB.sessions or {}
    DB.exported = DB.exported or {}
    -- 1. which raids were exported as they are, by the old form of the fingerprint
    local matched = {}
    for _, s in ipairs(DB.sessions) do
        local e = DB.exported[s.id]
        if e and e.h == ns.SessionHash(s, true) then matched[#matched + 1] = s end
    end
    -- 2. ids and targets
    for _, s in ipairs(DB.sessions) do
        s.gone = s.gone or {}
        for _, a in ipairs(s.awards or {}) do
            if type(a.id) ~= "string" then a.id = legacyId(s, a) end
            if not VALID_TO[a.to] then a.to = "player" end
        end
    end
    -- 3. the new fingerprint for what was exported
    for _, s in ipairs(matched) do
        DB.exported[s.id].h = ns.SessionHash(s)
    end
    -- 4.
    DB.awardsVersion = 1
end

---------------------------------------------------------------------------
-- Plus-one: mainspec wins of a player in this raid or this ID week. Only living awards to a
-- player with kind MS count; SR, OS, bank and disenchant do not.
---------------------------------------------------------------------------
-- The raid with the latest start, the running recording included.
local function newestSession()
    local best
    for _, s in ipairs(ns.Sessions()) do
        if not best or (s.start or 0) > (best.start or 0) then best = s end
    end
    return best
end

-- Start of the ID week: a week before the next weekly reset, or nil when the client cannot say.
local function weekStart()
    local api = C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset
    if type(api) ~= "function" then return nil end
    local left = api()
    if type(left) ~= "number" then return nil end
    return time() + left - 7 * 86400
end

-- The raids a scope covers and the scope that applied: "week" falls back to "raid" when the
-- client does not know the weekly reset.
local function plusSessions(scope)
    scope = scope or ns.Get("rolls.plusScope")
    if scope == "week" then
        local from = weekStart()
        if from then
            local out = {}
            for _, s in ipairs(ns.Sessions()) do
                if (s.start or 0) >= from then out[#out + 1] = s end
            end
            return out, "week"
        end
    end
    local s = ns.Active() or newestSession()
    return { s }, "raid"
end

-- The scope the plus-one counts in right now: "raid" or "week".
function ns.PlusScope()
    local _, scope = plusSessions()
    return scope
end

local function plusAward(a)
    return a.kind == "MS" and (a.to == nil or a.to == "player")
end

-- The keeper's plus-one of the running raid, for a client that does not count itself: not the
-- keeper and no officer (a raider follows the keeper's number). nil when it does not apply.
local function keeperPlus(scope)
    local s = ns.Active()
    local p = s and type(s.sync) == "table" and s.sync.plus
    if type(p) ~= "table" or type(p.n) ~= "table" then return nil end
    if scope ~= nil and scope ~= p.s then return nil end
    if ns.SyncIsKeeper and ns.SyncIsKeeper() then return nil end
    if ns.IsOfficerView() and ns.SelfMayOfficer(true) then return nil end
    return p
end

-- The plus-one wins of the raids of a scope by the winner's spelling, counted once per frame: the
-- roll start asks for 40 names, the award list for every row. { count = { name -> wins }, byMain =
-- { lower main -> wins } of the winners whose name and main both carry a surname, slow = { the
-- other winners, as first seen }, memo = { asked name -> plus-one } }. Two names with surnames
-- belong to one player exactly when their mains are the same (ns.SameMain), so those winners are
-- added up by the main; the others go through ns.SameMain one by one. Made again in the next frame, when
-- the raids of the scope or their award counts change, with another alt list, and on every change
-- of the book (also one by the sync).
local tallyOf
dropPlus = function() tallyOf = nil end
ns.Listen("DATA_CHANGED", dropPlus)

-- The lower main of a name when the name and its main both carry a surname, else nil.
local function spacedMain(name)
    local n = ns.FullName(name)
    if not n or not n:find(" ", 1, true) then return nil end
    local m = ns.FullName(ns.MainOf(n))
    if not m or not m:find(" ", 1, true) then return nil end
    return m:lower()
end

local function plusTally(scope)
    local sessions = plusSessions(scope)
    local alts = AmisiaDB and type(AmisiaDB.alts) == "table" and AmisiaDB.alts.list or nil
    local t, c = GetTime(), tallyOf
    if c and c.at == t and c.alts == alts and #c.sessions == #sessions then
        for i, s in ipairs(sessions) do
            if c.sessions[i] ~= s or c.sizes[i] ~= #(s.awards or {}) then c = nil break end
        end
    else
        c = nil
    end
    if c then return c end
    c = { at = t, alts = alts, sessions = sessions, sizes = {}, count = {}, order = {}, byMain = {}, slow = {}, memo = {} }
    for i, s in ipairs(sessions) do
        c.sizes[i] = #(s.awards or {})
        for _, a in ipairs(s.awards or {}) do
            -- a winner without a name counts for no one (ns.SameMain matches nothing)
            if plusAward(a) and type(a.name) == "string" then
                if not c.count[a.name] then
                    c.count[a.name] = 0
                    c.order[#c.order + 1] = a.name
                end
                c.count[a.name] = c.count[a.name] + 1
            end
        end
    end
    for _, w in ipairs(c.order) do
        local key = spacedMain(w)
        if key then
            c.byMain[key] = (c.byMain[key] or 0) + c.count[w]
        else
            c.slow[#c.slow + 1] = w
        end
    end
    tallyOf = c
    return c
end

-- The plus-one of a player: the mainspec wins of the character and of every character linked
-- to the same main (Alts.lua). The keeper's number, where it applies, is looked up by the name
-- first, then by the main.
function ns.PlusCount(name, scope)
    if not ns.FullName(name) then return 0 end
    local kp = keeperPlus(scope)
    if kp then
        for who, c in pairs(kp.n) do
            if ns.SameName(who, name) then return tonumber(c) or 0 end
        end
        for who, c in pairs(kp.n) do
            if ns.SameMain(who, name) then return tonumber(c) or 0 end
        end
        return 0
    end
    local tally = plusTally(scope)
    local n = tally.memo[name]
    if n then return n end
    local key = spacedMain(name)
    local list = key and tally.slow or tally.order
    n = key and tally.byMain[key] or 0
    for _, w in ipairs(list) do
        if ns.SameMain(w, name) then n = n + tally.count[w] end
    end
    tally.memo[name] = n
    return n
end

-- Everyone with a plus-one in the scope: { { name, n, names } }, most first, then by name. One
-- entry per player: spellings of one character (with and without surname) and the alts of a main
-- are counted together, under the main's name for an alt, else under the first spelling seen.
-- names holds every spelling that won, the main and its known alts (the sync writes them all);
-- won only the spellings that won.
function ns.PlusList(scope)
    local out, sessions = {}, plusSessions(scope)
    -- lower main of a winner -> its entry: the same player again needs no scan; a new key looks
    -- through the entries with ns.SameMain (a spelling without surname)
    local byKey = {}
    for _, s in ipairs(sessions) do
        for _, a in ipairs(s and s.awards or {}) do
            if plusAward(a) then
                local key = tostring(ns.MainOf(a.name) or a.name):lower()
                local hit = byKey[key]
                if not hit then
                    for _, e in ipairs(out) do
                        if ns.SameMain(e.name, a.name) then hit = e break end
                    end
                end
                if hit then
                    hit.n = hit.n + 1
                else
                    hit = { name = ns.AltMain(a.name) or a.name, n = 1, names = {}, won = {} }
                    out[#out + 1] = hit
                end
                byKey[key] = hit
                hit.names[a.name], hit.won[a.name] = true, true
            end
        end
    end
    for _, e in ipairs(out) do
        e.names[e.name] = true
        for _, alt in ipairs(ns.AltsOf(e.name)) do e.names[alt] = true end
    end
    table.sort(out, function(x, y)
        if x.n ~= y.n then return x.n > y.n end
        return x.name < y.name
    end)
    return out
end

local SCOPE_TEXT = { raid = L["dieser Raid"], week = L["diese ID-Woche"] }

-- "/amisia plus [Name]": the plus-one of everyone in the scope, or of one name.
local function plusCommand(rest)
    local name = ns.FullName(rest)
    local _, scope = plusSessions()
    if name then
        ns.msg(L["Plus-Eins von %s (%s): %d."]:format(name, SCOPE_TEXT[scope], ns.PlusCount(name)))
        return
    end
    local list, parts = ns.PlusList(), {}
    for _, e in ipairs(list) do parts[#parts + 1] = ("%s %d"):format(e.name, e.n) end
    if #parts == 0 then
        ns.msg(L["Plus-Eins (%s): noch niemand."]:format(SCOPE_TEXT[scope]))
    else
        ns.msg(L["Plus-Eins (%s): %s."]:format(SCOPE_TEXT[scope], table.concat(parts, ", ")))
    end
end

ns.RegisterSlash("plus", { officer = true, args = L["[Name]"], desc = L["Plus-Eins der Gewinner im Chat"], run = plusCommand })

---------------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------------
-- A character name: no digits, at most one space (a Forever surname); empty switches it off.
local function validName(v)
    local name = ns.FullName(v)
    if not name then return "" end
    if name:find("%d") then return nil end
    if select(2, name:gsub(" ", "")) > 1 then return nil end
    return name
end

-- The section is everyone's for the tooltip line; the rest are the officers' items.
ns.RegisterSettings{ key = "awards", label = L["Vergaben"], order = 28, group = "raid", pages = { "awards" }, items = {
    { key = "awards.tooltip", type = "toggle", label = L["Vergabe-Verlauf im Item-Tooltip"], default = true,
      tip = L["Zeigt im Tooltip eines Items, wer es in aufgezeichneten Raids bekommen hat (die letzten drei)."] },
    { key = "awards.modClick", type = "toggle", label = L["Alt+Shift-Klick auf ein Item öffnet die Vergabe"], default = true, officer = true, tip = L["Alt+Shift-Klick auf einen Item-Link öffnet den Vergabe-Dialog für dieses Item."] },
    { key = "awards.bankName", type = "text", label = L["Bank-Charakter"], default = "", validate = validName, officer = true,
      tip = L["Master Loot an diesen Namen zählt als Bank."], invalid = L["Name ohne Ziffern, höchstens ein Leerzeichen."] },
    { key = "awards.deName", type = "text", label = L["Entzauberer"], default = "", validate = validName, officer = true,
      tip = L["Master Loot an diesen Namen zählt als Entzaubern."], invalid = L["Name ohne Ziffern, höchstens ein Leerzeichen."] },
}}

---------------------------------------------------------------------------
-- Hand-outs through master loot
---------------------------------------------------------------------------
local PENDING_TTL = 5
local pending = {}   -- loot slot -> { slot, name, item, link, src, t, token, kind, note, pts }
local lastSlot       -- slot of the latest hand-out

-- The open hand-out of a loot slot, or of the latest hand-out when no slot is given.
function ns.PendingAward(slot) return pending[slot or lastSlot or 0] end

-- Gives the open hand-out of a slot a note and a kind (the loot rules: "Regel: ...", "-"), right
-- after GiveMasterLoot; the award written on confirmation carries them. false without one.
function ns.TagPendingAward(slot, note, kind)
    local a = slot and pending[slot]
    if not a then return false end
    a.note, a.kind = note, kind
    return true
end

-- Short name without the realm part.
local function shortName(name)
    return ns.FullName(name)
end

-- Name of what a loot slot came from: the drop recorded for its source, else the current target.
-- On Forever the slot's GUID, the target's GUID and its name may be secret in an instance: such a
-- value is never a table key, compared or returned (the source is "?" then).
function ns.LootSourceName(slot)
    local s = ns.Active()
    local raw = (slot and slot > 0 and GetLootSourceInfo) and GetLootSourceInfo(slot) or nil
    local guid = ns.Plain(raw)
    if guid == nil and type(raw) ~= "nil" then return "?" end
    if s and guid and s.drops[guid] and s.drops[guid].src ~= "?" then return s.drops[guid].src end
    local target = ns.Plain(UnitName("target"))
    if type(target) ~= "string" or target == "" then return "?" end
    if not guid or guid == (UnitGUID and ns.Plain(UnitGUID("target"))) then return target end
    return "?"
end

local TO_TEXT = { bank = L["an die Bank (%s)"], de = L["zum Entzaubern (%s)"] }

local function commit(a)
    local to = ns.IsSpecialName(a.name) or "player"
    local kind = "-"
    if to == "player" then
        kind = a.kind or (ns.RollKind and ns.RollKind(a.item, a.name)) or "-"
    end
    local ok, why = ns.AddAwardTo(ns.Active(), { name = a.name, item = a.item, kind = kind, src = a.src, t = time(), to = to, note = a.note })
    -- DKP or EPGP: the amount of the dialog, else the bid or the cost of the item's points round
    if ok and to == "player" and ns.PointsSession and ns.PointsSession(ns.Active()) then
        local pts = a.pts
        if pts == nil and ns.PointsCostFor then pts = ns.PointsCostFor(a.item, a.name, kind) end
        if pts ~= nil then ns.AwardCostOrSay(ns.Active(), ok.id, pts) end
    end
    if ok then
        local item = a.link or ("Item " .. a.item)
        if to == "player" then
            ns.msg(L["Vergabe gespeichert: %s an %s (%s)."]:format(item, a.name, kind))
        else
            ns.msg(L["Vergabe gespeichert: %s %s."]:format(item, TO_TEXT[to]:format(a.name)))
        end
    elseif why then
        ns.msg(why)
    end
end

-- The master loot candidate index of name for a loot slot: the one candidate that is name
-- (ns.SameName: a side without surname matches on the first name). nil, and true when two or more
-- fit (then nobody gets the item: it could go to the wrong raider); nil alone when none fits.
-- Secret candidate names are skipped.
function ns.LootCandidate(slot, name)
    name = ns.FullName(ns.Plain(name))
    if not slot or not name or type(GetMasterLootCandidate) ~= "function" then return nil end
    local exact, loose, nExact, nLoose = nil, nil, 0, 0
    for i = 1, 40 do
        local c = ns.FullName(ns.Plain(GetMasterLootCandidate(slot, i)))
        if c then
            if c:lower() == name:lower() then
                exact, nExact = i, nExact + 1
            elseif ns.SameName(c, name) then
                loose, nLoose = i, nLoose + 1
            end
        end
    end
    if nExact + nLoose == 1 then return exact or loose end
    return nil, nExact + nLoose > 1
end

local function onGive(slot, candidate)
    local link = GetLootSlotLink and ns.Plain(GetLootSlotLink(slot))
    local id = ns.ItemID(link)
    local name = shortName(GetMasterLootCandidate and ns.Plain(GetMasterLootCandidate(slot, candidate)))
    if not id or not name then return end
    local token = {}
    -- a new hand-out of the same slot replaces the old one: that one never arrived
    pending[slot] = { slot = slot, name = name, item = id, link = link, src = ns.LootSourceName(slot), t = time(), token = token }
    lastSlot = slot
    C_Timer.After(PENDING_TTL, function()
        if pending[slot] and pending[slot].token == token then pending[slot] = nil end
    end)
end

if type(GiveMasterLoot) == "function" then
    hooksecurefunc("GiveMasterLoot", ns.Perf.Wrap("Hook GiveMasterLoot", onGive))
end

ns.OnEvent("CHAT_MSG_LOOT", function(text)
    if not next(pending) then return end
    -- a secret line (boss fight on Forever) is skipped; the emptied slot confirms the hand-out
    local who, id = ns.ParseLoot(ns.Plain(text))
    who = shortName(who)
    if not who then return end
    -- the oldest open hand-out of that item to that player: two copies of one token leave in order
    local found
    for _, a in pairs(pending) do
        if a.name == who and a.item == id and (not found or a.t < found.t or (a.t == found.t and a.slot < found.slot)) then
            found = a
        end
    end
    if found then
        pending[found.slot] = nil
        commit(found)
    end
end)

ns.OnEvent("LOOT_SLOT_CLEARED", function(slot)
    local a = slot and pending[slot]
    if a then
        pending[slot] = nil
        commit(a)
    end
end)

ns.OnEvent("LOOT_CLOSED", function() wipe(pending) end)

---------------------------------------------------------------------------
-- Commands
---------------------------------------------------------------------------
-- "/amisia award <Name|bank|de> <Item-Link oder ID> [ms|os|sr]" and "/amisia unaward"; without
-- anything the award dialog opens.
local SPECIAL_TO = { bank = "bank", de = "de" }
local SPECIAL_TEXT = { bank = L["an die Bank"], de = L["zum Entzaubern"] }

function ns.AwardCommand(rest)
    rest = (rest or ""):match("^%s*(.-)%s*$")
    if rest:lower() == "unaward" then
        local a = ns.RemoveLastAward()
        ns.msg(a and L["Vergabe entfernt: Item %d an %s. \"Rückgängig\" auf der Seite Vergaben holt sie zurück."]:format(a.item, a.name) or L["Keine Vergabe in der laufenden Aufnahme."])
        return
    end
    if rest == "" and ns.ShowAwardDialog then
        ns.ShowAwardDialog(nil, ns.Active())
        return
    end
    -- the name runs up to the item link or the item id, so a Forever surname fits
    local name, tail = rest:match("^(.-)%s*(|c.*)$")
    if not name then name, tail = rest:match("^(%D-)%s+(%d.*)$") end
    if not name then name, tail = rest:match("^(%S+)%s*(.*)$") end
    if not name or name == "" then
        ns.msg(L["Aufruf: /amisia award <Name> <Item-Link oder ID> [ms|os|sr]"])
        return
    end
    local id = ns.ItemID(tail) or tonumber(tail:match("^(%d+)"))
    if not id then
        ns.msg(L["Item fehlt: Link einfügen oder Item-ID angeben."])
        return
    end
    local kind = (tail:match("%s(%a%a)%s*$") or ""):upper()
    if kind ~= "MS" and kind ~= "OS" and kind ~= "SR" then kind = "-" end
    local to = SPECIAL_TO[name:lower()]
    local ok, why = ns.AddAwardTo(ns.Active(), { name = to and "-" or shortName(name), item = id, kind = to and "-" or kind,
        src = ns.LootSourceName(0), t = time(), to = to, manual = true })
    if not ok then
        ns.msg(why)
    elseif to then
        ns.msg(L["Vergabe gespeichert: Item %d %s."]:format(id, SPECIAL_TEXT[to]))
    else
        ns.msg(L["Vergabe gespeichert: Item %d an %s (%s)."]:format(id, shortName(name), kind))
    end
end

ns.RegisterSlash("award", { officer = true, args = L["<Name|bank|de> <Item-Link|ID> [ms|os|sr]"], desc = L["Vergabe von Hand eintragen, ohne Angaben öffnet der Dialog"],
    run = function(rest) ns.AwardCommand(rest) end })
ns.RegisterSlash("unaward", { officer = true, desc = L["letzte Vergabe zurücknehmen"], run = function() ns.AwardCommand("unaward") end })
ns.RegisterSlash("rueckgaengig", { en = "undo", officer = true, desc = L["letzte Änderung an Vergaben zurücknehmen"], run = function()
    local text = ns.UndoAward()
    ns.msg(text and L["Rückgängig: %s."]:format(text) or L["Nichts rückgängig zu machen."])
end })
end)
