-- Amisia raid recording: records who was in each raid, which guild materials and which blue or
-- better items were looted and what lay in opened loot windows, counts the guild bank, and exports
-- it as text for the Import tab of the Amisia loot ledger. Split from Core/Core.lua (F-202, D-130):
-- the core keeps the event frame, the loot line parser and the load of AmisiaDB.
local ADDON, ns = ...
ns.Load(function()
local L = ns.L

-- The item functions live in C_Item (WoW Forever has no GetItemInfo global).
local GetItemInfo = C_Item.GetItemInfo

-- Tracked guild bank materials: [itemID] = fallback name until the client has the item cached;
-- MAT_ORDER is the order of the counts and the export's B lines, GEMS the ids summed as gems.
-- Mats.lua fills MATS and MAT_ORDER in place from the learned list (AmisiaDB.mats): trade goods
-- that drop in raids. While the list is empty nothing is counted, looted materials are not recorded
-- apart and the export writes no B lines. GEMS stays empty: the learned list has no gem group.
ns.MATS = {}
ns.MAT_ORDER = {}
ns.GEMS = {}

-- Whether any material is tracked.
function ns.HasMats() return ns.MAT_ORDER[1] ~= nil end

-- "Name n, Name n" over the tracked materials of counts. With more than three materials only
-- those with a count are named, and with max at most max of them ("und n weitere"); "" when none.
function ns.MatSummary(counts, max)
    local parts, more = {}, 0
    local all = #ns.MAT_ORDER <= 3
    for _, id in ipairs(ns.MAT_ORDER) do
        local n = counts and counts[id] or 0
        if all or n > 0 then
            if max and #parts >= max then
                more = more + 1
            else
                parts[#parts + 1] = ("%s %d"):format(ns.ItemName(id), n)
            end
        end
    end
    if more > 0 then parts[#parts + 1] = L["und %d weitere"]:format(more) end
    return table.concat(parts, ", ")
end

function ns.GemCount(counts)
    local n = 0
    for id in pairs(ns.GEMS) do n = n + (counts[id] or 0) end
    return n
end

-- "Name n, Name n, Edelsteine n" of one counts table for the overview cards; "" when no material
-- is tracked or none of them is in counts.
function ns.MatLine(counts)
    if not ns.HasMats() then return "" end
    local total = 0
    for _, id in ipairs(ns.MAT_ORDER) do total = total + (counts[id] or 0) end
    local gems = ns.GemCount(counts)
    if total + gems == 0 then return "" end
    local line = ns.MatSummary(counts, 3)
    if next(ns.GEMS) then line = line .. L[", Edelsteine %d"]:format(gems) end
    return line
end

-- Loot of this quality or better is recorded besides the materials: 3 rare (blue), 4 epic, 5 legendary.
ns.MIN_QUALITY = 3
-- Blue or better items that are no raid loot worth listing: disenchanting results.
ns.IGNORE = {
    [20725] = true, -- Nexus Crystal
    [14344] = true, -- Large Brilliant Shard
    [14343] = true, -- Small Brilliant Shard
}

local ROSTER_EVERY  = 60           -- seconds between roster snapshots while recording

local nightStart = ns.NightStart

local DB            -- AmisiaDB, set on ADDON_LOADED
local active        -- the session currently being recorded, or nil
local ticker        -- roster snapshot ticker while recording
local rosterPending -- throttles bursts of GROUP_ROSTER_UPDATE

local msg = ns.msg

-- a data change: the window redraws once at the next frame however many come (MainFrame.lua)
local function refresh()
    if ns.RefreshSoon then ns.RefreshSoon() elseif ns.Refresh then ns.Refresh() end
end

local parseLoot = ns.ParseLootLink

---------------------------------------------------------------------------
-- Sessions
---------------------------------------------------------------------------
local function raidInstance()
    local name, instanceType, _, _, _, _, _, instanceID = GetInstanceInfo()
    return instanceType == "raid", name, instanceID
end

-- The moment a raider still counts as punctual: the raid start time set in the settings,
-- on the calendar day of this raid night. A time before 06:00 means the night after it.
local function lateCutoff(t)
    local mins = ns.Get("record.lateAt")
    if not mins then return nil end
    local d = date("*t", t - nightStart())
    local midnight = time({ year = d.year, month = d.month, day = d.day, hour = 0, min = 0, sec = 0 })
    if not midnight then return nil end
    return midnight + mins * 60 + ((mins * 60 < nightStart()) and (24 * 60 * 60) or 0)
end
ns.LateCutoff = lateCutoff

-- Nobody counts as late before the recording itself was running: starting the raid late must not
-- mark the whole group, so the first roster snapshot moves the line if it comes after the cutoff.
local function lateAfter(s)
    if not s or not s.lateAt then return nil end
    return math.max(s.lateAt, s.firstScan or s.start or 0)
end
ns.LateAfter = lateAfter

-- Only the first raid of a night decides who is late: a second raid the same evening
-- (Hyjal, then Black Temple) marks nobody.
local function firstRaidOfNight(night, instanceID)
    for _, o in ipairs(DB.sessions) do
        if o.date == night and o.instanceID ~= instanceID then return false end
    end
    return true
end

-- Keeps record.keepSessions raids, the oldest go first. In the officer view a raid the site has
-- not got yet (not exported, or changed since) stays, up to KEEP_MAX raids in all.
local KEEP_MAX = 200
local function trimSessions()
    local list = DB.sessions
    local keep = ns.Get("record.keepSessions") or 60
    -- (the site holds Forever raids only: off Forever nothing waits for it, D-57)
    local guard = ns.FOREVER and ns.IsOfficerView()
    local i = 1
    while #list > keep and i < #list do
        if guard and #list <= KEEP_MAX and ns.ExportState(list[i]) ~= "done" then
            i = i + 1
        else
            table.remove(list, i)
        end
    end
    -- kept over the limit: say why, so the officer exports them (record.exportWarn)
    if guard and #list > keep and ns.Get("record.exportWarn") then
        msg(L["%d Raids über \"Raids aufbewahren\" (%d) bleiben, weil die Website sie noch nicht hat. Bitte exportieren (Seite Export)."]:format(#list - keep, keep))
    end
end

local function newSession(zone, instanceID)
    local t = time()
    local night = ns.NightOf(t)
    local s = {
        id = date("%Y%m%d%H%M%S", t) .. "-" .. tostring(instanceID or 0),
        start = t,
        last = t,
        date = night,
        zone = zone or "?",
        instanceID = instanceID or 0,
        members = {},
        loot = {},
        items = {},   -- blue or better loot: { name, item, count, t }
        -- epoch seconds: whoever shows up after this is marked late
        lateAt = firstRaidOfNight(night, instanceID or 0) and lateCutoff(t) or nil,
        drops = {},   -- opened loot windows by source GUID: { src, t, items = { [itemID] = count } }
        awards = {},  -- hand-outs, kept by Awards.lua: { id, name, item, t, kind = MS|OS|SR|-, src, to, note, edited, orig, manual }
        gone = {},    -- deleted hand-outs with deleted = epoch, for undo and the export's tombstone line
        kills = {},   -- boss attempts, kept by RaidLog.lua: { enc, name, start, t, ok, size, diff, src, who, wait, n }
        bench = {},   -- the bench of this raid, kept by Bench.lua: name -> { t, class, self, by, note }
        outside = {}, -- in the group, online, not in the instance: name -> last seen epoch
    }
    DB.sessions[#DB.sessions + 1] = s
    trimSessions()
    -- the bench gathered tonight before the raid
    if ns.TakeBenchNext then ns.TakeBenchNext(s) end
    -- the loot system of the guild (DKP, EPGP) is frozen with the raid, as the late line is
    if ns.PointsNewSession then ns.PointsNewSession(s) end
    return s
end

local function findReusable(instanceID)
    local t = time()
    for i = #DB.sessions, 1, -1 do
        local s = DB.sessions[i]
        if s.instanceID == instanceID and (t - (s.last or s.start or 0)) <= (ns.Get("record.resumeHours") or 2) * 3600 then
            return s
        end
    end
    return nil
end

local function noteMember(s, name, class, t)
    local m = s.members[name]
    if m then
        m.last = t
        if class and class ~= "" then m.class = class end
    else
        -- whoever comes from the bench of this raid is never late: an entry an officer made (or took
        -- over), or an own entry (!bench) made before the late line; a late !bench changes nothing
        local after = lateAfter(s)
        local e = s.bench and next(s.bench) ~= nil and ns.IsBenched and ns.IsBenched(s, name)
        if type(e) == "table" and (not e.self or e.by or not after or (e.t or 0) <= after) then
            s.members[name] = { class = class or "", first = t, last = t, bench = true }
        else
            s.members[name] = { class = class or "", first = t, last = t, late = (after and t > after) or nil }
        end
    end
end
ns.NoteMember = noteMember

local function snapshotRoster()
    if not active then return end
    local t = time()
    active.firstScan = active.firstScan or t
    local n = GetNumGroupMembers() or 0
    -- The recorder's own roster line gives the zone string that means "inside the raid". Names and
    -- zones go through ns.Plain: in a boss fight on Forever they may be secret, and such a line is
    -- skipped (never compared or cut), while the readable ones still count.
    local me, here, hereSecret = ns.UnitFullName("player"), nil, false
    for i = 1, n do
        local name, _, _, _, _, _, zone = GetRaidRosterInfo(i)
        name = ns.Plain(name)
        if name and ns.SameName(name, me) then
            here = ns.Plain(zone)
            hereSecret = here == nil and type(zone) ~= "nil"
            break
        end
    end
    active.outside = active.outside or {}
    for i = 1, n do
        local name, _, _, _, _, class, zone, online = GetRaidRosterInfo(i)
        name, zone, online, class = ns.Plain(name), ns.Plain(zone), ns.Plain(online), ns.Plain(class)
        local full = type(name) == "string" and ns.FullName(name)
        -- Offline members and members waiting outside (bench, city) are not in the raid.
        if full and online then
            if hereSecret then
                -- the own zone cannot be compared: only raiders already counted stay counted
                if active.members[full] then noteMember(active, full, nil, t) end
            elseif not here or zone == here then
                noteMember(active, full, type(class) == "string" and class or nil, t)
            elseif type(zone) == "string" then
                active.outside[full] = t
            end
        end
    end
    active.last = t
    refresh()
end

local function startTicker()
    if ticker then return end
    ticker = C_Timer.NewTicker(ROSTER_EVERY, ns.Perf.Wrap("Ticker Roster", function() snapshotRoster() end))
end

local function stopTicker()
    if ticker then
        ticker:Cancel()
        ticker = nil
    end
end

-- At the end of a recording, in the officer view: how many raids the site has not got yet; once in
-- REMIND_EVERY seconds (a release to the graveyard and back ends and resumes the recording).
local REMIND_EVERY = 600
local remindedAt
local function exportReminder()
    if not ns.FOREVER or not ns.IsOfficerView() or not ns.Get("record.exportWarn") then return end
    if remindedAt and GetTime() - remindedAt < REMIND_EVERY then return end
    remindedAt = GetTime()
    local n = #ns.PendingExport()
    if n > 0 then
        msg(n == 1 and L["1 Raid ist noch nicht auf der Website. Seite Raid > Export."]
            or L["%d Raids sind noch nicht auf der Website. Seite Raid > Export."]:format(n))
    end
end

local function stopRecording()
    if not active then return end
    snapshotRoster()
    msg(L["Aufnahme beendet: %s, %d Raider."]:format(active.zone, ns.MemberCount(active)))
    exportReminder()
    local old = active
    active = nil
    stopTicker()
    -- the sync sends a last snapshot of the ended raid when something changed
    ns.Fire("RECORDING", nil, old)
    refresh()
end

local function evaluate()
    if not DB then return end
    if not ns.Get("record.enabled") then
        stopRecording()
        return
    end
    local isRaid, zone, instanceID = raidInstance()
    if isRaid and IsInRaid() then
        local started = false
        if not active or active.instanceID ~= instanceID then
            if active then stopRecording() end
            local s = findReusable(instanceID)
            if s then
                active = s
                if ns.TakeBenchNext then ns.TakeBenchNext(s) end
                msg(L["Aufnahme fortgesetzt: %s (%s)."]:format(s.zone, s.date))
            else
                active = newSession(zone, instanceID)
                msg(L["Aufnahme gestartet: %s. /amisia zeigt die Liste."]:format(active.zone))
            end
            started = true
        end
        startTicker()
        -- the snapshot refreshes the window
        snapshotRoster()
        -- start or resume: the version check says hello, the sync claims or follows
        if started then ns.Fire("RECORDING", active) end
    elseif active then
        stopRecording()
    else
        refresh()
    end
end

-- Remembers an item's name and quality from its link for the export.
local function rememberItem(id, link, q)
    if not DB then return end
    local name = type(link) == "string" and link:match("|h%[(.-)%]|h")
    local known = DB.itemNames[id]
    DB.itemNames[id] = { n = name or (known and known.n) or ("Item " .. id), q = q or (known and known.q) or 0 }
end
ns.RememberItem = rememberItem

-- Whether an item's name is already on record for the export.
function ns.KnownItem(id) return DB and DB.itemNames[id] ~= nil end

---------------------------------------------------------------------------
-- Awards: what the master looter hands out. The book itself lives in Awards.lua; these are the
-- entry points the recording offers.
---------------------------------------------------------------------------
-- An award into the running recording, as 1.4 wrote it.
function ns.AddAward(name, item, kind, src, t)
    return ns.AddAwardTo(active, { name = name, item = item, kind = kind, src = src, t = t })
end

-- ns.InGroup (whether a short name belongs to the current group, and its class) lives in Names.lua
-- with the group index.

-- Deletes the newest living award of the running recording (a tombstone, so it can be undone).
function ns.RemoveLastAward()
    if not active or #active.awards == 0 then return nil end
    return (ns.DeleteAward(active, active.awards[#active.awards].id))
end

local function onLoot(text)
    if not active then return end
    local who, id, count, link = parseLoot(text)
    if not who then return end
    local t = time()
    -- a trade good of a raid joins the material list before it is sorted in
    if ns.LearnMat then ns.LearnMat(id, link) end
    if ns.MATS[id] then
        active.loot[#active.loot + 1] = { name = who, item = id, count = count, t = t }
    else
        local q = ns.LinkQuality(link)
        if not q or q < ns.MIN_QUALITY or ns.IGNORE[id] then return end
        rememberItem(id, link, q)
        active.items[#active.items + 1] = { name = who, item = id, count = count, t = t }
    end
    noteMember(active, who, nil, t)
    refresh()
end

-- What lies in a loot window the recorder opens: a boss or trash corpse, or a chest in the raid.
-- The slots of one window are added up (a boss can drop the same token twice); reopening the
-- same corpse keeps the larger total instead of adding it again.
local function onLootOpened()
    if not active or not GetNumLootItems or not GetLootSlotLink then return end
    -- the target's GUID and name may be secret in an instance on Forever: never a table key or a
    -- stored source name then (the loot then counts under "?")
    local targetGUID = UnitGUID and ns.Plain(UnitGUID("target"))
    local targetName = ns.Plain(UnitName("target"))
    local seen = {}   -- source -> { [itemID] = count in this window }
    for slot = 1, GetNumLootItems() or 0 do
        local link = ns.Plain(GetLootSlotLink(slot))
        local id = type(link) == "string" and tonumber(link:match("item:(%d+)"))
        local q = id and ns.LinkQuality(link)
        local source = id and ns.Plain((GetLootSourceInfo and GetLootSourceInfo(slot))) or targetGUID or ("?" .. (targetName or ""))
        -- a container opened from the bags is not a drop
        local drop = type(source) == "string" and not source:find("^Item%-")
        -- a trade good dropping in the raid joins the material list, and is then no drop line
        if id and drop and ns.LearnMat then ns.LearnMat(id, link, q) end
        if id and q and q >= ns.MIN_QUALITY and not ns.MATS[id] and not ns.IGNORE[id] then
            if drop then
                local _, _, qty = GetLootSlotInfo(slot)
                seen[source] = seen[source] or {}
                seen[source][id] = (seen[source][id] or 0) + (tonumber(ns.Plain(qty)) or 1)
                rememberItem(id, link, q)
            end
        end
    end
    local t, any = time(), false
    for source, items in pairs(seen) do
        local d = active.drops[source]
        if not d then
            d = { src = "?", t = t, items = {} }
            active.drops[source] = d
        end
        if d.src == "?" and targetName and source == targetGUID then d.src = targetName end
        for id, n in pairs(items) do
            d.items[id] = math.max(d.items[id] or 0, n)
        end
        any = true
    end
    if any then refresh() end
end

---------------------------------------------------------------------------
-- Guild bank count
-- Counts the tracked materials in every guild bank tab the player may view.
-- A tab's items only arrive after QueryGuildBankTab, announced by
-- GUILDBANKBAGSLOTS_CHANGED, so every such event triggers a fresh count.
---------------------------------------------------------------------------
local BANK_SLOTS = 98
local HAS_BANK_API = GetGuildBankItemInfo and GetGuildBankItemLink and QueryGuildBankTab
    and GetNumGuildBankTabs and GetGuildBankTabInfo
local bankOpen, bankCounted, bankPending, bankNeedTabs = false, false, false, false

-- minFilled: when counting while the bank closes, a result with fewer tabs holding items than
-- the last count means the client already dropped tab data, so it is thrown away.
local function countBank(minFilled)
    bankPending = false
    if not bankOpen or not DB or not ns.HasMats() then return end
    local tabs = GetNumGuildBankTabs() or 0
    if tabs == 0 then return end -- tab list not here yet, GUILDBANK_UPDATE_TABS retries
    local counts, viewable, filled = {}, 0, 0
    for id in pairs(ns.MATS) do counts[id] = 0 end
    for tab = 1, tabs do
        local _, _, isViewable = GetGuildBankTabInfo(tab)
        if isViewable then
            viewable = viewable + 1
            local any = false
            for slot = 1, BANK_SLOTS do
                local link = GetGuildBankItemLink(tab, slot)
                if link then
                    any = true
                    local id = tonumber(link:match("item:(%d+)"))
                    if id and counts[id] then
                        local _, count = GetGuildBankItemInfo(tab, slot)
                        counts[id] = counts[id] + (tonumber(count) or 1)
                    end
                end
            end
            if any then filled = filled + 1 end
        end
    end
    -- No tab has delivered items yet: keep the last good count instead of storing zeros.
    if filled == 0 then return end
    if minFilled and filled < minFilled then return end
    DB.bank = {
        at = time(),
        by = UnitName("player") or "?",
        guild = (GetGuildInfo("player")) or "",
        counts = counts,
        tabs = viewable,
        filled = filled,
        total = tabs,
    }
    bankCounted = true
    -- the count goes to the guild once the counting is over (BankShare.lua: officers, bank.share)
    if ns.BankShareCounted then ns.BankShareCounted() end
    refresh()
end

local function scheduleBankCount()
    if bankPending then return end
    bankPending = true
    C_Timer.After(0.5, countBank)
end

local function queryBankTabs()
    local tabs = GetNumGuildBankTabs() or 0
    if tabs == 0 then
        bankNeedTabs = true
        return
    end
    bankNeedTabs = false
    local current = GetCurrentGuildBankTab and GetCurrentGuildBankTab()
    for tab = 1, tabs do
        local _, _, isViewable = GetGuildBankTabInfo(tab)
        if isViewable and tab ~= current then QueryGuildBankTab(tab) end
    end
    if current and current >= 1 and current <= tabs then QueryGuildBankTab(current) end
    scheduleBankCount()
end

local function bankOpened(frame)
    if not ns.Get("bank.count") then return end
    if not HAS_BANK_API or not ns.HasMats() then return end
    if not bankOpen then bankCounted = false end
    bankOpen = true
    frame:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED")
    frame:RegisterEvent("GUILDBANK_UPDATE_TABS")
    queryBankTabs()
end

local function bankClosed(frame, quiet)
    if not bankOpen then return end
    -- a change from the last moments is still waiting for the debounce: count it before closing
    if bankPending and not quiet then
        countBank((bankCounted and DB and DB.bank and DB.bank.filled) or 1)
    end
    bankOpen, bankNeedTabs = false, false
    frame:UnregisterEvent("GUILDBANKBAGSLOTS_CHANGED")
    frame:UnregisterEvent("GUILDBANK_UPDATE_TABS")
    if not quiet and bankCounted and DB and DB.bank then
        local sum = ns.MatSummary(DB.bank.counts, 6)
        msg(L["Gildenbank gezählt: %s (%d Tabs)."]:format(sum ~= "" and sum or L["keine Materialien"], DB.bank.tabs or 0))
        if (DB.bank.total or 0) > (DB.bank.tabs or 0) then
            msg(L["%d von %d Tabs sind für dich nicht sichtbar. Ihr Inhalt fehlt in dieser Zählung."]:format(
                (DB.bank.total or 0) - (DB.bank.tabs or 0), DB.bank.total or 0))
        end
        if (DB.bank.filled or 0) < (DB.bank.tabs or 0) then
            msg(L["Nur %d von %d Tabs haben Gegenstände geliefert. Sind die übrigen nicht leer, die Bank beim nächsten Mal länger offen lassen."]:format(
                DB.bank.filled or 0, DB.bank.tabs or 0))
        end
    end
end

-- The last guild bank count, or nil when there is none or no material is tracked (a count of
-- materials no longer tracked is kept in AmisiaDB.bank, but neither shown nor exported).
function ns.Bank()
    if not (DB and DB.bank and ns.HasMats()) then return nil end
    return DB.bank
end

-- The count the Bank page shows: ns.Bank(), else a count an officer sent (BankShare.lua, F-238: via set)
-- while this client has learned no material yet; then true as well, and the count's own items are the list.
function ns.BankShown()
    local bank = ns.Bank()
    if bank then return bank, false end
    bank = DB and DB.bank
    if type(bank) == "table" and bank.via and type(bank.counts) == "table" and next(bank.counts) then return bank, true end
    return nil, false
end

---------------------------------------------------------------------------
-- Public helpers for the window
---------------------------------------------------------------------------
function ns.Sessions() return DB and DB.sessions or {} end
function ns.Active() return active end

-- The recorded raid of an id (the pages Raid-Log and Vergaben).
function ns.RaidById(id)
    for _, s in ipairs(ns.Sessions()) do
        if s.id == id then return s end
    end
    return nil
end

-- The raids newest first, the running recording in front.
function ns.RaidsNewestFirst()
    local src, out, act = ns.Sessions(), {}, ns.Active()
    if act then out[1] = act end
    for i = #src, 1, -1 do
        if src[i] ~= act then out[#out + 1] = src[i] end
    end
    return out
end
function ns.IsEnabled() return DB ~= nil and ns.Get("record.enabled") end

function ns.SetEnabled(on)
    if not DB then return end
    ns.Set("record.enabled", on and true or false)
    msg(on and L["Aufnahme aktiv."] or L["Aufnahme pausiert."])
end

-- Raid start as HH:MM, or nil when the late marker is switched off.
function ns.LateTime()
    local mins = ns.Get("record.lateAt")
    if not mins then return nil end
    return ("%02d:%02d"):format(math.floor(mins / 60), mins % 60)
end

function ns.SetLateTime(text)
    return (ns.Set("record.lateAt", text)) or nil
end

ns.RegisterSettings{ key = "record", label = L["Aufnahme"], order = 10, group = "raid", pages = { "raidlog", "overview" }, items = {
    { key = "record.enabled", type = "toggle", label = L["Aufnahme im Raid"], default = true,
      tip = L["Zeichnet in Raidinstanzen mit Raidgruppe Anwesenheit und Loot auf."],
      onChange = function() evaluate() end },
    { key = "record.lateAt", type = "time", allowOff = true, label = L["Raidbeginn (zu spät ab)"], default = 20 * 60,
      tip = L["Wer danach zum ersten Mal im Raid steht, wird als zu spät vermerkt. \"aus\" schaltet es ab."] },
    { key = "record.keepSessions", type = "slider", label = L["Raids aufbewahren"], default = 60, min = 10, max = 200, step = 10, tip = L["So viele Raids bleiben gespeichert, die ältesten gehen zuerst. In der Offiziersansicht bleibt ein Raid, den die Website noch nicht hat (bis zu 200 Raids)."] },
    { key = "record.exportWarn", type = "toggle", label = L["An nicht exportierte Raids erinnern"], default = true, officer = true, forever = true,
      tip = L["Am Ende einer Aufnahme und wenn mehr Raids bleiben als eingestellt: wie viele Raids die Website noch nicht hat. Aus, wenn ein anderer Offizier exportiert."] },
    { key = "record.resumeHours", type = "slider", label = L["Fortsetzen innerhalb von (Std.)"], default = 2, min = 1, max = 6,
      expert = true, tip = L["Wer denselben Raid innerhalb dieser Zeit wieder betritt, setzt die Aufnahme fort."] },
    { key = "record.nightStart", type = "time", label = L["Raidnacht beginnt um"], default = 6 * 60, expert = true,
      tip = L["Ein Raid vor dieser Uhrzeit zählt zur Nacht davor."] },
}}
-- everyone's since F-238: the shared log and count reach every member, who may switch them off
ns.RegisterSettings{ key = "bank", label = L["Gildenbank"], order = 63, group = "guild", pages = { "bank" }, items = {
    { key = "bank.count", type = "toggle", label = L["Beim Öffnen der Gildenbank zählen"], default = true,
      tip = L["Zählt die Gildenmaterialien in allen sichtbaren Tabs."] },
    { key = "bank.log", type = "toggle", label = L["Gildenbank-Protokoll mitschreiben"], default = true,
      tip = L["Liest beim Öffnen der Gildenbank das Protokoll jedes sichtbaren Tabs und das Goldprotokoll."] },
    { key = "bank.share", type = "toggle", label = L["Gildenbank-Protokoll mit der Gilde abgleichen"], default = true,
      tip = L["Offiziere senden neue Protokolleinträge und die letzte Zählung an alle Amisia-Nutzer der Gilde; jeder nimmt sie nur von Offizieren an. Aus: nichts senden, nichts annehmen."] },
    { key = "bank.logDays", type = "slider", label = L["Protokoll aufbewahren (Tage)"], default = 90, min = 14, max = 365, step = 1,
      tip = L["Ältere Einträge fallen heraus; höchstens 1000 Einträge."] },
    { key = "bank.pledgeDays", type = "slider", label = L["Spendenzusagen gelten (Tage)"], default = 7, min = 1, max = 30,
      tip = L["Danach fällt eine Zusage aus der Bedarfsliste."] },
}}

function ns.LateCount(s)
    local n = 0
    for _, m in pairs(s.members or {}) do
        if m.late then n = n + 1 end
    end
    return n
end

function ns.MemberCount(s)
    local n = 0
    for _ in pairs(s.members) do n = n + 1 end
    return n
end

function ns.ItemCount(s)
    local n = 0
    for _, l in ipairs(s.items or {}) do n = n + (l.count or 1) end
    return n
end

function ns.MatCounts(s)
    local c = {}
    for _, l in ipairs(s.loot) do
        c[l.item] = (c[l.item] or 0) + (l.count or 1)
    end
    return c
end

function ns.DeleteSessions(ids)
    if not DB then return 0 end
    local keep, removed = {}, 0
    for _, s in ipairs(DB.sessions) do
        if ids[s.id] and s ~= active then
            removed = removed + 1
        else
            keep[#keep + 1] = s
        end
    end
    DB.sessions = keep
    refresh()
    return removed
end

-- Where a boss attempt came from, as the letter of its EK line.
local SRC_LETTER = { enc = "E", kill = "B", loot = "L", hand = "H" }
-- A free text as the last field of a line: no line break or pipe can cut the block.
local function oneLine(text)
    return (tostring(text or "?"):gsub("[%c|]", " "))
end

-- The lines of list summed per name and item: { name, item, count } in the order of "name\titem".
local function sumByNameItem(list)
    local sum, keys = {}, {}
    for _, l in ipairs(list) do
        local key = l.name .. "\t" .. l.item
        if not sum[key] then
            sum[key] = { name = l.name, item = l.item, count = 0 }
            keys[#keys + 1] = key
        end
        sum[key].count = sum[key].count + (l.count or 1)
    end
    table.sort(keys)
    for i, key in ipairs(keys) do keys[i] = sum[key] end
    return keys
end

-- The S..E block of one session, appended to lines; used collects the item ids to name in N lines.
-- legacy: the form of 1.4, every award as an A line and nothing else (the old export marks).
local function sessionLines(s, lines, used, legacy)
    lines[#lines + 1] = ("S %s %s %d %s"):format(s.id, s.date, tonumber(s.instanceID) or 0, s.zone or "?")
    local names = {}
    for name in pairs(s.members) do names[#names + 1] = name end
    table.sort(names)
    for _, name in ipairs(names) do
        -- M <name> <class> <first seen epoch> <1 late, 0 punctual>
        local m = s.members[name]
        lines[#lines + 1] = ("M %s %s %d %d"):format(ns.ExportName(name), (m.class and m.class ~= "") and m.class or "UNKNOWN",
            m.first or 0, m.late and 1 or 0)
    end
    for _, e in ipairs(sumByNameItem(s.loot)) do
        lines[#lines + 1] = ("L %s %d %d"):format(ns.ExportName(e.name), e.item, e.count)
        used[e.item] = true
    end
    -- I <name> <itemID> <count>: blue or better loot
    for _, e in ipairs(sumByNameItem(s.items or {})) do
        lines[#lines + 1] = ("I %s %d %d"):format(ns.ExportName(e.name), e.item, e.count)
        used[e.item] = true
    end
    -- D <itemID> <count> <source name>: blue or better items seen in loot windows
    local dsum, dkeys = {}, {}
    for _, d in pairs(s.drops or {}) do
        for id, c in pairs(d.items or {}) do
            local key = (d.src or "?") .. "\t" .. id
            if not dsum[key] then
                dsum[key] = { item = id, src = d.src or "?", count = 0 }
                dkeys[#dkeys + 1] = key
            end
            dsum[key].count = dsum[key].count + c
        end
    end
    table.sort(dkeys)
    for _, key in ipairs(dkeys) do
        local e = dsum[key]
        lines[#lines + 1] = ("D %d %d %s"):format(e.item, e.count, e.src)
        used[e.item] = true
    end
    -- A <name> <itemID> <epoch> <MS|OS|SR|-> <source name>: hand-outs to players, as 1.4 wrote them
    -- AS <id> <itemID> <epoch> <BANK|DE> <receiver|-> <source name>: hand-outs to the bank or for disenchanting
    -- AX <id> <edited epoch|0> <first winner|-> [<note>]: the id and history of the A or AS line before it
    for _, a in ipairs(s.awards or {}) do
        local to = legacy and "player" or a.to or "player"
        if to == "player" then
            lines[#lines + 1] = ("A %s %d %d %s %s"):format(ns.ExportName(a.name), a.item, a.t or 0, a.kind or "-", a.src or "?")
        else
            lines[#lines + 1] = ("AS %s %d %d %s %s %s"):format(a.id or "?", a.item, a.t or 0, to == "bank" and "BANK" or "DE",
                a.name ~= "-" and ns.ExportName(a.name) or "-", a.src or "?")
        end
        -- an award of 1.4 has no id until the move on load, and until then no history line either
        if not legacy and a.id then
            lines[#lines + 1] = ("AX %s %d %s%s"):format(a.id, a.edited or 0, a.orig and ns.ExportName(a.orig) or "-",
                a.note and (" " .. a.note) or "")
        end
        used[a.item] = true
    end
    -- AD <id> <itemID> <epoch> <deleted epoch>: a hand-out deleted after the fact
    if not legacy then
        for _, a in ipairs(s.gone or {}) do
            lines[#lines + 1] = ("AD %s %d %d %d"):format(a.id or "?", a.item, a.t or 0, a.deleted or 0)
            used[a.item] = true
        end
        -- EK <encounterID|0> <start epoch> <end epoch> <K|W> <size> <difficulty> <E|B|L|H> <boss name>
        -- EP <encounterID|0> <end epoch> <name> <name> ...: who was there, right after the EK of a kill
        local kills = {}
        for i, k in ipairs(s.kills or {}) do kills[i] = k end
        table.sort(kills, function(a, b)
            if (a.t or 0) ~= (b.t or 0) then return (a.t or 0) < (b.t or 0) end
            return (a.start or a.t or 0) < (b.start or b.t or 0)
        end)
        for _, k in ipairs(kills) do
            local t = k.t or 0
            lines[#lines + 1] = ("EK %d %d %d %s %d %d %s %s"):format(tonumber(k.enc) or 0, k.start or t, t, k.ok and "K" or "W",
                tonumber(k.size) or 0, tonumber(k.diff) or 0, SRC_LETTER[k.src] or "H", oneLine(k.name))
            if k.ok and not k.wait and type(k.who) == "table" and #k.who > 0 then
                local who = {}
                for i, name in ipairs(k.who) do who[i] = name end
                table.sort(who)
                for i, name in ipairs(who) do who[i] = ns.ExportName(name) end
                lines[#lines + 1] = ("EP %d %d %s"):format(tonumber(k.enc) or 0, t, table.concat(who, " "))
            end
        end
        -- BN <name> <class|UNKNOWN> <epoch> <S|O> <officer|-> [<note>]: the bench, by name
        local benched = {}
        for name in pairs(s.bench or {}) do benched[#benched + 1] = name end
        table.sort(benched)
        for _, name in ipairs(benched) do
            local e = s.bench[name]
            lines[#lines + 1] = ("BN %s %s %d %s %s%s"):format(ns.ExportName(name), (e.class and e.class ~= "") and e.class or "UNKNOWN",
                e.t or 0, e.self and "S" or "O", e.by and ns.ExportName(e.by) or "-", e.note and (" " .. oneLine(e.note)) or "")
        end
        -- R <itemID> <epoch> <W|A|O> <winner|-> <name>:<choice>[:<roll>] ...: group loot rolls (GroupRolls.lua)
        if ns.GroupRollLines and type(s.rolls) == "table" then ns.GroupRollLines(s, lines, used) end
        -- PS, PE, PA: the raid's DKP or EPGP (Points.lua), only for a raid with a points system
        if ns.PointsSessionLines then ns.PointsSessionLines(s, lines) end
    end
    lines[#lines + 1] = "E"
    return lines
end

local checksum = ns.Checksum

-- Fingerprint of what a session would export; it changes whenever the export of it would.
-- legacy: the fingerprint 1.4 stored, used once to move its export marks.
function ns.SessionHash(s, legacy)
    return checksum(table.concat(sessionLines(s, {}, {}, legacy), "\n"))
end

-- The fingerprints of the raids that are not recording: the overview and the raid lists ask on every
-- refresh (each loot line), and 60 exported raids cost 200 ms each time. A kept one holds HASH_SHORT
-- seconds always (a burst of changes in the raid hashes once), and up to HASH_KEEP seconds while
-- nothing changed (every edit of an old raid fires DATA_CHANGED or POINTS; RECORDING when a raid
-- starts or ends).
local HASH_SHORT, HASH_KEEP = 5, 60
local hashes = setmetatable({}, { __mode = "k" })   -- session -> { h, at, gen }
local hashGen = 0
for _, event in ipairs({ "DATA_CHANGED", "POINTS", "ALTS", "SETTING", "RECORDING" }) do
    ns.Listen(event, function() hashGen = hashGen + 1 end)
end

-- "new" (never exported), "changed" (exported, but more was recorded since) or "done". fresh: the
-- fingerprint now (the export itself), else a kept one of a raid that is not recording.
function ns.ExportState(s, fresh)
    local e = DB and DB.exported and DB.exported[s.id]
    if not e then return "new" end
    local now, kept = GetTime(), hashes[s]
    local h
    if not fresh and s ~= active and kept and (now - kept.at < HASH_SHORT or (kept.gen == hashGen and now - kept.at < HASH_KEEP)) then
        h = kept.h
    else
        h = ns.SessionHash(s)
        hashes[s] = { h = h, at = now, gen = hashGen }
    end
    return e.h == h and "done" or "changed"
end

-- Sessions to export when none is selected: everything new or changed since its last export (fresh:
-- every fingerprint now, for the export itself).
function ns.PendingExport(fresh)
    local out = {}
    for _, s in ipairs(ns.Sessions()) do
        if ns.ExportState(s, fresh) ~= "done" then out[#out + 1] = s end
    end
    return out
end

-- Whether the guild bank count is newer than the last export that carried it, or the needs, the
-- pledges or the bank log have something no export carried yet.
function ns.BankPending()
    local bank = ns.Bank()
    if bank and bank.counts and (bank.at or 0) > (DB.exportedBank or 0) then return true end
    if ns.BankNeedsPending and ns.BankNeedsPending() then return true end
    if ns.BankLogPending and #ns.BankLogPending() > 0 then return true end
    return false
end

-- Remembers what an export carried, so the next one without a selection can leave it out.
function ns.MarkExported(list)
    if not DB then return end
    local t = time()
    for _, s in ipairs(list) do
        local h = ns.SessionHash(s)
        DB.exported[s.id] = { h = h, at = t }
        hashes[s] = { h = h, at = GetTime(), gen = hashGen }
    end
    if DB.bank and DB.bank.counts then DB.exportedBank = DB.bank.at or 0 end
    if ns.MarkBankNeedsExported then ns.MarkBankNeedsExported() end
    if ns.MarkBankLogExported then ns.MarkBankLogExported() end
    refresh()
end

-- Text block for the ledger's Import tab. One S..E block per session.
function ns.ExportText(list)
    local lines = { "#AMISIA 2 " .. ns.ExportName(ns.UnitFullName("player") or "?") }
    local used = {}   -- item ids of L, B, I, D and A lines, named in N lines at the end
    local bank = ns.Bank()
    if bank and bank.counts then
        -- K <epoch seconds> <date> <HH:MM> <tabs with items> <tabs visible> <tabs total> <counted by>
        lines[#lines + 1] = ("K %d %s %s %d %d %d %s"):format(bank.at or 0, date("%Y-%m-%d", bank.at), date("%H:%M", bank.at),
            bank.filled or 0, bank.tabs or 0, bank.total or bank.tabs or 0, bank.by or "?")
        -- a material learned after the count has no number yet, so no B line
        for _, id in ipairs(ns.MAT_ORDER) do
            if bank.counts[id] then
                lines[#lines + 1] = ("B %d %d"):format(id, bank.counts[id])
                used[id] = true
            end
        end
    end
    -- LC <itemID> <edited epoch> <officer> <prio token|-> [<note>]: the loot prio edited in game (LootPrio.lua)
    if ns.LootPrioExportLines then
        for _, line in ipairs(ns.LootPrioExportLines()) do lines[#lines + 1] = line end
    end
    -- PX <id> <name> <D|E|G> <amount> <epoch> <officer> <reason>: point corrections made in game (Points.lua)
    if ns.PointsExportLines then
        for _, line in ipairs(ns.PointsExportLines()) do lines[#lines + 1] = line end
    end
    -- BQ <itemID> <min> <target|0> <set epoch> <set by>: the guild bank needs of an officer
    local needs = ns.BankNeeds and ns.BankNeeds()
    if needs and next(needs.list) then
        local ids = {}
        for id in pairs(needs.list) do ids[#ids + 1] = id end
        table.sort(ids)
        for _, id in ipairs(ids) do
            local e = needs.list[id]
            lines[#lines + 1] = ("BQ %d %d %d %d %s"):format(id, e.min, e.target or 0, needs.rev or 0, ns.ExportName(needs.by or "?"))
            used[id] = true
        end
        -- BP <itemID> <count> <epoch> <name>: a member's pledge to donate, while it counts
        for _, p in ipairs(ns.BankPledgeList()) do
            lines[#lines + 1] = ("BP %d %d %d %s"):format(p.item, p.count, p.t, ns.ExportName(p.name))
            used[p.item] = true
        end
    elseif needs and (needs.rev or 0) > 0 then
        -- every need was taken out: item 0 says "the list is empty now"
        lines[#lines + 1] = ("BQ 0 0 0 %d %s"):format(needs.rev, ns.ExportName(needs.by or "?"))
    end
    -- BT <from> <to> <tab|0> <kind> <itemID|0> <count|copper> <tab1|0> <tab2|0> <name>: a guild bank
    -- log entry no export carried yet (tab 0: the money log; from..to: when it happened)
    for _, e in ipairs(ns.BankLogPending and ns.BankLogPending() or {}) do
        lines[#lines + 1] = ("BT %d %d %d %s %d %d %d %d %s"):format(e.lo, e.hi, e.k, e.y, e.i, e.c, e.a or 0, e.b or 0, ns.ExportName(e.n))
        if e.i > 0 then used[e.i] = true end
    end
    for _, s in ipairs(list) do
        sessionLines(s, lines, used)
    end
    -- N <itemID> <quality> <item name>
    local ids = {}
    for id in pairs(used) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        local known = DB and DB.itemNames[id]
        lines[#lines + 1] = ("N %d %d %s"):format(id, (known and known.q) or 0, GetItemInfo(id) or (known and known.n) or ("Item " .. id))
    end
    lines[#lines + 1] = "#END"
    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
-- After the core loaded AmisiaDB (Core/Core.lua): the raids, the item names and the export marks,
-- cleaned as before; the first ADDON_LOADED handler, as this file comes right after Core/Core.lua.
ns.OnEvent("ADDON_LOADED", function()
    DB = AmisiaDB
    DB.sessions = DB.sessions or {}
    DB.itemNames = DB.itemNames or {}
    DB.exported = DB.exported or {}   -- session id -> { h = fingerprint, at = epoch } of its last export
    local loadedAt, tonight = time(), ns.NightOf(time())
    for _, s in ipairs(DB.sessions) do
        s.members = s.members or {}
        s.loot = s.loot or {}
        s.items = s.items or {}
        s.drops = s.drops or {}
        s.awards = s.awards or {}
        s.gone = s.gone or {}
        s.kills = s.kills or {}
        s.bench = s.bench or {}
        s.outside = s.outside or {}
        -- the sync state of a raid (2.1): a table with a raid key, waiting wishes younger than a
        -- day, conflicts only of tonight (20 at most); an award's revision only as a number >= 0
        local sy = s.sync
        if sy ~= nil and (type(sy) ~= "table" or type(sy.key) ~= "string" or not sy.key:match("^%d%d%d%d%-%d%d%-%d%d:%d+$")) then
            s.sync = nil
        elseif sy then
            if type(sy.rev) ~= "number" or sy.rev < 0 then sy.rev = 0 end
            if type(sy.pending) == "table" then
                local keep = {}
                for _, p in ipairs(sy.pending) do
                    if type(p) == "table" and type(p.t) == "number" and loadedAt - p.t < 86400 then keep[#keep + 1] = p end
                end
                sy.pending = keep
            elseif sy.pending ~= nil then
                sy.pending = nil
            end
            if type(sy.conflicts) == "table" then
                local keep = {}
                if s.date == tonight then
                    for _, c in ipairs(sy.conflicts) do
                        if type(c) == "table" and #keep < 20 then keep[#keep + 1] = c end
                    end
                end
                sy.conflicts = keep
            elseif sy.conflicts ~= nil then
                sy.conflicts = nil
            end
        end
        for _, list in ipairs({ s.awards, s.gone }) do
            for _, a in ipairs(list) do
                if a.v ~= nil and (type(a.v) ~= "number" or a.v < 0) then a.v = nil end
            end
        end
    end
    -- the learned material list, and what the raids recorded before it teach once
    if ns.MatsLoaded then ns.MatsLoaded(DB) end
    -- open boss attempts of an earlier session, kills still waiting for their names
    if ns.RaidLogLoaded then ns.RaidLogLoaded() end
    -- a bench gathered for an earlier night falls away
    if ns.BenchLoaded then ns.BenchLoaded() end
    -- awards of 1.4 get their ids, and the export marks of 1.4 are carried over
    ns.MigrateAwards(DB)
    -- soft-reserve lists of 1.5 get data model 2
    if ns.MigrateSoftRes then ns.MigrateSoftRes(DB) end
    -- forget the export marks of sessions that were dropped or deleted
    local ids = {}
    for _, s in ipairs(DB.sessions) do ids[s.id] = true end
    for id in pairs(DB.exported) do
        if not ids[id] then DB.exported[id] = nil end
    end
end)

-- The recording's events. The core frame registers them (ns.OnEvent); this file comes right after
-- Core/Core.lua, so its handlers run before those of the other files, as the core's own part did. The
-- guild bank's tab events only while the bank is open, on a frame of their own.
local bankFrame
local function onEvent(event, arg1)
    if event == "CHAT_MSG_LOOT" then
        -- a secret line of a boss fight is skipped
        local text = ns.Plain(arg1)
        if active and type(text) == "string" then
            onLoot(text)
        end
    elseif event == "LOOT_OPENED" then
        onLootOpened()
    elseif event == "GROUP_ROSTER_UPDATE" then
        if not rosterPending then
            rosterPending = true
            C_Timer.After(2, function()
                rosterPending = false
                evaluate()
            end)
        end
    elseif event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" or event == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" then
        if Enum and Enum.PlayerInteractionType and arg1 == Enum.PlayerInteractionType.GuildBanker then
            if event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then bankOpened(bankFrame) else bankClosed(bankFrame) end
        end
    elseif event == "GUILDBANKFRAME_OPENED" then
        bankOpened(bankFrame)
    elseif event == "GUILDBANKFRAME_CLOSED" then
        bankClosed(bankFrame)
    elseif event == "GUILDBANK_UPDATE_TABS" then
        if bankOpen then
            if bankNeedTabs then queryBankTabs() else scheduleBankCount() end
        end
    elseif event == "GUILDBANKBAGSLOTS_CHANGED" then
        if bankOpen then scheduleBankCount() end
    elseif event == "PLAYER_ENTERING_WORLD" or event == "ZONE_CHANGED_NEW_AREA" then
        -- a loading screen always leaves the bank
        if event == "PLAYER_ENTERING_WORLD" then bankClosed(bankFrame, true) end
        -- instance information settles a moment after the loading screen
        C_Timer.After(1, evaluate)
    end
end

for _, ev in ipairs({ "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "GROUP_ROSTER_UPDATE", "CHAT_MSG_LOOT", "LOOT_OPENED" }) do
    ns.OnEvent(ev, function(arg1) onEvent(ev, arg1) end)
end
if HAS_BANK_API then
    bankFrame = CreateFrame("Frame")
    bankFrame:SetScript("OnEvent", ns.Perf.Wrap("Event GUILDBANK", function(_, event, arg1) onEvent(event, arg1) end))
    for _, ev in ipairs({ "PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
                          "GUILDBANKFRAME_OPENED", "GUILDBANKFRAME_CLOSED" }) do
        ns.OnEvent(ev, function(arg1) onEvent(ev, arg1) end)
    end
end

---------------------------------------------------------------------------
-- Slash command
---------------------------------------------------------------------------
-- alone the recording's switch; with minutes or "stop" the break timer of Raid/PullTimer.lua (F-164,
-- D-94: "/amisia pause 5" announces a break, as /amisia raidpause does)
ns.RegisterSlash("pause", { desc = L["Aufnahme pausieren oder fortsetzen"], run = function(rest)
    if type(rest) == "string" and rest:match("%S") and ns.PullTimer then return ns.PullTimer.Slash("break", rest) end
    ns.SetEnabled(not ns.IsEnabled())
end })
ns.RegisterSlash("spaet", { en = "late", args = L["<HH:MM>|aus"], desc = L["Raidbeginn für die Zu-spät-Markierung"],
    run = function(rest)
        if rest == "" then
            local at = ns.LateTime()
            msg(at and L["Raidbeginn %s. Wer danach zum ersten Mal im Raid steht, wird als zu spät vermerkt. /amisia spaet aus schaltet es ab."]:format(at)
                or L["Verspätungen werden nicht vermerkt. /amisia spaet 20:00 schaltet sie ein."])
        elseif ns.SetLateTime(rest) then
            local at = ns.LateTime()
            msg(at and L["Raidbeginn %s: wer danach zum ersten Mal im Raid steht, ist zu spät."]:format(at)
                or L["Verspätungen werden nicht mehr vermerkt."])
        else
            msg(L["Aufruf: /amisia spaet <HH:MM> | aus"])
        end
    end })
ns.RegisterSlash("status", { desc = L["Stand der Aufnahme und der Gildenbank"], run = function()
    if active then
        local c = ns.MatCounts(active)
        local late = ns.LateCount(active)
        local sum = ns.HasMats() and ns.MatSummary(c, 6) or ""
        local mats = sum ~= "" and (", " .. sum) or ""
        msg(L["Aufnahme: %s, %d Raider%s%s."]:format(active.zone, ns.MemberCount(active),
            late > 0 and L[", %d zu spät"]:format(late) or "", mats))
    else
        msg(ns.IsEnabled() and L["Keine Aufnahme. Sie startet in einer Raidinstanz mit Raidgruppe."] or L["Aufnahme pausiert. Fortsetzen im Minimap-Menü oder am Pfeil der Statuszeile des Amisia-Fensters."])
    end
    -- the guild bank only while materials are tracked
    if not ns.HasMats() then return end
    local bank = ns.Bank()
    if bank and bank.counts then
        local sum = ns.MatSummary(bank.counts, 6)
        msg(L["Gildenbank vom %s: %s."]:format(ns.FmtDayTime(bank.at), sum ~= "" and sum or L["keine Materialien"]))
    else
        msg(L["Gildenbank noch nicht gezählt. Öffne sie einmal."])
    end
end })
ns.RegisterSlash("export", { officer = true, forever = true, desc = L["den neuesten Raid exportieren"], run = function()
    if ns.ShowExport then ns.ShowExport(true) end
end })
end)
