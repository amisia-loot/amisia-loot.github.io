-- Gear page: the best items of the own character per slot ("Ziele") with the
-- three options of a slot, the buttons to wish or exclude and the explained score; what a place
-- still offers ("Hier"); the own wishlist with its text for the website ("Wunschliste"); the guild
-- wishes pasted from the website ("Gilde", import for officers). Plus the overview card. The dungeon
-- planner is a page of its own (Pages/Dungeons.lua) and draws with the helpers this file hands over
-- in ns.GearPageKit.
-- Everything shown comes from the caches of Bis.lua; a refresh never computes the targets again
-- unless something they depend on changed.
local ADDON, ns = ...
local L = ns.L
local W, T = ns.W, ns.Theme
local Gear = ns.Gear
local GREY, GREEN = T.GREY, "|cff4fd06a"
local CHECK = "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t"
local STAR = "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:12:12|t"
local QUALITY = T.QUALITY_HEX
local ROW_H = 24
local GOAL_ROWS, HERE_ROWS, WISH_ROWS, GUILD_ROWS = 11, 14, 12, 11
local PRIO_TEXT = { [3] = L["hoch"], [2] = L["mittel"], [1] = L["niedrig"] }
local PRIO_NEXT = { [3] = 2, [2] = 1, [1] = 3 }
local PRIO_TIP = { [3] = L[" (hoch)"], [1] = L[" (niedrig)"] }
local OWNED_TEXT = { worn = L["angelegt"], bag = L["in der Tasche, nicht angelegt"], bank = L["in der Bank, nicht angelegt"] }
-- a saved "dungeons" (the planner's view before its own page) is no view any more: "goals" is shown
local VIEWS = { goals = true, here = true, wish = true, guild = true, sim = true }
-- the source chips: key, label, width
local CHIPS = { { "X", "Raids", 48 }, { "Q", "Quests", 50 }, { "D", "Dungeons", 64 }, { "C", L["Berufe: alle"], 86 },
                { "V", L["Händler"], 56 }, { "W", L["Welt"], 40 }, { "A", "AH", 32 }, { "P", "PvP", 36 } }

local groupOnly          -- the guild view's "Nur Gruppe"; nil: on while in a raid
local exportOpen = false -- the wishlist shows the text for the website instead of the list
local exportText = ""
local guildResult        -- what the last import said
local scrolledTo         -- the slot the targets list was last scrolled to
local placeGone          -- the saved place of "Hier" was not in the data

local function itemInfo(x)
    local f = C_Item and C_Item.GetItemInfo
    if f then return f(x) end
    return nil
end

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

-- The window state of the page in settings.bis (view, slot, place, sources).
local function state()
    local s = AmisiaDB.settings
    s.bis = type(s.bis) == "table" and s.bis or {}
    return s.bis
end

-- What a refresh keeps until Bis.lua's state changes: source texts, explanations, the wishes.
local memo = { stamp = -1 }
local function cached()
    local st = ns.BisStamp()
    if memo.stamp ~= st then memo = { stamp = st, src = {}, explain = {} } end
    return memo
end

local nameMissing = false   -- a shown row had no item name yet ("Item 12345")

local function itemText(id)
    local name, _, q = itemInfo(id)
    local row = Gear.Item(id)
    q = q or (row and (row[5] or 0) > 0 and row[5]) or 1
    if not name then nameMissing = true end
    return ("|c%s%s|r"):format(QUALITY[q] or QUALITY[1], name or Gear.ScanName(id) or (row and row.name) or ("Item " .. id))
end

-- A worn item's name in the colour of its link.
local function linkText(link)
    local color = link:match("^|c(%x%x%x%x%x%x%x%x)")
    local name = link:match("|h%[(.-)%]|h")
    if name then return color and ("|c%s%s|r"):format(color, name) or name end
    local id = ns.ItemID(link)
    return id and itemText(id) or "?"
end

local function linkOf(id)
    local _, link = itemInfo(id)
    return link or ("item:" .. id)
end

-- A gain as percent of what is worn; a tiny worn score (starter items) gives thousands, shown as ">999 %"
-- so the column does not cut it.
local function pctText(gain, mine)
    local pct = math.floor(gain / mine * 100 + 0.5)
    if pct > 999 then return ">999 %" end
    return ("%+d %%"):format(pct)
end

local function firstSource(id, o)
    return Gear.Sources(id, o)[1] or Gear.Sources(id)[1]
end

-- pick: the BiS pick of the option (its source text stands in when the data knows none)
local function sourceText(id, o, pick)
    local c = cached()
    -- with the options (their play style) and without them, each its own text
    local key = (o and "o" or "-") .. id
    local t = c.src[key]
    if t == nil then
        local rec = firstSource(id, o)
        t = rec and Gear.SourceText(rec, true) or ""
        c.src[key] = t
    end
    if t == "" and type(pick) == "table" and type(pick.src) == "string" then return pick.src end
    return t
end

local function marks(e)
    return (e.owned and (CHECK .. " ") or "") .. (e.wished and (STAR .. " ") or "")
end

-- What the planner did with an option, as short grey notes: a BiS pick, the set it belongs to,
-- computed stats, an effect the scoring does not count, the best seen random suffix, moved ahead
-- for its effort.
local function noteParts(e)
    local out = {}
    if e.outside then out[#out + 1] = L["außerhalb deines Spielstils"] end
    if e.pick then out[#out + 1] = L["BiS-Empfehlung"] end
    if e.set then out[#out + 1] = L["Set %d/%d, %+d Bonus"]:format(e.set.have, e.set.total, math.floor(e.set.bonus + 0.5)) end
    if e.sc then out[#out + 1] = L["berechnet"] end
    if Gear.EffectText(e.id or e[1]) then out[#out + 1] = L["Effekt nicht gewertet"] end
    if e.suffix then out[#out + 1] = L["bester gesehener Bonus"] end
    if e.easier then out[#out + 1] = L["leichter zu bekommen"] end
    -- the reputation the item asks for, red while the own standing is too low (F-124)
    local rep, low = ns.PlayStyle.RepText(e.id or e[1])
    if rep then out[#out + 1] = low and ("|cffd04040" .. rep .. "|r") or rep end
    return out
end
local function noteText(e)
    local parts = noteParts(e)
    if #parts == 0 then return "" end
    return " " .. GREY .. "(" .. table.concat(parts, ", ") .. ")|r"
end

local function gainText(e)
    if e.worn or e.owned == "worn" then return CHECK end
    if e.switch then return L["Wechsel"] end
    if type(e.gain) ~= "number" then return "" end
    return (e.upgrade and GREEN or GREY) .. ("%+d"):format(math.floor(e.gain + 0.5)) .. "|r"
end

local function upgradesText(n) return n == 1 and "1 Upgrade" or (n .. " Upgrades") end

local function wishCount()
    local c = ns.BisChar()
    local n = 0
    for _ in pairs(c and c.wish or {}) do n = n + 1 end
    return n
end

local insertLink = W.InsertLink

-- Shift or Ctrl on an item: the client's modified click (link into the chat, dressing room, as the
-- player's key bindings say); Ctrl the client does not take opens the dressing room itself.
local function modifiedClick(id)
    if not id then return false end
    local ctrl = IsControlKeyDown and IsControlKeyDown() or false
    if not ((IsShiftKeyDown and IsShiftKeyDown()) or ctrl) then return false end
    local link = linkOf(id)
    local handled = HandleModifiedItemClick and HandleModifiedItemClick(link)
    if not handled and ctrl and type(DressUpLink) == "function" then pcall(DressUpLink, link) end
    return true
end

local function itemTooltip(owner, id)
    if not id then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    local _, link = itemInfo(id)
    if link then
        GameTooltip:SetHyperlink(link)
    elseif GameTooltip.SetItemByID then
        GameTooltip:SetItemByID(id)
        -- an item only the server describes and no longer does: what the scan saw (D-59)
        if Gear.ScanTooltip(GameTooltip, id, owner, function() itemTooltip(owner, id) end) then return end
    end
    GameTooltip:Show()
end
local function hideTip() GameTooltip:Hide() end

local function say(ok, why)
    if not ok and why then ns.msg(why) end
end

---------------------------------------------------------------------------
-- Map: the button before a source and the menu entries, only for items with a place
---------------------------------------------------------------------------

local MAP_ICON = "Interface\\Icons\\INV_Misc_Map_01"

-- Whether an item has a place on the map (with the page's filters), kept until the state changes.
local function hasPlace(id)
    if not id or not ns.HasData("MAP") or not ns.MapItemPlaces then return false end
    local c = cached()
    c.places = c.places or {}
    local v = c.places[id]
    if v == nil then
        v = #ns.MapItemPlaces(id) > 0
        c.places[id] = v
    end
    return v
end

-- The source key of a record, when it has a place (else the nearest of all sources is taken).
local function placeKey(rec)
    local key = rec and ns.MapKeyOf and ns.MapKeyOf(rec)
    if key and #ns.MapPoints(key) > 0 then return key end
    return nil
end

local function showOnMap(id, key)
    local point = ns.Map.ItemNearest(id, key)
    if not point and key then point = ns.Map.ItemNearest(id) end
    if point then ns.MapShowOnWorldMap(point) end
end

local function setTarget(id, key)
    local ok, why = ns.MapSetTarget(id, key)
    if not ok and key then ok, why = ns.MapSetTarget(id) end
    say(ok, why)
end

-- Click: the target to the source (the nearest place); Shift: the place on the world map.
local function mapClick(self)
    if not self.id then return end
    if IsShiftKeyDown and IsShiftKeyDown() then showOnMap(self.id, self.key) else setTarget(self.id, self.key) end
end

local function mapTip(self)
    if not self.id then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine(L["Wegpunkt zur Quelle"], 1, 0.82, 0)
    local where = ns.Map.Where(self.id, self.key)
    if where then GameTooltip:AddLine(L["Fundort: %s"]:format(where), 0.85, 0.85, 0.85) end
    GameTooltip:AddLine(L["Klick: Ziel setzen. Shift-Klick: auf der Weltkarte zeigen."], 0.6, 0.6, 0.6)
    GameTooltip:Show()
end

-- A 16 px map button at x in its row.
local function mapButton(parent, x)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(16, 16)
    b:SetPoint("LEFT", x, 0)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints()
    b.icon:SetTexture(MAP_ICON)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.25)
    b:SetScript("OnClick", mapClick)
    b:SetScript("OnEnter", mapTip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:Hide()
    return b
end

-- Shows the button for an item with a place (rows are pooled: every field is set again).
local function setMapButton(b, id, rec, hide)
    if id and not hide and hasPlace(id) then
        b.id, b.key = id, placeKey(rec)
        b:Show()
    else
        b.id, b.key = nil, nil
        b:Hide()
    end
end

-- "Wegpunkt setzen" and "Auf der Karte zeigen", for an item with a place.
local function mapEntries(out, id, key)
    if not hasPlace(id) then return end
    out[#out + 1] = { L["Wegpunkt setzen"], function() setTarget(id, key) end }
    out[#out + 1] = { L["Auf der Karte zeigen"], function() showOnMap(id, key) end }
end

local function inInstance()
    return IsInInstance and ns.Plain(IsInInstance()) and true or false
end

local lift = W.LiftDialog

local function col(parent, x, w, label, template)
    local fs = W.Text(parent, template or T.FONT.head, w)
    fs:SetPoint("LEFT", x, 0)
    if label then fs:SetText(label) end
    return fs
end

-- Every place key the data knows (raids, dungeons, zones), per data set.
local knownFor, known
local function placeKnown(place)
    local d = ns.Data("GEAR")
    if not place or not d then return false end
    if knownFor ~= d then
        known, knownFor = {}, d
        for _, rec in ipairs(d.S) do
            local p = Gear.PlaceOf(rec)
            if p then known[p] = true end
        end
    end
    for k in pairs(place.keys or {}) do
        if known[k] then return true end
    end
    return false
end

local function guildVisible() return ns.IsOfficerView() or ns.GuildWishesInfo() ~= nil end

local function shownView()
    local v = state().view
    if not VIEWS[v] or (v == "guild" and not guildVisible()) then return "goals" end
    return v
end

local function setView(v)
    state().view = v
    guildResult = nil
    if v ~= "wish" then exportOpen = false end
    ns.Refresh()
end

local longDate = ns.LongDate

---------------------------------------------------------------------------
-- Head: spec, views, counts, source chips
---------------------------------------------------------------------------

local function counts(o, res)
    local parts = { L["Level %d"]:format(o.level), upgradesText(res.upgrades or 0) }
    local c = ns.BisChar()
    parts[#parts + 1] = (c and c.bankAt) and L["Bank %s"]:format(ns.FmtDay(c.bankAt)) or L["Bank noch nicht geöffnet"]
    local ex = ns.BisExcludeCount()
    if ex > 0 then parts[#parts + 1] = L["%d ausgeschlossen"]:format(ex) end
    local loading = Gear.Loading()
    if loading > 0 then parts[#parts + 1] = "|cffe0a344" .. L["lädt noch %d Items"]:format(loading) .. "|r" end
    if o.style then
        local h = ns.BisStyleHidden(o)
        if h.n > 0 then parts[#parts + 1] = L["Spielstil blendet %d Ziele aus"]:format(h.n) end
    end
    return table.concat(parts, " · ")
end

---------------------------------------------------------------------------
-- The play style (F-124): a chip with a menu of the five switches, here and in the goals window
---------------------------------------------------------------------------

local PS = ns.PlayStyle
local STYLE_HIDDEN_LINES = 10

local function styleEntries(owner)
    local out = {}
    for _, k in ipairs(PS.KEYS) do
        local on = PS.On(k)
        out[#out + 1] = { (on and (CHECK .. " ") or "     ") .. (on and PS.LABEL[k] or (GREY .. PS.LABEL[k] .. "|r")),
            function()
                PS.Toggle(k)
                -- open again: several switches in a row
                W.Menu(owner, styleEntries(owner))
            end, tip = PS.TIP[k], tipTitle = PS.LABEL[k] }
    end
    if PS.Count() > 0 then
        out[#out + 1] = { L["Alle aus"], function() PS.Clear() end }
    end
    return out
end

local function styleTooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(L["Spielstil"])
    local names = PS.Names()
    if not names then
        GameTooltip:AddLine(L["Aus: alle Quellen der Chips zählen. Klick: wählen, wie du spielst."], 1, 1, 1, true)
        GameTooltip:Show()
        return
    end
    GameTooltip:AddLine(names, 1, 1, 1, true)
    local h = ns.BisStyleHidden()
    if h.n > 0 then
        GameTooltip:AddLine(L["Spielstil blendet %d Ziele aus:"]:format(h.n), 1, 0.82, 0, true)
        for i = 1, math.min(STYLE_HIDDEN_LINES, #h.list) do
            local x = h.list[i]
            GameTooltip:AddDoubleLine(itemText(x.id), PS.WhyText(x.id, x.why), 1, 1, 1, 0.8, 0.8, 0.8)
        end
        if #h.list > STYLE_HIDDEN_LINES then GameTooltip:AddLine(L["und %d weitere"]:format(#h.list - STYLE_HIDDEN_LINES), 0.6, 0.6, 0.6) end
    else
        GameTooltip:AddLine(L["Der Spielstil blendet keines deiner Ziele aus."], 0.8, 0.8, 0.8, true)
    end
    GameTooltip:AddLine(L["Klick: Spielstil wählen"], 0.6, 0.6, 0.6)
    GameTooltip:Show()
end

-- The text of a row without an option: the shield hand beside a two-hander, the play style, none.
local function noOptionText(e)
    if e.key == "OFFHAND" and e.plan == "2H" then return L["Zweihandwaffe geplant"] end
    if PS.Count() > 0 then return L["Nichts mit diesem Spielstil"] end
    return L["keine Option"]
end

local function styleChip(parent)
    local chip = W.Tab(parent, L["Spielstil"], nil)
    chip:SetScript("OnClick", function(self) W.Menu(self, styleEntries(self)) end)
    chip:HookScript("OnEnter", styleTooltip)
    chip:HookScript("OnLeave", function() GameTooltip:Hide() end)
    W.FitChip(chip)
    return chip
end

local function fillStyle(chip)
    local n = PS.Count()
    chip.label:SetText(n > 0 and L["Spielstil (%d)"]:format(n) or L["Spielstil"])
    W.FitChip(chip)
    chip:SetOn(n > 0)
    chip:Show()
end

local chipsFor, chipsCache
local function chipSet()
    local set = CHIPS
    -- the raids chip shows once the data has raids; looked up once per data set
    local d = ns.Data("GEAR")
    if chipsFor == d then return chipsCache end
    local raids = false
    for _, rec in ipairs(d and d.S or {}) do
        if rec[1] == "X" then raids = true break end
    end
    local out = set
    if not raids then
        out = {}
        for i = 2, #set do out[#out + 1] = set[i] end
    end
    chipsFor, chipsCache = d, out
    return out
end

local function profClick()
    local src = ns.BisOpts().sources
    if not src.C then
        src.C = true
        ns.Set("bis.prof", "all")   -- l10n-ok: setting key
    elseif ns.Get("bis.prof") ~= "mine" and ns.BisSkills() then   -- l10n-ok: setting key
        ns.Set("bis.prof", "mine")   -- l10n-ok: setting key
    else
        src.C = false
        ns.Set("bis.prof", "all")   -- l10n-ok: setting key
    end
    ns.Fire("BIS_CHANGED")
end

-- The spec picker of the head row (here and on the dungeons page): a change is ns.BisSetSpec, so
-- both pages show the same spec.
local function specPicker(parent)
    return W.Picker(parent, 180, function(v) ns.BisSetSpec(v ~= "" and v or nil) end)
end

-- The spec: chosen, or guessed from the talents.
local function fillSpec(picker, o)
    local values = {}
    for _, sp in ipairs(Gear.Specs(o.class)) do values[#values + 1] = { value = sp.key, text = L[sp.name] } end
    values[#values + 1] = { value = "", text = L["aus den Talenten"] }
    picker:SetValues(values)
    picker:SetValue(o.spec)
    if o.guessed then picker.label:SetText(picker.label:GetText() .. " " .. GREY .. L["(geraten)"] .. "|r") end
end

local function fillHead(f, o, res, v)
    fillSpec(f.spec, o)
    for k, chip in pairs(f.views) do chip:SetOn(k == v) end
    if guildVisible() then f.views.guild:Show() else f.views.guild:Hide() end
    f.views.wish.label:SetText(L["Wunschliste (%d)"]:format(wishCount()))
    -- the new label (a large count, the English text) widens the chip and moves the guild chip
    W.FitChip(f.views.wish)
    if Gear.Available() then f.open:Show() else f.open:Hide() end
    f:Place(1, f.headRow, { f.open })
    f.counts:SetText(counts(o, res))
    if ns.BisExcludeCount() > 0 then f.reset:Show() else f.reset:Hide() end
    fillStyle(f.style)
    f:Place(2, { { f.counts, fill = true } }, { f.style, f.reset }, { shown = true })
    -- the source chips, in a row
    local shown, row = {}, {}
    for _, def in ipairs(chipSet()) do
        local chip = f.src[def[1]]
        shown[def[1]] = true
        row[#row + 1] = chip
        local on = o.sources[def[1]] and true or false
        chip:SetOn(on)
        if def[1] == "C" then
            chip.label:SetText(not on and L["Berufe"] or (o.prof == "mine" and L["Berufe: meine"] or L["Berufe: alle"]))
        end
        chip:Show()
    end
    for k, chip in pairs(f.src) do if not shown[k] then chip:Hide() end end
    if v == "goals" then
        local plans = {}
        for _, k in ipairs(ns.BIS_PLAN_ORDER) do plans[#plans + 1] = { value = k, text = L["Waffen: %s"]:format(ns.BIS_PLANS[k]) } end
        f.plan:SetValues(plans)
        f.plan:SetValue(o.plan or "auto")
        f.plan:Show()
    else
        f.plan:Hide()
    end
    f:Place(3, row, { f.plan }, { shown = true })
end

---------------------------------------------------------------------------
-- Ziele: the slots, the details of one, the explanation
---------------------------------------------------------------------------

local function selectedSlot()
    local slot = state().slot
    if ns.BIS_SLOT_NAME[slot] then return slot end
    return "HEAD"
end

local function selectSlot(key)
    state().slot = key
    scrolledTo = key
    ns.Refresh()
end

local function menuEntries(e, o)
    local id = e.id
    local out = { { L["Item ausschließen"], function() say(ns.BisExclude("item", id)) end } }
    local rec = firstSource(id, o)
    if rec and (rec[1] == "X" or rec[1] == "D") and rec[3] and rec[3] ~= "Trash" then
        out[#out + 1] = { L["Boss ausschließen"], function() say(ns.BisExclude("boss", rec[3])) end }
    end
    local place = rec and Gear.PlaceOf(rec)
    if place then out[#out + 1] = { L["Ort ausschließen"], function() say(ns.BisExclude("place", place)) end } end
    if e.wished then
        out[#out + 1] = { L["Von der Wunschliste nehmen"], function() ns.WishRemove(id) end }
    else
        out[#out + 1] = { L["Auf die Wunschliste"], function() say(ns.WishAdd(id)) end }
    end
    -- a row of its own place (Hier) keeps the menu on that place
    mapEntries(out, id, placeKey(e.rec))
    out[#out + 1] = { L["Link in den Chat"], function() insertLink(linkOf(id)) end }
    return out
end

local function toggleWish(id, wished)
    if wished then ns.WishRemove(id) else say(ns.WishAdd(id)) end
end

local function fillGoalRow(r, e)
    r.slot:SetText(e.name)
    local up = e.opt and e.opt.upgrade
    if up then r.slot:SetTextColor(1, 0.82, 0) else r.slot:SetTextColor(0.56, 0.53, 0.64) end
    r.worn:SetText(e.wornLink and linkText(e.wornLink) or (GREY .. L["nichts"] .. "|r"))
    if e.opt then
        r.best:SetText(marks(e.opt) .. itemText(e.opt.id))
        r.src:SetText(sourceText(e.opt.id, e.o, e.opt.pick))
        r.gain:SetText(gainText(e.opt))
    else
        r.best:SetText(GREY .. noOptionText(e) .. "|r")
        r.src:SetText("")
        r.gain:SetText("")
    end
    if e.key == selectedSlot() then r.sel:Show() else r.sel:Hide() end
end

-- the list is 590 wide (12 px for its scroll bar): the source gives them, the gain moves left; the
-- slot names in gold
local GOAL_COLS = { { "slot", 4, 66, "Slot", font = T.FONT.head }, { "worn", 74, 156, L["Angelegt"] },
    { "best", 234, 186, L["Bestes"] }, { "src", 424, 114, L["Quelle"] }, { "gain", 542, 44, L["Zuwachs"], justify = "RIGHT" } }

local function buildGoals(f)
    local G = W.Page(f, { view = true })
    G.headFrame, G.head = G:Columns(GOAL_COLS)
    G.list = G:List(GOAL_ROWS, ROW_H, function(r)
        r.sel = W.SelectBar(r)
        W.Cells(r, GOAL_COLS)
        r:SetScript("OnClick", function(self)
            local e = self.item
            if not e then return end
            if e.opt and modifiedClick(e.opt.id) then return end
            selectSlot(e.key)
        end)
        r:SetScript("OnEnter", function(self)
            local e = self.item
            if e and e.opt then itemTooltip(self, e.opt.id) end
        end)
        r:SetScript("OnLeave", hideTip)
    end, fillGoalRow)
    -- 11 of 17 slots (18 + 264 = 282 of the view's 406)

    -- the window "Ausrüstungsziele" (UI/GoalsWindow.lua), why the weights are as they are
    -- (tooltip), and the simulation of another class or level: 20 high, between the list (it ends
    -- at -282) and the first option (-302), from the right edge; the title takes the rest
    G.big = W.Button(G, L["Ausrüstungsziele"], 110, function() if ns.ToggleGoalsFrame then ns.ToggleGoalsFrame() end end,
        { height = T.ROW_BUTTON_H })
    W.FitChip(G.big, 110)
    W.Tooltip(G.big, L["Ausrüstungsziele"], L["Puppe, Liste und Rangliste je Slot in einem großen Fenster."])
    G.why = W.Link(G, L["Warum?"], nil)
    G.why:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L["Warum diese Gewichte"])
        for _, line in ipairs(ns.BisWhy()) do GameTooltip:AddLine(line, 1, 1, 1, true) end
        GameTooltip:Show()
    end)
    G.why:HookScript("OnLeave", hideTip)
    G.sim = W.Link(G, L["Simulation"], function() setView("sim") end)
    W.Tooltip(G.sim, L["Simulation"], L["Beste Items für eine andere Klasse, Spezialisierung oder Stufe, ohne deinen Besitz."])
    local reach = W.Row(G, { G.big, G.why, G.sim }, T.CHIP_GAP, 0, -282, { right = true })
    G.title = W.Text(G, T.FONT.title, T.PAGE_W - reach - T.LAYOUT.ITEM_GAP - T.LAYOUT.TEXT_X)
    G.title:SetPoint("TOPLEFT", T.LAYOUT.TEXT_X, -286)
    G.opts = {}
    for i = 1, 3 do
        local b = CreateFrame("Button", nil, G)
        b:SetHeight(25)
        b:SetPoint("TOPLEFT", 0, -302 - (i - 1) * 26)
        b:SetPoint("TOPRIGHT", 0, -302 - (i - 1) * 26)
        W.Flat(b, 1, 1, 1, 0.04)
        -- lights up as the recipe list's rows do
        b.hover = b:CreateTexture(nil, "HIGHLIGHT")
        b.hover:SetAllPoints()
        if W.HasAtlas("Professions_Recipe_Hover") then
            b.hover:SetAtlas("Professions_Recipe_Hover")
            b.hover:SetAlpha(0.5)
        else
            b.hover:SetColorTexture(1, 1, 1, 0.08)
        end
        b.rank = col(b, 4, 12, nil, T.FONT.head)
        b.name = col(b, 20, 212, nil, T.FONT.text)
        -- the map button sits in the 18 px before the source
        b.map = mapButton(b, 236)
        b.src = col(b, 254, 174, nil, T.FONT.text)
        b.gain = col(b, 432, 46, nil, T.FONT.text)
        b.gain:SetJustifyH("RIGHT")
        b.wish = W.Button(b, L["Wunsch##Knopf"], 78, function(self)
            local e = self:GetParent().opt
            if e then toggleWish(e.id, e.wished) end
        end)
        b.ex = W.Button(b, L["Aus##ausschließen"], 36, function(self)
            local e = self:GetParent().opt
            if e then say(ns.BisExclude("item", e.id)) end
        end)
        W.FitChip(b.ex, 36)
        W.Row(b, { b.wish, b.ex }, T.CHIP_GAP, 0, 0, { right = true, point = "RIGHT" })
        -- shown while the mouse is on the option (D-67)
        W.RowAction(b, b.wish)
        W.RowAction(b, b.ex)
        W.Tooltip(b.ex, L["Ausschließen"], L["Das Item nicht mehr vorschlagen; die nächste Option rückt auf. Rechtsklick auf die Zeile: Boss oder Ort ausschließen."])
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        b:SetScript("OnClick", function(self, button)
            local e = self.opt
            if not e then return end
            if button == "RightButton" then
                W.Menu(self, menuEntries(e, ns.BisOpts()))
                return
            end
            modifiedClick(e.id)
        end)
        b:SetScript("OnEnter", function(self) if self.opt then itemTooltip(self, self.opt.id) end end)
        b:SetScript("OnLeave", hideTip)
        G.opts[i] = b
    end
    G.explain = W.Text(G, T.FONT.text, 590, true)
    G.explain:SetPoint("TOPLEFT", T.LAYOUT.TEXT_X, -382)
    G.explain:SetHeight(24)
    G.explain:SetJustifyV("TOP")
    G.explain:SetMaxLines(2)
    -- the explanation in full on hover: option 1 against 2 and against what is worn
    G.explainHit = CreateFrame("Frame", nil, G)
    G.explainHit:SetPoint("TOPLEFT", G.explain, "TOPLEFT")
    G.explainHit:SetPoint("BOTTOMRIGHT", G.explain, "BOTTOMRIGHT")
    G.explainHit:EnableMouse(true)
    G.explainHit:SetScript("OnEnter", function(self)
        if not self.lines or #self.lines == 0 then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(self.title or L["Vergleich"])
        for _, line in ipairs(self.lines) do GameTooltip:AddLine(line, 1, 1, 1, true) end
        GameTooltip:Show()
    end)
    G.explainHit:SetScript("OnLeave", hideTip)
    return G
end

-- The comparison lines of a slot: option 1 against option 2 and against the worn item.
local function compareLines(o, list, wornLink)
    local c = cached()
    local first = list[1]
    if not first then return {} end
    local key = "cmp|" .. first.id .. "|" .. (list[2] and list[2].id or 0) .. "|" .. tostring(wornLink)
    if c.explain[key] then return c.explain[key] end
    local lines = {}
    for _, n in ipairs(noteParts(first)) do lines[#lines + 1] = GREY .. n .. "|r" end
    local second = list[2]
    if second then
        -- the options themselves: their random suffix and set bonus share count as in the ranking
        local cmp = ns.BisCompare(first, second, o, { L["Option 1"], L["Option 2"] })
        if cmp then
            lines[#lines + 1] = cmp.text
            for i = 1, math.min(4, #cmp.lines) do lines[#lines + 1] = "  " .. cmp.lines[i] end
        end
    end
    if wornLink and not first.worn then
        local cmp = ns.BisCompare(first, wornLink, o, { L["Option 1"], L["das Angelegte"] })
        if cmp then
            lines[#lines + 1] = cmp.text
            for i = 1, math.min(4, #cmp.lines) do lines[#lines + 1] = "  " .. cmp.lines[i] end
        end
    end
    -- the exact change on the own values (D-54; BisExplainModel leaves out a simulation)
    if not first.worn and ns.BisExplainModel then
        local m = ns.BisExplainModel(first.id, o)
        for i, line in ipairs(m) do lines[#lines + 1] = (i == 1 and "" or "  ") .. line end
    end
    c.explain[key] = lines
    return lines
end

-- The explanation of an option as one text, kept until the state changes.
local function explainText(o, res, slotKey, e)
    local c = cached()
    local key = slotKey .. "|" .. (e and e.id or 0)
    if c.explain[key] then return c.explain[key] end
    local out = {}
    if (slotKey == "MAINHAND" or slotKey == "OFFHAND") and res.twoHandScore and res.oneHandScore then
        local more = {}
        if res.dwScore then more[#more + 1] = L["zwei Waffen %s"]:format(Gear.Num(res.dwScore)) end
        if res.shieldScore then more[#more + 1] = L["mit Schild %s"]:format(Gear.Num(res.shieldScore)) end
        out[#out + 1] = L["Zweihand %s gegen Waffenhand plus Schildhand %s%s."]:format(Gear.Num(res.twoHandScore),
            Gear.Num(res.oneHandScore), #more > 0 and (" (" .. table.concat(more, ", ") .. ")") or "")
    end
    if not e then
        out[#out + 1] = (slotKey == "OFFHAND" and res.plan == "2H") and L["Die Zweihandwaffe belegt beide Hände."]
            or L["Für diesen Slot gibt es keine Option in den Daten."]
    else
        local lines = ns.BisExplain(e.id, o)
        if #lines <= 1 then
            out[#out + 1] = lines[1] or ""
        else
            local lead
            if e.worn then
                lead = L["angelegt"]
            elseif e.switch then
                lead = L["Waffenwechsel"]
            else
                lead = Gear.UnitText(e.gain or 0, Gear.Weights(o.class, o.spec, o.kind, o.level))
            end
            local parts = {}
            for i = 2, #lines do
                -- the pick's note is a sentence of its own (BisExplain's last line)
                if not (e.pick and lines[i] == ns.BisPickText(e.pick)) then parts[#parts + 1] = lines[i] end
            end
            out[#out + 1] = lead .. ": " .. table.concat(parts, ", ") .. "."
        end
        if e.pick then out[#out + 1] = ns.BisPickText(e.pick) end
    end
    local text = table.concat(out, " ")
    c.explain[key] = text
    return text
end

local function goalItems(res, o)
    local c = cached()
    if c.goalsRes == res then return c.goals end
    local items = {}
    for _, sl in ipairs(Gear.SLOTS) do
        local link = GetInventoryItemLink and ns.Plain(GetInventoryItemLink("player", sl.inv))
        items[#items + 1] = { key = sl.key, name = sl.name, wornLink = type(link) == "string" and link or nil,
            opt = res[sl.key] and res[sl.key][1], plan = res.plan, o = o }
    end
    c.goalsRes, c.goals = res, items
    return items
end

local function fillGoals(G, o, res)
    local items = goalItems(res, o)
    local slot = selectedSlot()
    -- a slot chosen from outside (the toast) is scrolled into view once
    if scrolledTo ~= slot then
        scrolledTo = slot
        for i, e in ipairs(items) do
            if e.key == slot and (i <= G.list.offset or i > G.list.offset + GOAL_ROWS) then
                G.list.offset = math.max(0, math.min(i - 1, #items - GOAL_ROWS))
            end
        end
    end
    G.list:SetItems(items)
    local sp = Gear.SpecInfo(o.class, o.spec)
    G.title:SetText(L["%s · Bestes für %s%s"]:format(ns.BIS_SLOT_NAME[slot] or slot, sp and L[sp.name] or "?", o.guessed and L[" (geraten)"] or ""))
    local list = res[slot] or {}
    for i, b in ipairs(G.opts) do
        local e = list[i]
        b.opt = e
        if e then
            b.rank:SetText(tostring(i))
            b.name:SetText(marks(e) .. itemText(e.id) .. noteText(e))
            b.src:SetText(e.owned and OWNED_TEXT[e.owned] or sourceText(e.id, o, e.pick))
            setMapButton(b.map, e.id, nil, e.owned)
            b.gain:SetText(gainText(e))
            if e.worn then
                b.wish:Hide()
                b.ex:Hide()
            else
                b.wish:SetText(e.wished and L["Wunsch weg"] or L["Wunsch##Knopf"])
                b.wish:Show()
                b.ex:Show()
            end
            b:Show()
        else
            setMapButton(b.map, nil)
            b:Hide()
        end
    end
    G.explain:SetText(explainText(o, res, slot, list[1]))
    local wornLink
    for _, e in ipairs(goalItems(res, o)) do if e.key == slot then wornLink = e.wornLink end end
    G.explainHit.title = ns.BIS_SLOT_NAME[slot] or slot
    G.explainHit.lines = compareLines(o, list, wornLink)
end

---------------------------------------------------------------------------
-- Hier: a place and what it still offers
---------------------------------------------------------------------------

local function bossText(rec)
    if not rec then return "" end
    if (rec[1] == "X" or rec[1] == "D") and rec[3] then return rec[3] end
    return Gear.SourceText(rec, true)
end

local function fillHereRow(r, e)
    r.boss:SetText(bossText(e.rec))
    -- an entrance means nothing inside the instance
    setMapButton(r.map, e.id, e.rec, inInstance())
    r.name:SetText(marks(e) .. itemText(e.id))
    r.slot:SetText(ns.BIS_SLOT_NAME[e.slotKey] or "")
    r.gain:SetText(gainText(e))
    if e.owned then
        r.wishBtn:Hide()
    else
        r.wishBtn:SetText(e.wished and L["Wunsch weg"] or L["Wunsch##Knopf"])
        r.wishBtn:Show()
    end
end

-- the list is 590 wide (12 px for its scroll bar): the gain gives 6, the button moves left; the
-- boss cell starts after the map button (cx)
local HERE_COLS = { { "boss", 4, 146, "Boss", cx = 22, cw = 128 }, { "name", 154, 216, "Item" }, { "slot", 374, 76, "Slot" },
    { "gain", 454, 50, L["Zuwachs"], justify = "RIGHT" } }

local function buildHere(f)
    -- the place, the list, what the place offers in the footer
    local Hh = W.Page(f, { view = true })
    Hh:Bands({ "row" })
    Hh.pick = W.Picker(Hh, 240, function(v)
        placeGone = false
        state().place = (v ~= "here") and v or nil
        ns.Refresh()
    end)
    Hh:Place(1, { Hh.pick })
    Hh:Footer({ "hint" })
    Hh.headFrame, Hh.head = Hh:Columns(HERE_COLS)
    Hh.list = Hh:List(HERE_ROWS, ROW_H, function(r)
        r.map = mapButton(r, 4)
        W.Cells(r, HERE_COLS)
        r.wishBtn = W.Button(r, L["Wunsch##Knopf"], 82, function(self)
            local e = self:GetParent().item
            if e then toggleWish(e.id, e.wished) end
        end, { height = T.ROW_BUTTON_H })
        r.wishBtn:SetPoint("LEFT", 508, 0)
        W.RowAction(r, r.wishBtn)
        r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        r:SetScript("OnClick", function(self, button)
            local e = self.item
            if not e then return end
            if button == "RightButton" then
                W.Menu(self, menuEntries(e, ns.BisOpts()))
                return
            end
            modifiedClick(e.id)
        end)
        r:SetScript("OnEnter", function(self) if self.item then itemTooltip(self, self.item.id) end end)
        r:SetScript("OnLeave", hideTip)
    end, fillHereRow)
    return Hh
end

local function fillHere(Hh, o)
    local chosen = state().place
    local cur = ns.BisCurrentPlace()
    local values = { { value = "here", text = L["Hier: %s"]:format((cur and cur.text) or L["unbekannt"]) } }
    local found = false
    for _, p in ipairs(ns.BisPlaces()) do
        values[#values + 1] = { value = p.key, text = p.text }
        if p.key == chosen then found = true end
    end
    -- a saved place the data no longer has (another data set, a rebuilt one): the own place again,
    -- said until another place is picked
    if chosen ~= nil and not found then
        chosen = nil
        state().place = nil
        placeGone = true
    end
    local gone = placeGone
    Hh.pick:SetValues(values)
    Hh.pick:SetValue(chosen or "here")
    local place, list = ns.BisHere(chosen, o)
    Hh.list:SetItems(list)
    local hint
    if not place or not placeKnown(place) then
        hint = L["Diesen Ort kennen die Daten nicht."]
    elseif #list == 0 then
        hint = PS.Count() > 0 and L["Hier gibt es mit diesem Spielstil nichts für dich."] or L["Hier gibt es nichts mehr für dich."]
    else
        hint = L["Was du an diesem Ort noch holen kannst: Upgrades und Wünsche, Besitz unten."]
    end
    if place and (place.loading or 0) > 0 then hint = hint .. " · " .. L["lädt noch %d Items"]:format(place.loading) end
    if gone then hint = L["Der gewählte Ort fehlt in den Daten, gezeigt wird der aktuelle."] .. " " .. hint end
    Hh.hint:SetText(hint)
end

---------------------------------------------------------------------------
-- Wunschliste: the own wishes and their text for the website
---------------------------------------------------------------------------

local function fillWishRow(r, e)
    r.name:SetText(itemText(e.id))
    r.slot:SetText(e.slot or "")
    r.src:SetText(e.src or "")
    setMapButton(r.map, e.id, nil, e.owned)
    r.prio.label:SetText(PRIO_TEXT[e.e.prio] or PRIO_TEXT[2])
    r.prio:SetOn(e.e.prio == 3)
    if e.owned then
        r.state:SetText(L["hast du"])
        r.state:SetTextColor(0.31, 0.82, 0.42)
    elseif e.excluded then
        r.state:SetText(L["aus##ausgeschlossen"])
        r.state:SetTextColor(0.56, 0.53, 0.64)
    else
        r.state:SetText("")
    end
end

local function setExport(V, text)
    exportText = text or ""
    V.area.box:SetText(exportText)
end

-- the list is 590 wide (12 px for its scroll bar): the source gives them, what follows moves left;
-- the source cell after the map button, the priority a chip
local WISH_COLS = { { "name", 4, 216, "Item" }, { "slot", 224, 76, "Slot" }, { "src", 304, 154, L["Quelle"], cx = 322, cw = 136 },
    { "prio", 462, 58, L["Priorität"], cell = false }, { "state", 524, 44, "" } }

local function buildWish(f)
    -- the wishes (or their text for the website), the buttons in the bottom row, the hint in the footer
    local V = W.Page(f, { view = true })
    V:Footer({ { "hint", lines = 2 } })
    V.headFrame, V.head = V:Columns(WISH_COLS)
    V.list = V:List(WISH_ROWS, ROW_H, function(r)
        W.Cells(r, WISH_COLS)
        r.map = mapButton(r, 304)
        r.prio = W.Chip(r, "", 58, function(self)
            local e = self:GetParent().item
            if e then ns.WishSetPrio(e.id, PRIO_NEXT[e.e.prio] or 2) end
        end)
        r.prio:SetPoint("LEFT", 462, 0)
        r.del = W.ResetButton(r, T.RESET, function(self)
            local e = self:GetParent().item
            if e then ns.WishRemove(e.id) end
        end)
        r.del:SetPoint("LEFT", 572, 0)
        r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        r:SetScript("OnClick", function(self, button)
            local e = self.item
            if not e then return end
            if button == "RightButton" then
                W.Menu(self, menuEntries({ id = e.id, wished = true }, ns.BisOpts()))
                return
            end
            modifiedClick(e.id)
        end)
        r:SetScript("OnEnter", function(self) if self.item then itemTooltip(self, self.item.id) end end)
        r:SetScript("OnLeave", hideTip)
    end, fillWishRow)

    V.area = W.ReadOnlyArea(V, function() return exportText or "" end)
    V.area:SetPoint("TOPLEFT", 0, V.listTop)
    V.area:SetPoint("TOPRIGHT", 0, V.listTop)
    V.area:SetHeight(120)
    V.area:Hide()
    V.areaHint = W.Text(V, T.FONT.hint, 590, true)
    V.areaHint:SetPoint("TOPLEFT", V.area, "BOTTOMLEFT", T.LAYOUT.TEXT_X, -T.LAYOUT.GAP)
    V.areaHint:SetHeight(28)
    V.areaHint:SetText(L["Strg+A, Strg+C, auf der Website im Reiter Wishlist bei Paste from the addon einfügen."])
    V.areaHint:Hide()

    V.web = W.Button(V, L["Für die Website"], 120, function()
        exportOpen = not exportOpen
        if exportOpen then
            setExport(V, ns.WishExportText())
            V.area.box:SetFocus()
            V.area.box:HighlightText()
        else
            V.area.box:ClearFocus()
        end
        ns.Refresh()
    end)
    V.clean = W.Link(V, L["Erhaltene entfernen"], function()
        for _, e in ipairs(ns.Wishes()) do
            if e.owned then ns.WishRemove(e.id) end
        end
    end)
    W.FitChip(V.web, 120)
    W.FitChip(V.clean)
    V:BottomRow({ V.web, V.clean })
    return V
end

local function fillWish(V)
    local c = cached()
    if not c.wishes then c.wishes = ns.Wishes() end
    local list = c.wishes
    V.list:SetItems(list)
    if exportOpen then
        V.list:Hide()
        V.area:Show()
        V.areaHint:Show()
        V.web:SetText(L["Zur Liste"])
        -- the text follows the list unless the box is in use
        if not V.area.box:HasFocus() then
            local text = ns.WishExportText()
            if text ~= exportText then setExport(V, text) end
        end
    else
        V.area:Hide()
        V.areaHint:Hide()
        V.list:Show()
        V.web:SetText(L["Für die Website"])
    end
    local owned = false
    for _, e in ipairs(list) do if e.owned then owned = true break end end
    if ns.Get("bis.wishAutoRemove") then   -- l10n-ok: setting key
        V.clean:Hide()
    else
        V.clean:Show()
        V.clean:SetEnabled(owned)
    end
    if #list == 0 then
        V.hint:SetText(L["Noch keine Wünsche. Wunsch-Knopf in Ziele oder Hier, oder /amisia wunsch <Item-Link>."])
    else
        V.hint:SetText(L["%d von %d Wünschen. Ein Klick auf die Priorität ändert sie."]:format(#list, ns.BIS_MAX_WISH or 50))
    end
end

---------------------------------------------------------------------------
-- Gilde: the website's wishlist in the game
---------------------------------------------------------------------------

local function onlyGroup()
    if groupOnly ~= nil then return groupOnly end
    return IsInRaid() and true or false
end

local classColored = ns.ClassColored

local guildKey, guildList
local function guildItems(only)
    local g = AmisiaDB.bis and AmisiaDB.bis.guild
    if type(g) ~= "table" or type(g.list) ~= "table" then return {} end
    local roster = ns.GroupRoster()
    local key = table.concat({ tostring(g.list), tostring(g.at), tostring(only), table.concat(roster, ",") }, "|")
    if key == guildKey then return guildList end
    -- the class of everyone in the raid, for the colours
    local classes = {}
    if IsInRaid() then
        for i = 1, GetNumGroupMembers() or 0 do
            local name, _, _, _, _, class = GetRaidRosterInfo(i)
            name, class = ns.FullName(ns.Plain(name)), ns.Plain(class)
            if name then classes[name:lower()] = class end
        end
    end
    local out = {}
    for id in pairs(g.list) do
        local ws = ns.WishersOf(id, only)
        if #ws > 0 then
            local names = {}
            for _, w in ipairs(ws) do
                local text = w.name .. (PRIO_TIP[w.prio] or "")
                if w.inGroup then
                    local class = classes[w.name:lower()]
                    if not class then
                        for _, r in ipairs(roster) do
                            if ns.SameNameIn(w.name, r, roster) then class = classes[r:lower()] break end
                        end
                    end
                    names[#names + 1] = classColored(text, class)
                else
                    names[#names + 1] = GREY .. text .. "|r"
                end
            end
            out[#out + 1] = { id = id, n = #ws, who = table.concat(names, ", ") }
        end
    end
    table.sort(out, function(a, b)
        if a.n ~= b.n then return a.n > b.n end
        return a.id < b.id
    end)
    guildKey, guildList = key, out
    return out
end

-- the list is 590 wide (12 px for its scroll bar), the wishers give them
local GUILD_COLS = { { "name", 4, 256, "Item" }, { "who", 264, 322, L["Wünschende"] } }

local function buildGuild(f)
    -- the list's state with "Nur Gruppe", the wishes; officers paste the website's text under it
    local U = W.Page(f, { view = true })
    U:Bands({ "row" })
    U.info = W.Text(U, T.FONT.text)
    U.group = W.TabCheck(U, L["Nur Gruppe"], function()
        groupOnly = not onlyGroup()
        ns.Refresh()
    end)
    W.FitChip(U.group)
    U:Place(1, { { U.info, fill = true } }, { U.group })
    U.headFrame, U.head = U:Columns(GUILD_COLS)
    U.list = U:List(GUILD_ROWS, ROW_H, function(r)
        W.Cells(r, GUILD_COLS)
        r:SetScript("OnClick", function(self) if self.item then modifiedClick(self.item.id) end end)
        r:SetScript("OnEnter", function(self) if self.item then itemTooltip(self, self.item.id) end end)
        r:SetScript("OnLeave", hideTip)
    end, function(r, e)
        r.name:SetText(itemText(e.id))
        r.who:SetText(e.who)
    end)
    U.area = W.EditArea(U)
    U.importBtn = W.Button(U, L["Importieren"], 100, function()
        -- the website's text: the wishes, the alts and the loot prio (any of them)
        local text, ok = ns.ImportSiteText(U.area.box:GetText())
        if ok then
            U.area.box:SetText("")
            U.area.box:ClearFocus()
        end
        guildResult = text
        ns.Refresh()
    end)
    U.clearBtn = W.Link(U, L["Löschen##Gildenwünsche"], function()
        lift(StaticPopup_Show("AMISIA_GUILDWISH_CLEAR"))
    end)
    W.FitChip(U.importBtn, 100)
    W.FitChip(U.clearBtn)
    U.hint = W.Text(U, T.FONT.hint)
    -- the import, clear and what the last import said in the bottom row; the box between it and the list
    U.bottomList = { U.importBtn, U.clearBtn, { U.hint, fill = true } }
    U:BottomRow(U.bottomList)
    U.area:SetPoint("TOPLEFT", U.list, "BOTTOMLEFT", 0, -T.LAYOUT.GAP)
    U.area:SetPoint("BOTTOMRIGHT", 0, U:Bottom())
    return U
end

local function fillGuild(U)
    local officer = ns.IsOfficerView()
    local info = ns.GuildWishesInfo()
    local age = ns.GuildWishesAgeText()
    if info then
        U.info:SetText((info.n == 1 and L["Liste vom %s, 1 Wunsch"] or L["Liste vom %s, %d Wünsche"]):format(longDate(info.date), info.n)
            .. (age and (" " .. GREY .. age .. "|r") or ""))
    else
        U.info:SetText(GREY .. L["Keine Gildenwünsche geladen."] .. "|r")
    end
    local alts = ns.AltsInfo()
    if alts then
        U.info:SetText(U.info:GetText() .. " · " .. (alts.n == 1 and L["1 Twink"] or L["%d Twinks"]:format(alts.n)))
    end
    local only = onlyGroup()
    U.group:SetOn(only)
    U.list:SetItems(guildItems(only))
    if officer then
        U.area:Show(); U.importBtn:Show(); U.clearBtn:Show()
        U.clearBtn:SetEnabled(info ~= nil)
        U.hint:SetText(guildResult or L["Auf der Website im Reiter Wishlist: Copy for the addon."])
    else
        U.area:Hide(); U.importBtn:Hide(); U.clearBtn:Hide()
        U.hint:SetText(age or "")
    end
    -- raiders: the hint alone in the bottom row
    U:BottomRow(U.bottomList, nil, { shown = true })
end

---------------------------------------------------------------------------
-- Simulation: the best items of any class, spec and level (ns.BisFor), without ownership
---------------------------------------------------------------------------

local SIM_ROWS = 11

-- The simulated character in settings.bis.sim: class, spec, level, weapon plan; starts as the own.
local function simState()
    local st = state()
    st.sim = type(st.sim) == "table" and st.sim or {}
    local sim = st.sim
    local _, myClass = UnitClass("player")
    if not (type(sim.class) == "string" and #Gear.Specs(sim.class) > 0) then sim.class = myClass or "WARRIOR" end
    local ok = false
    for _, sp in ipairs(Gear.Specs(sim.class)) do if sp.key == sim.spec then ok = true end end
    if not ok then sim.spec = (Gear.Specs(sim.class)[1] or {}).key end
    sim.level = math.max(1, math.min(tonumber(sim.level) or tonumber(UnitLevel("player")) or 1, Gear.Cap()))
    if not ns.BIS_PLANS[sim.plan] then sim.plan = "auto" end
    return sim
end
ns.BisSimState = simState

local function simChanged()
    ns.Refresh()
end

local function fillSimRow(r, e)
    r.slot:SetText(e.name)
    if e.opt then
        r.best:SetText(itemText(e.opt[1]) .. noteText(e.opt))
        r.src:SetText(sourceText(e.opt[1], nil, e.opt.pick))
        r.score:SetText(Gear.Num(e.opt[2]))
    else
        r.best:SetText(GREY .. ((e.key == "OFFHAND" and e.plan == "2H") and L["Zweihandwaffe geplant"] or L["keine Option"]) .. "|r")
        r.src:SetText("")
        r.score:SetText("")
    end
end

local SIM_COLS = { { "slot", 4, 66, "Slot", font = T.FONT.head }, { "best", 74, 250, L["Bestes"] },
    { "src", 328, 200, L["Quelle"] }, { "score", 532, 54, L["Wertung"], justify = "RIGHT" } }

local function buildSim(f)
    -- the simulated character with the way back, the list, what the weights mean in the footer
    local S = W.Page(f, { view = true })
    S:Bands({ "row" })
    S.class = W.Picker(S, 118, function(v)
        local sim = simState()
        sim.class, sim.spec = v, nil
        simChanged()
    end)
    S.spec = W.Picker(S, 140, function(v)
        simState().spec = v
        simChanged()
    end)
    S.level = W.Stepper(S, 104, function(v)
        simState().level = v
        simChanged()
    end)
    S.plan = W.Picker(S, 132, function(v)
        simState().plan = v
        simChanged()
    end)
    S.back = W.Link(S, L["Zurück"], function() setView("goals") end)
    W.FitChip(S.back)
    S:Place(1, { S.class, S.spec, S.level, S.plan }, { S.back })
    S:Footer({ { "info", lines = 3 } })
    S.headFrame, S.head = S:Columns(SIM_COLS)
    S.list = S:List(SIM_ROWS, ROW_H, function(r)
        W.Cells(r, SIM_COLS)
        r:SetScript("OnClick", function(self)
            local e = self.item
            if e and e.opt then modifiedClick(e.opt[1]) end
        end)
        r:SetScript("OnEnter", function(self)
            local e = self.item
            if e and e.opt then itemTooltip(self, e.opt[1]) end
        end)
        r:SetScript("OnLeave", hideTip)
    end, fillSimRow)
    return S
end

local function fillSim(S)
    local sim = simState()
    local classes = {}
    for _, token in ipairs(ns.GEAR_WEIGHTS and ns.GEAR_WEIGHTS.order or {}) do
        classes[#classes + 1] = { value = token, text = Gear.CLASS_NAMES[token] or token }
    end
    S.class:SetValues(classes)
    S.class:SetValue(sim.class)
    local specs = {}
    for _, sp in ipairs(Gear.Specs(sim.class)) do specs[#specs + 1] = { value = sp.key, text = L[sp.name] } end
    S.spec:SetValues(specs)
    S.spec:SetValue(sim.spec)
    S.level:Configure(1, Gear.Cap(), 1, function(v) return "Level " .. v end)
    S.level:SetValue(sim.level)
    local plans = {}
    for _, k in ipairs(ns.BIS_PLAN_ORDER) do plans[#plans + 1] = { value = k, text = L["Waffen: %s"]:format(ns.BIS_PLANS[k]) } end
    S.plan:SetValues(plans)
    S.plan:SetValue(sim.plan)
    -- the result, kept until anything the gear page depends on changes
    local c = cached()
    local key = table.concat({ sim.class, tostring(sim.spec), sim.level, sim.plan }, "|")
    if c.simKey ~= key then
        c.simKey = key
        c.sim = ns.BisFor(sim.class, sim.spec, sim.level, { plan = sim.plan })
    end
    local res = c.sim
    local items = {}
    for _, sl in ipairs(Gear.SLOTS) do
        items[#items + 1] = { key = sl.key, name = sl.name, opt = res[sl.key] and res[sl.key][1], plan = res.plan }
    end
    S.list:SetItems(items)
    local o = { class = sim.class, spec = sim.spec, kind = ns.Get("bis.kind") or "Speedrun", level = sim.level }   -- l10n-ok: setting key
    local lines = ns.BisWhy(o)
    S.info:SetText(GREY .. L["Ohne Besitz und Zuwachs, mit deinen Quellen."] .. " " .. table.concat(lines, " ") .. "|r")
end

---------------------------------------------------------------------------
-- The page
---------------------------------------------------------------------------

-- What the dungeons page (Pages/Dungeons.lua, loaded after this file) draws with: the same cache,
-- item texts, marks, tooltips, clicks and menus as the gear page, and its spec picker.
ns.GearPageKit = {
    state = state, cached = cached, itemText = itemText, marks = marks, gainText = gainText,
    itemTooltip = itemTooltip, hideTip = hideTip, modifiedClick = modifiedClick, menuEntries = menuEntries,
    say = say, col = col, specPicker = specPicker, fillSpec = fillSpec, styleChip = styleChip, fillStyle = fillStyle,
    noOptionText = noOptionText,
    -- for the window "Ausrüstungsziele": the source text, the map button, the link and whether a shown
    -- row had no item name yet
    sourceText = sourceText, mapButton = mapButton, setMapButton = setMapButton, linkOf = linkOf, pctText = pctText,
    OWNED_TEXT = OWNED_TEXT,
    nameMissing = function() return nameMissing end,
    -- a refresh starts with no missing item name; GET_ITEM_INFO_RECEIVED fills its rows again
    namesFresh = function() nameMissing = false end,
}

StaticPopupDialogs["AMISIA_BIS_CLEAR_EX"] = {
    text = L["Alle Ausschlüsse aufheben?"],
    button1 = L["Aufheben"],
    button2 = L["Abbrechen"],
    OnAccept = function() ns.BisClearExcludes() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

ns.RegisterPanel{ key = "gear", label = L["Ausrüstung"], sub = L["Das beste Item je Platz und woher du es bekommst."], icon = "Interface\\Icons\\INV_Chest_Chain_05", order = 50, group = "gear",
    available = function() return Gear.Available() end,
    create = function(parent)
        local f = W.Page(parent)
        -- the head row: spec, views, the table; the counts with the reset of exclusions; the source
        -- chips with the weapon plan; the views under them
        f:Bands({ "row", "line", "row" })
        f.spec = specPicker(f)
        f.views = {}
        f.views.goals = W.Tab(f, L["Ziele"], function() setView("goals") end)
        f.views.here = W.Tab(f, L["Hier"], function() state().place = nil; setView("here") end)
        f.views.wish = W.Tab(f, L["Wunschliste"], function() setView("wish") end)
        f.views.guild = W.Tab(f, L["Gilde"], function() setView("guild") end)
        W.Tooltip(f.views.goals, L["Ziele"], L["Das beste erreichbare Item je Slot mit deinen Quellen."])
        W.Tooltip(f.views.here, L["Hier"], L["Items aus der Zone oder dem Dungeon, in dem du gerade bist."])
        W.Tooltip(f.views.wish, L["Wunschliste"], L["Die Items, die du dir gemerkt hast."])
        W.Tooltip(f.views.guild, L["Gilde"], L["Die Wunschlisten deiner Gilde von der Website."])
        -- 64 wide: the tooltip says what the table is
        f.open = W.Link(f, L["Tabelle"], function() ns.ToggleGearFrame() end)
        W.Tooltip(f.open, L["Ausrüstungstabelle"], L["Die besten Items aller Levelbereiche für jede Spezialisierung."])
        f.headRow = { f.spec, f.views.goals, f.views.here, f.views.wish, f.views.guild }
        f:Place(1, f.headRow, { f.open })
        f.counts = W.Text(f, T.FONT.hint)
        -- a row button (20 high): it stands in the counts' line, between the bands around it
        f.reset = W.Link(f, L["zurücksetzen"], function() lift(StaticPopup_Show("AMISIA_BIS_CLEAR_EX")) end)
        W.FitChip(f.reset)
        f.style = styleChip(f)
        f:Place(2, { { f.counts, fill = true } }, { f.style, f.reset })
        -- the weapon plan of the own character, beside the source chips of the targets
        f.plan = W.Picker(f, 132, function(v) say(ns.BisSetPlan(v)) end)
        f.src = {}
        for _, def in ipairs(CHIPS) do
            local key = def[1]
            f.src[key] = W.TabCheck(f, def[2], function()
                if key == "C" then
                    profClick()
                else
                    local src = ns.BisOpts().sources
                    src[key] = not src[key]
                    ns.Fire("BIS_CHANGED")
                end
            end)
            -- as wide as given, wider where the text (English) needs it
            W.FitChip(f.src[key], def[3])
        end
        f.goals = buildGoals(f)
        f.here = buildHere(f)
        f.wish = buildWish(f)
        f.guild = buildGuild(f)
        f.sim = buildSim(f)
        f.bodies = { goals = f.goals, here = f.here, wish = f.wish, guild = f.guild, sim = f.sim }
        for _, b in pairs(f.bodies) do b:Hide() end
        return f
    end,
    refresh = function(f)
        nameMissing = false
        local o = ns.BisOpts()
        local res = ns.BisTargets()
        local v = shownView()
        fillHead(f, o, res, v)
        for k, body in pairs(f.bodies) do
            if k ~= v then body:Hide() end
        end
        f.bodies[v]:Show()
        if v == "goals" then
            fillGoals(f.goals, o, res)
        elseif v == "here" then
            fillHere(f.here, o)
        elseif v == "wish" then
            fillWish(f.wish)
        elseif v == "sim" then
            fillSim(f.sim)
        else
            fillGuild(f.guild)
        end
    end }

-- A wish, an exclusion, the spec or the guild list changed: show it at once (a click's answer).
-- The raid journal shows the gear page's spec picker and item texts, so it is one of them.
local function onGearPage()
    local cur = ns.CurrentPage and ns.CurrentPage()
    return cur == "gear" or cur == "dungeons" or cur == "raidjournal" or cur == "overview"
end
local function refreshShown() if onGearPage() then ns.Refresh() end end
-- the own items changed: with the next frame (a bag sort or a gear set swap changes many in one frame)
local function refreshOwned() if onGearPage() then ns.RefreshSoon() end end
ns.Listen("BIS_CHANGED", refreshShown)
-- a new or cleared list: what the last import said is over (an import sets its result afterwards)
ns.Listen("GUILD_WISHES", function()
    guildResult = nil
    refreshShown()
end)
ns.Listen("ALTS", refreshShown)
ns.BisOnOwned(refreshOwned)

-- Item names the client did not have at the last refresh: once item data arrives the shown rows
-- are filled again, once for a burst of answers, and the wishlist (sorted by name) and the guild
-- list are built again.
local namesDue = false
ns.OnEvent("GET_ITEM_INFO_RECEIVED", function()
    if not nameMissing or namesDue then return end
    namesDue = true
    C_Timer.After(0.3, function()
        namesDue = false
        local cur = ns.CurrentPage and ns.CurrentPage()
        if not nameMissing or not (cur == "gear" or cur == "dungeons" or cur == "raidjournal") then return end
        memo.wishes = nil
        guildKey = nil
        ns.Refresh()
    end)
end)

---------------------------------------------------------------------------
-- The overview card
---------------------------------------------------------------------------

local function bestUpgrade(res)
    local best
    for _, sl in ipairs(Gear.SLOTS) do
        local e = res[sl.key] and res[sl.key][1]
        if e and e.upgrade and (not best or e.gain > best.gain) then best = e end
    end
    return best
end

ns.RegisterCard{ key = "gear", order = 30, available = function() return Gear.Available() end, fill = function(c)
    local o = ns.BisOpts()
    local res = ns.BisTargets()
    local n = wishCount()
    c.title:SetText(L["Deine Ausrüstung"])
    c.line1:SetText((n == 1 and L["Level %d · %s · 1 Wunsch"] or L["Level %d · %s · %d Wünsche"]):format(o.level, upgradesText(res.upgrades or 0), n))
    local cur = ns.BisCurrentPlace()
    if cur and cur.key:find("^I:") and placeKnown(cur) then
        local _, list = ns.BisHere(nil, o)
        local up = 0
        for _, e in ipairs(list) do
            if e.upgrade and not e.owned then up = up + 1 end
        end
        c.line2:SetText(L["Hier: %s (%s)"]:format(upgradesText(up), cur.text or "?"))
    else
        local best = bestUpgrade(res)
        local text = best and L["Bestes: %s (+%d)"]:format(itemText(best.id), math.floor(best.gain + 0.5)) or L["Kein Upgrade in den Daten."]
        -- the dungeon planner's recommendation, from its cache when nothing changed
        local nextE = ns.DungeonNext and ns.DungeonNext()
        if nextE then text = text .. "\n" .. L["Nächster Dungeon: %s"]:format(nextE.name) end
        -- two lines at most: a long item name would wrap the text into the button
        c.line2:SetMaxLines(2)
        c.line2:SetText(text)
    end
    c:SetAction(L["Öffnen"], function() ns.ShowGear("goals") end)
end }
