-- Tools (expert mode): one row per task that gathers data for the N100's builds (F-186, D-118): the
-- item scan ("Ausrüstung"), the quest and NPC scans by id (D-104) and the item collector, each with its
-- state in plain words, a progress bar while the total is known, and only the actions that fit the
-- state; a line "Nächster Schritt" when there is something to do. Under it the guild's drop data:
-- kills own and heard, the list per instance and boss with the rates, the sharing switch and the text
-- "Drops für die Website" (in place of the list).
local ADDON, ns = ...
local L = ns.L
local W, T = ns.W, ns.Theme
local page
local exportOpen = false
local exportText = ""

-- rows of 18 under the drop controls down to the footer (12 x 18 = 216 of 221)
local DROP_ROWS, DROP_ROW_H = 12, 18
local GOLD = { 1, 0.82, 0 }
local GREY = { 0.56, 0.53, 0.64 }
local WHITE = { 1, 1, 1 }
local INDENT = { boss = "   ", item = "      " }

local function setExport(D, text)
    exportText = text or ""
    D.area.box:SetText(exportText)
    D.area.box:SetCursorPosition(0)
end

local function itemTooltip(owner, id)
    if not id then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    local _, link = C_Item.GetItemInfo(id)
    if link then
        GameTooltip:SetHyperlink(link)
    elseif GameTooltip.SetItemByID then
        GameTooltip:SetItemByID(id)
    end
    GameTooltip:Show()
end

local function buildDrops(f)
    -- the guild's drop data under its section header: the state, sharing and the text for the website,
    -- the list (or the text) down to the footer
    local D = W.Page(f, { view = true })
    local top = D:Bands({ "header", { "line", lines = 2 }, "row" })
    D.head = W.SectionHeader(D, L["Drop-Daten"], false)
    D.head:SetAllPoints(D.bands[1])
    D.state = D:Line(2)

    D.share = W.Toggle(D, function(on) ns.Set("drops.share", on); ns.Refresh() end)
    D.shareLabel = W.Text(D, T.FONT.text, 180)
    D.shareLabel:SetText(L["Mit der Gilde teilen"])
    W.Tooltip(D.share, L["Drop-Daten mit der Gilde teilen"], L["Ohne Namen, nur außerhalb von Instanzen, nur unter geprüften Gildenmitgliedern."])

    D.web = W.Button(D, L["Drops für die Website"], 160, function()
        exportOpen = not exportOpen
        if exportOpen then
            setExport(D, ns.DropsExportText())
            D.area.box:SetFocus()
            D.area.box:HighlightText()
        else
            D.area.box:ClearFocus()
        end
        ns.Refresh()
    end)
    W.FitChip(D.web, 160)
    D:Place(3, { D.share, D.shareLabel }, { D.web })
    D:Footer({ "areaHint" })

    -- rows of 18 under the controls down to the footer; the list is 590 wide, its thin bar beside it
    D.list = D:List(DROP_ROWS, DROP_ROW_H, function(r)
        r.name = W.Text(r, T.FONT.text, 330)
        r.name:SetPoint("LEFT", 6, 0)
        r.rate = W.Text(r, T.FONT.text, 240)
        r.rate:SetPoint("RIGHT", -6, 0)
        r.rate:SetJustifyH("RIGHT")
        r:SetScript("OnEnter", function(self)
            if self.item and self.item.kind == "item" then itemTooltip(self, self.item.id) end
        end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end, function(r, e)
        -- instances gold, the rates of items grey
        local nameColor = e.kind == "inst" and GOLD or WHITE
        local rateColor = e.kind == "inst" and GOLD or e.kind == "item" and GREY or WHITE
        r.name:SetText((INDENT[e.kind] or "") .. e.text)
        r.name:SetTextColor(nameColor[1], nameColor[2], nameColor[3])
        r.rate:SetText(e.rate)
        r.rate:SetTextColor(rateColor[1], rateColor[2], rateColor[3])
    end)
    D.area = W.ReadOnlyArea(D, function() return exportText end)
    D.area:SetPoint("TOPLEFT", 0, top)
    D.area:SetPoint("BOTTOMRIGHT", 0, D:Bottom())
    D.area:Hide()
    D.areaHint:SetText(L["Strg+A, Strg+C, auf der Website im Reiter Import einfügen."])
    D.areaHint:Hide()
    return D
end

local function fillDrops(D)
    local s = ns.DropsStatus()
    if s.kills == 0 then
        D.state:SetText(ns.Get("drops.record")
            and L["Noch keine Kills. Amisia zeichnet geöffnete Lootfenster von Bossen in Dungeons und Raids auf."]
            or L["Noch keine Kills. Amisia zeichnet geöffnete Lootfenster von Bossen in Dungeons und Raids auf (Aufzeichnen ist in den Einstellungen aus)."])
    else
        D.state:SetText(L["%d Kills (%d eigene, %d gehörte), %d Bosse, neuester Tag %s, letzter Austausch %s."]:format(
            s.kills, s.own, s.heard, s.bosses, s.newest and ns.DropsDate(s.newest) or L["keiner"],
            s.heardAt and ns.FmtDayTime(s.heardAt) or L["noch keiner"]))
    end
    D.share:SetChecked(ns.Get("drops.share") and true or false)
    D.list:SetItems(ns.DropsBossList())
    if exportOpen then
        D.list:Hide()
        D.area:Show()
        D.areaHint:Show()
        D.web:SetText(L["Zur Liste"])
        -- the text follows the records unless the box is in use
        if not D.area.box:HasFocus() then
            local text = ns.DropsExportText()
            if text ~= exportText then setExport(D, text) end
        end
    else
        D.area:Hide()
        D.areaHint:Hide()
        D.list:Show()
        D.web:SetText(L["Drops für die Website"])
    end
end

---------------------------------------------------------------------------
-- The scan rows (F-186)
---------------------------------------------------------------------------
local SCAN_ROWS = { "gear", "quests", "npcs", "collect" }
local ROW_NAME = { gear = L["Ausrüstung"], quests = L["Quests"], npcs = L["NPCs"], collect = L["Sammler"] }
local ACTIONS = { "resume", "start", "retry", "stop", "toggle" }
local TICK = 1   -- seconds between two updates of the rows while a scan runs and the page shows

local function percent(p) return math.floor(100 * p.done / p.total) end
local function dur(seconds) return ns.ScanById.Duration(seconds) end

-- Which scan runs: "gear", "quests", "npcs" or nil.
local function runningScan()
    if ns.ScanRunning and ns.ScanRunning() then return "gear" end
    if ns.QuestScan and ns.QuestScan.Running() then return "quests" end
    if ns.NpcScan and ns.NpcScan.Running() then return "npcs" end
    return nil
end

local function inInstance()
    local ok, _, kind = pcall(GetInstanceInfo)
    kind = ok and ns.Plain(kind) or nil
    return kind ~= nil and kind ~= "none"
end

-- What a finished or idle scan holds: n lines wait in the file for the N100's build, or (none left)
-- everything was taken over (D-34: the addon trims what the build has); never ran: "Noch nicht gelaufen".
local WAITING = {
    gear = { L["%d neue Items warten auf die Übernahme."], L["Fertig: %d neue Items warten auf die Übernahme."] },
    quests = { L["%d neue Quests warten auf die Übernahme."], L["Fertig: %d neue Quests warten auf die Übernahme."] },
    npcs = { L["%d neue Namen warten auf die Übernahme."], L["Fertig: %d neue Namen warten auf die Übernahme."] },
}
local function waiting(key, n, finished, ran)
    if n > 0 then return WAITING[key][finished and 2 or 1]:format(n) end
    if finished or ran then return L["Fertig: alles übernommen."] end
    return L["Noch nicht gelaufen."]
end

-- A running or paused scan with a known total: the text and the bar's value.
local function progressText(p, runningFmt, pausedFmt)
    if not p.total then return p.running and L["Läuft ..."] or L["Angehalten."], nil end
    local fmt = p.running and runningFmt or pausedFmt
    return fmt:format(percent(p), dur(p.seconds)), p.done / p.total
end

-- Each row's model: { state, bar (0..1 or nil), resume, start, retry (a count), stop, toggle (label) }.
local function gearRow()
    local p = ns.ScanProgress()
    local m = { start = not p.running, retry = not p.running and p.retry > 0 and p.retry or nil, stop = p.running }
    if p.running then
        m.state, m.bar = progressText(p, p.kind == "retry" and L["Wiederholt Offene: %d %%, etwa %s übrig"]
            or L["Läuft: %d %%, etwa %s übrig"], L["Angehalten: %d %%, noch etwa %s"])
    elseif p.resumable then
        m.state, m.bar = progressText(p, L["Läuft: %d %%, etwa %s übrig"], L["Angehalten: %d %%, noch etwa %s"])
        m.resume = true
    else
        local s = AmisiaDB and AmisiaDB.scan or {}
        m.state = waiting("gear", p.items, p.finished, s.next ~= nil or s.trim ~= nil)
    end
    return m
end

local function questRow()
    local QS = ns.QuestScan
    local p = QS.Progress()
    local m = { stop = p.running }
    if p.running or p.started then
        m.state, m.bar = progressText(p, L["Läuft: %d %%, etwa %s übrig"], L["Angehalten: %d %%, noch etwa %s"])
        m.resume = not p.running
    else
        local q = AmisiaDB and AmisiaDB.scan and AmisiaDB.scan.quests
        m.state = waiting("quests", p.n, p.finished, type(q) == "table" and q.at ~= nil)
        m.start = true
    end
    return m
end

local function npcRow()
    local p = ns.NpcScan.Progress()
    local m = { stop = p.running ~= nil }
    if p.running == "mini" then
        m.state = L["Prüft zuerst drei bekannte NPCs ..."]
    elseif p.none and not p.running then
        m.state = L["Der Client nennt keine NPC-Namen."]
    elseif p.running == "B" or (not p.running and p.phase == "B") then
        if p.running or p.started then
            m.state, m.bar = progressText(p, L["Sucht neue NPCs: %d %%, etwa %s übrig"], L["Suche nach neuen NPCs angehalten: %d %%, noch etwa %s"])
        else
            m.state = p.total and L["Bekannte NPCs fertig; die Suche nach neuen dauert etwa %s."]:format(dur(p.seconds))
                or L["Bekannte NPCs fertig; die Suche nach neuen ist offen."]
        end
        m.resume = not p.running
    elseif p.running or p.started then
        m.state, m.bar = progressText(p, L["Läuft: %d %%, etwa %s übrig"], L["Angehalten: %d %%, noch etwa %s"])
        m.resume = not p.running
    else
        m.state = waiting("npcs", p.n, p.finished, p.doneA)
        -- a finished NPC scan has nothing left to ask (a start would only say its state)
        m.start = not p.finished
    end
    return m
end

local function collectRow()
    local on = ns.Get("tools.collect") and true or false
    local n = ns.CollectCount()
    local m = { toggle = on and L["Ausschalten"] or L["Einschalten"] }
    if n > 0 then
        m.state = (on and L["An: %d Items mit Quelle warten auf die Übernahme."] or L["Aus: %d Items mit Quelle warten auf die Übernahme."]):format(n)
    else
        m.state = on and L["An: alles übernommen."] or L["Aus."]
    end
    return m
end

local MODELS = { gear = gearRow, quests = questRow, npcs = npcRow, collect = collectRow }

-- The line "Nächster Schritt" (D-118), the first that fits: a scan stopped by an instance; new entries
-- of this session not yet written (SavedVariables are written at logout and /reload); items without an
-- answer to ask again. Nothing while a scan runs, else nil.
local function nextStep()
    if runningScan() then return nil end
    local paused = ns.ScanProgress().pausedIn or (ns.QuestScan.Progress().pausedIn) or (ns.NpcScan.Progress().pausedIn)
    if paused then
        return inInstance() and L["Ein Scan hielt in der Instanz an: außerhalb von Instanzen in seiner Zeile fortsetzen."]
            or L["Ein Scan hielt in der Instanz an: in seiner Zeile fortsetzen."]
    end
    local added = ns.ScanAddedCount()
    if added > 0 then
        return L["%d neue Einträge seit dem Einloggen: ausloggen oder /reload, damit sie gespeichert werden."]:format(added)
    end
    local retry = ns.ScanProgress().retry
    if retry > 0 then return L["%d Items ohne Antwort: Offene wiederholen."]:format(retry) end
    return nil
end

local function onAction(key, act)
    if act == "toggle" then
        ns.Set("tools.collect", not ns.Get("tools.collect"))
    elseif act == "stop" then
        ns.ScanCommand("stop")
    elseif key == "gear" then
        ns.ScanCommand(act == "resume" and "" or act == "retry" and "retry" or "gear")
    else
        ns.ScanCommand(key)
    end
    ns.Refresh()
end

local ACTION_LABEL = { resume = L["Fortsetzen"], start = L["Starten"], stop = L["Anhalten"], retry = L["Offene wiederholen"], toggle = L["Einschalten"] }

local function buildScanRow(f, i, key)
    local r = { key = key, band = i, acts = {} }
    r.name = W.Text(f, T.FONT.head, T.TOOLS.NAME_W)
    r.name:SetText(ROW_NAME[key])
    r.state = W.Text(f, T.FONT.text)
    r.bar = W.ProgressBar(f)
    r.bar:Hide()
    for _, act in ipairs(ACTIONS) do
        local b = W.Link(f, ACTION_LABEL[act], function() onAction(key, act) end)
        W.FitChip(b)
        b:Hide()
        r.acts[act] = b
    end
    return r
end

-- Sets one row from its model; places the band again only when its parts come or go.
local function fillScanRow(f, r, busy)
    local m = MODELS[r.key]()
    r.state:SetText(m.state or "")
    local sig = m.bar and "b" or ""
    if m.bar then r.bar:SetValue(m.bar) end
    r.bar:SetShown(m.bar ~= nil)
    for _, act in ipairs(ACTIONS) do
        local b, want = r.acts[act], m[act]
        if act == "retry" and want then b:SetText(L["Offene wiederholen (%d)"]:format(want)) end
        if act == "toggle" and want then b:SetText(want) end
        b:SetShown(want and true or false)
        -- one scan at a time (D-104): while another runs, this row's starts are greyed with the reason
        local blockedNow = busy and busy ~= r.key and act ~= "toggle" and act ~= "stop"
        if blockedNow then b:Disable() else b:Enable() end
        b.blockedBy = blockedNow and busy or nil
        if want then sig = sig .. act end
    end
    if sig ~= r.sig then
        r.sig = sig
        local right = { r.bar }
        for _, act in ipairs(ACTIONS) do right[#right + 1] = r.acts[act] end
        f:Place(r.band, { r.name, { r.state, fill = true } }, right, { shown = true })
    end
end

local function fillScans(f)
    local busy = runningScan()
    for _, r in ipairs(f.rows) do fillScanRow(f, r, busy) end
    local step = nextStep()
    f.next:SetText(step and (T.LABEL .. L["Nächster Schritt:"] .. "|r " .. step) or "")
    f.next:SetShown(step ~= nil)
end

local function blockedTip(b)
    if not b.blockedBy then return end
    GameTooltip:SetOwner(b, "ANCHOR_RIGHT")
    GameTooltip:SetText(L["Es läuft schon ein Scan"])
    GameTooltip:AddLine(L["Immer nur ein Scan zur Zeit: erst den laufenden anhalten."], 1, 1, 1, true)
    GameTooltip:Show()
end

local function buildScans(f)
    -- four rows of controls (one per task) and the line "Nächster Schritt"
    f:Bands({ "row", "row", "row", "row", "line" })
    f.rows, f.rowByKey = {}, {}
    for i, key in ipairs(SCAN_ROWS) do
        local r = buildScanRow(f, i, key)
        f.rows[i], f.rowByKey[key] = r, r
        for _, b in pairs(r.acts) do
            b:SetScript("OnEnter", blockedTip)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
    end
    f.next = f:Line(5)
    -- while a scan runs and the page shows: the rows' texts and bars once a second, nothing rebuilt
    local since = 0
    f.ticker = CreateFrame("Frame", nil, f)
    f.ticker:SetScript("OnUpdate", ns.Perf.Wrap("OnUpdate Tools scans", function(_, elapsed)
        since = since + (elapsed or 0)
        if since < TICK then return end
        since = 0
        if runningScan() and ns.CurrentPage() == "tools" then fillScans(f) end
    end))
end

ns.RegisterPanel{ key = "tools", label = L["Werkzeuge"], sub = L["Scans für die Daten, Drops der Gilde."], icon = "Interface\\Icons\\INV_Misc_Gear_01", order = 80, group = "guild", expert = true,
    create = function(parent)
        local f = W.Page(parent)
        buildScans(f)
        f.drops = buildDrops(f)
        page = f
        return f
    end,
    refresh = function(f)
        fillScans(f)
        fillDrops(f.drops)
    end }

-- The text "Drops für die Website" (/amisia drops export): the tools page with the text marked.
-- The page is part of expert mode; without it the command says where the text is.
function ns.ShowDropsExport()
    ns.ShowPage("tools")
    if ns.CurrentPage() ~= "tools" or not page then
        ns.msg(L["Der Text \"Drops für die Website\" steht auf der Seite Werkzeuge; sie zeigt Amisia im Expertenmodus (Einstellungen)."])
        return
    end
    exportOpen = true
    ns.Refresh()
    setExport(page.drops, ns.DropsExportText())
    page.drops.area.box:SetFocus()
    page.drops.area.box:HighlightText()
end

-- New or merged records: the page shows them, at most once a second and only while shown.
local refreshPending, refreshAt = false, nil
ns.Listen("DROPS_CHANGED", function()
    if not page or not page:IsShown() or ns.CurrentPage() ~= "tools" or refreshPending then return end
    refreshPending = true
    local wait = refreshAt and math.max(0, 1 - (GetTime() - refreshAt)) or 0
    C_Timer.After(wait, function()
        refreshPending = false
        refreshAt = GetTime()
        if page and page:IsShown() and ns.CurrentPage() == "tools" then ns.Refresh() end
    end)
end)
