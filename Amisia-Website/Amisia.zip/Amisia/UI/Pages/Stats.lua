-- Statistik: loot and attendance per player from the saved raids (Raid/Stats.lua), every
-- character of a player together. Officers see every player; a raider sees the own row, as on the
-- page Vergaben. The hall of fame is for everyone. Sortable columns, the range (4 weeks, phase,
-- all), class and role, a row's tooltip with the split per character, the weeks of the chosen player.
local ADDON, ns = ...
ns.Load(function()
local L = ns.L
local W, T = ns.W, ns.Theme
local ROWS, ROW_H = 9, 22
local WEEK = 7 * 86400
local DOT = "|TInterface\\AddOns\\Amisia\\Media\\Icons\\dot:10:10:0:0|t"
local MAX_DOTS = 12

local view = "players"          -- "players" or "fame"
local range = "all"             -- "4w", "phase", "all"
local classPick, rolePick = "all", "all"
local sortCol, sortDesc = "items", true
local chosen                    -- key of the player in the detail
local wanted                    -- a player name to choose at the next refresh (ns.ShowStats, the search)

-- The columns: key, x, width, head text. They end at 558 of the 590 the list has.
local COLS = {
    { "name", 6, 130, L["Spieler"] },
    { "items", 140, 36, "Items" },
    { "ms", 178, 28, "MS" },
    { "os", 208, 28, "OS" },
    { "sr", 238, 28, "SR" },
    { "perRaid", 268, 44, L["/Raid"] },
    { "rate", 314, 92, L["Teilnahme"] },
    { "bosses", 408, 46, L["Bosse"] },
    { "streak", 456, 40, L["Serie"] },
    { "last", 498, 60, L["Letztes"] },
}
local HEAD_TIP = {
    name = L["Ein Spieler mit allen Charakteren (Twinks zählen für ihren Main)."],
    items = L["Vergebene Items, ohne Bank und Entzaubern."],
    perRaid = L["Items pro Raid, bei dem der Spieler da war."],
    rate = L["Raids da (Ersatzbank zählt als da) von den Raids seit dem ersten Auftauchen."],
    bosses = L["Bosskills, bei denen der Spieler dabei war."],
    streak = L["Die längste Reihe von Raids ohne Fehlen."],
    last = L["Das Datum des letzten Items."],
}
local ROLE_TEXT = { dps = L["Schaden"], unknown = L["Rolle unbekannt"] }

local function classColor(class)
    local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    return c and c.colorStr or "ffffffff"
end

local function className(class)
    local names = ns.Gear and ns.Gear.CLASS_NAMES
    return names and names[class] or class or "?"
end

local function rateText(p)
    if p.total == 0 then return "-" end
    return ("%d %% (%d/%d)"):format(math.floor(p.rate * 100 + 0.5), p.raids, p.total)
end

local function plural(n, one, many) return n == 1 and one or many end

-- The statistics of a range without filters, kept until the raids change: an award, a sync, a
-- deleted raid (DATA_CHANGED), the alt list (ALTS), a recording starting or ending (RECORDING), a raid
-- more or less, a roster snapshot or a new raider, kill or award of the running raid, the hour (the
-- weeks and the 4 weeks count from now). A sort, a row, the class or the role builds nothing.
local cache = {}        -- range -> { stamp, res }
local function invalidate() cache = {} end
ns.Listen("DATA_CHANGED", invalidate)
ns.Listen("ALTS", invalidate)
ns.Listen("RECORDING", invalidate)

local function dataStamp()
    local act = ns.Active and ns.Active()
    local n = #ns.Sessions()
    if not act then return ("%d|%d"):format(n, math.floor(time() / 60)) end
    return ("%d|%s|%d|%d|%d|%d"):format(n, tostring(act.last), ns.MemberCount(act), type(act.kills) == "table" and #act.kills or 0,
        type(act.awards) == "table" and #act.awards or 0, math.floor(time() / 60))
end

local function statsOf(r)
    local stamp = dataStamp()
    local e = cache[r]
    if not e or e.stamp ~= stamp then
        e = { stamp = stamp, res = ns.StatsBuild({ range = r }) }
        cache[r] = e
    end
    return e.res
end

-- The statistics as the page shows them: the range and the filters (officers), sorted. The players
-- shown are res.all through the class and role test of ns.StatsBuild.
local function build()
    local officer = ns.IsOfficerView()
    local class = officer and classPick ~= "all" and classPick or nil
    local role = officer and rolePick ~= "all" and rolePick or nil
    local full = statsOf(range)
    local shown = {}
    for _, p in ipairs(full.all) do
        if (not class or p.class == class) and (not role or p.role == role) then shown[#shown + 1] = p end
    end
    local res = { from = full.from, phase = full.phase, awards = full.awards, raids = full.raids, all = full.all, players = shown }
    ns.StatsSort(res.players, sortCol, sortDesc)
    local rows = res.players
    if not officer then
        local me = ns.UnitFullName("player")
        rows = {}
        for _, p in ipairs(res.players) do
            if me and ns.SameMain(p.name, me) then rows[#rows + 1] = p end
        end
    end
    return res, rows
end

-- "Bob: 1 Item, 2 Raids" per character.
local function charLines(p)
    local out = {}
    for _, c in ipairs(p.chars) do
        out[#out + 1] = L["%s: %d %s, %d %s"]:format(c.name, c.items, plural(c.items, L["Item"], L["Items"]), c.raids,
            plural(c.raids, L["Raid"], L["Raids"]))
    end
    return out
end

local function detailText(p)
    if not p then return "" end
    local lines = { ("|c%s%s|r  %s"):format(classColor(p.class), p.name, T.GREY .. className(p.class) .. " · " .. ROLE_TEXT[p.role] .. "|r") }
    local chars = charLines(p)
    if #p.chars > 1 then lines[#lines + 1] = T.LABEL .. L["Charaktere:"] .. "|r " .. table.concat(chars, " · ") end
    lines[#lines + 1] = L["Zu spät: %d · Ersatzbank: %d · Bosse gesehen: %d"]:format(p.late, p.bench, p.bosses)
    lines[#lines + 1] = ""
    lines[#lines + 1] = T.LABEL .. L["Items pro Woche (die letzten 8 Wochen):"] .. "|r"
    local now = time()
    for i = 1, #p.weeks do
        local n = p.weeks[i]
        local bar = n > 0 and DOT:rep(math.min(n, MAX_DOTS)) .. (n > MAX_DOTS and "+" or "") or T.GREY .. "-|r"
        lines[#lines + 1] = L["Woche ab %s:"]:format(ns.FmtDay(now - i * WEEK)) .. "  " .. bar .. (n > 0 and ("  " .. n) or "")
    end
    return table.concat(lines, "\n")
end

local function fameText(res)
    local fame = ns.StatsFame(res)
    if #fame == 0 then return T.GREY .. L["Noch nichts für die Ruhmeshalle: es fehlen aufgezeichnete Raids mit Vergaben."] .. "|r" end
    local lines = {}
    for _, e in ipairs(fame) do
        lines[#lines + 1] = T.LABEL .. e.title .. "|r"
        lines[#lines + 1] = "   " .. e.name .. " - " .. e.text
        lines[#lines + 1] = ""
    end
    lines[#lines + 1] = T.GREY .. L["Beste Teilnahme ab 3 Raids. Nur was die Aufzeichnungen hergeben: wie groß ein Upgrade war, weiß Amisia im Nachhinein nicht."] .. "|r"
    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- The page
---------------------------------------------------------------------------

local function build_page(parent)
    local f = W.Page(parent)

    -- the head row: view chips left, range chips right; under it class and role (officers) and the counts
    f:Bands({ "row", "row" })
    f.view = {
        players = W.Tab(f, L["Spieler"], function() view = "players" ns.Refresh() end),
        fame = W.Tab(f, L["Ruhmeshalle"], function() view = "fame" ns.Refresh() end),
    }
    W.FitChip(f.view.players, 70)
    W.FitChip(f.view.fame, 70)
    f.range = {
        w4 = W.Tab(f, L["4 Wochen"], function() range = "4w" ns.Refresh() end),
        phase = W.Tab(f, L["Phase"], function() range = "phase" ns.Refresh() end),
        all = W.Tab(f, L["Alle Raids"], function() range = "all" ns.Refresh() end),
    }
    for _, c in pairs(f.range) do W.FitChip(c) end
    f:Place(1, { f.view.players, f.view.fame }, { f.range.w4, f.range.phase, f.range.all })
    W.Tooltip(f.range.phase, L["Phase"], L["Die Raids, seit der neueste Raid zum ersten Mal aufgezeichnet wurde."])

    f.class = W.Picker(f, 130, function(v) classPick = v or "all" ns.Refresh() end)
    f.role = W.Picker(f, 130, function(v) rolePick = v or "all" ns.Refresh() end)
    f.role:SetValues({ { value = "all", text = L["Alle Rollen"] }, { value = "dps", text = ROLE_TEXT.dps },
                       { value = "unknown", text = ROLE_TEXT.unknown } })
    f.info = W.Text(f, T.FONT.hint)
    f:Place(2, { f.class, f.role, { f.info, fill = true } })
    f:Footer({ { "hint", help = true } })

    -- column heads: a click sorts, a second click turns the order round
    f.headFrame, f.heads = f:Columns(COLS, { sort = function(key)
        if sortCol == key then
            sortDesc = not sortDesc
        else
            sortCol, sortDesc = key, key ~= "name"
        end
        ns.Refresh()
    end })
    for _, c in ipairs(COLS) do
        W.Tooltip(f.heads[c[1]], c[4], (HEAD_TIP[c[1]] and (HEAD_TIP[c[1]] .. " ") or "") .. L["Klicken sortiert."])
    end

    f.list = f:List(ROWS, ROW_H, function(r)
        W.Cells(r, COLS)
        r:SetScript("OnClick", function(self)
            if self.item then
                chosen = self.item.key
                ns.Refresh()
            end
        end)
        r:SetScript("OnEnter", function(self)
            local p = self.item
            if not p then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(p.name, 1, 0.82, 0)
            for _, line in ipairs(charLines(p)) do GameTooltip:AddLine(line, 0.85, 0.85, 0.85) end
            GameTooltip:AddLine(L["Zu spät: %d · Ersatzbank: %d"]:format(p.late, p.bench), 0.6, 0.6, 0.6)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end, function(r, p)
        r.name:SetText(("|c%s%s|r"):format(classColor(p.class), p.name) .. (#p.chars > 1 and (T.GREY .. " +" .. (#p.chars - 1) .. "|r") or ""))
        r.items:SetText(tostring(p.items))
        r.ms:SetText(tostring(p.ms))
        r.os:SetText(tostring(p.os))
        r.sr:SetText(tostring(p.sr))
        r.perRaid:SetText(p.raids > 0 and ns.Num(p.perRaid, 2) or "-")
        r.rate:SetText(rateText(p))
        r.bosses:SetText(tostring(p.bosses))
        r.streak:SetText(tostring(p.streak))
        r.last:SetText(p.last and ns.FmtDay(p.last) or "-")
        if r.sel then r.sel:SetShown(p.key == chosen) end
    end)
    for _, r in ipairs(f.list.rows) do r.sel = W.SelectBar(r) end
    f.empty = f:Empty()
    f.empty:Set(L["Noch kein Raid aufgezeichnet"], L["Noch keine Raids aufgezeichnet. Die Statistik füllt sich mit jedem Raid, den Amisia aufzeichnet."])

    -- the chosen player under the list: characters and items per week
    local G = T.LAYOUT
    f.detail = W.ScrollText(f)
    f.detail:SetPoint("TOPLEFT", f.list, "BOTTOMLEFT", G.TEXT_X, -2 * G.GAP)
    f.detail:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -T.SCROLL_ROOM, f:Bottom())

    -- the hall of fame, from the content top
    f.fame = W.ScrollText(f)
    f.fame:SetPoint("TOPLEFT", G.TEXT_X, f.top)
    f.fame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -T.SCROLL_ROOM, f:Bottom())
    f.fame:Hide()
    return f
end

local function refresh(f)
    local officer = ns.IsOfficerView()
    local res, rows = build()
    f.view.players:SetOn(view == "players")
    f.view.fame:SetOn(view == "fame")
    f.range.w4:SetOn(range == "4w")
    f.range.phase:SetOn(range == "phase")
    f.range.all:SetOn(range == "all")

    -- the classes there are, for the picker
    local classes, seen = { { value = "all", text = L["Alle Klassen"] } }, {}
    for _, p in ipairs(res.all) do
        if p.class and not seen[p.class] then
            seen[p.class] = true
            classes[#classes + 1] = { value = p.class, text = className(p.class) }
        end
    end
    table.sort(classes, function(a, b)
        if a.value == "all" or b.value == "all" then return a.value == "all" end
        return a.text < b.text
    end)
    f.class:SetValues(classes)
    f.class:SetValue(classPick)
    f.role:SetValue(rolePick)
    f.class:SetShown(officer and view == "players")
    f.role:SetShown(officer and view == "players")
    f:Place(2, { f.class, f.role, { f.info, fill = true } }, nil, { shown = true })

    local info = L["%d %s"]:format(res.raids, plural(res.raids, L["Raid"], L["Raids"]))
    if range == "phase" and res.phase then
        info = info .. " · " .. L["Phase seit %s (%s)"]:format(ns.FmtDay(res.phase.from), res.phase.zone)
    end
    f.info:SetText(info)

    local fame = view == "fame"
    f.fame:SetShown(fame)
    f.headFrame:SetShown(not fame)
    f.list:SetShown(not fame)
    f.detail:SetShown(not fame)
    f.hint:SetShown(not fame)
    if fame then
        f.empty:Hide()
        -- the hall of fame is everyone's: not the officer's class and role filter of the player view
        f.fame:SetText(fameText({ from = res.from, phase = res.phase, awards = res.awards, raids = res.raids, all = res.all, players = res.all }))
        return
    end
    W.MarkSortHead(f.heads, sortCol)
    -- a player asked for by name (the search): his row, scrolled into view
    if wanted then
        local low = wanted:lower()
        for i, p in ipairs(rows) do
            local mine = p.key == low or tostring(p.name):lower() == low
            for _, c in ipairs(type(p.chars) == "table" and p.chars or {}) do
                if type(c.name) == "string" and (c.name:lower() == low or (ns.SameName and ns.SameName(c.name, wanted))) then
                    mine = true
                end
            end
            if mine then
                chosen = p.key
                f.list.offset = math.max(0, i - 1)
                break
            end
        end
        wanted = nil
    end
    -- the chosen player, else the first row
    local pick
    for _, p in ipairs(rows) do
        if p.key == chosen then pick = p end
    end
    pick = pick or rows[1]
    chosen = pick and pick.key or nil
    f.list:SetItems(rows)
    f.empty:SetShown(#ns.Sessions() == 0)
    f.hint:SetText(officer and L["Klick auf eine Zeile: Wochen des Spielers. Maus über eine Zeile: seine Charaktere."]
        or L["Deine Zahlen. Die Zahlen anderer Spieler sehen nur Offiziere; die Ruhmeshalle sehen alle."])
    f.detail:SetText(detailText(pick))
end

-- Opens the page, in a view ("players" or "fame") when given; with name the players' view with that
-- player chosen (every range, class and role, so the row is there when the view shows it).
function ns.ShowStats(which, name)
    if which == "players" or which == "fame" then view = which end
    if type(name) == "string" and name ~= "" then
        view, range, classPick, rolePick, wanted = "players", "all", "all", "all", name
    end
    -- showing the page refreshes it
    ns.ShowPage("stats")
end

ns.RegisterPanel{ key = "stats", label = L["Statistik"], sub = L["Teilnahme und Beute über alle aufgezeichneten Raids."], icon = "Interface\\Icons\\INV_Misc_Note_05", order = 32, group = "raid",
    create = function(parent) return build_page(parent) end,
    refresh = function(f) refresh(f) end }

ns.RegisterSlash("statistik", { en = "stats", desc = L["Seite Statistik öffnen"], run = function() ns.ShowStats() end })
end)
