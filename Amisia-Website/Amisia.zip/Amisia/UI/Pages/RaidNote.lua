-- Raid-Notiz (F-196, D-126, Raid/RaidNote.lua): the raid note to write and send, its templates and the
-- own note. Officers, the raid leader and assistants (guild members in the own raid) edit and send it;
-- officers (and the author's character) also write it and its templates outside a raid, sending waits
-- for the raid (RN.CanEdit). Everyone else sees the note received there, read only and grey. The own note below is everyone's and never
-- travels. The head row: the template picker, the name field, "Speichern", "Löschen"; at the right
-- "Fenster zeigen". Over the note's field the eight raid marks (F-198): a click puts "{totenkopf}" ...
-- (the client's language) at the cursor of the field written in last (the own note for who may not
-- send). Under the note's field the counter and the red "An Raid senden". In an own party (F-213) the page is the
-- group note's: its leader writes and sends ("An Gruppe senden", 1000 bytes, 20 lines), the others see it read only.
local ADDON, ns = ...
ns.Load(function()
local L = ns.L
local W, T = ns.W, ns.Theme
local S = T.RAIDNOTE
local LAY = T.LAYOUT
local RN = ns.RaidNote

local GREY, ORANGE = "|cff8f86a3", "|cffe0a344"
local chosen          -- the template picked in this session

local function mayEdit() return (RN.CanEdit()) end

-- a received note in an edit box: its codes as text (the box would show colours, textures and links)
local function plainText(c) return c and (c.text:gsub("|", "||")) or "" end

local function setBox(box, text)
    box.setting = true
    box:SetText(text or "")
    box.setting = false
end

local function saveSet(f)
    local name = f.name:GetText()
    if (name or ""):match("^%s*$") then name = chosen or "" end
    local ok, why = RN.SaveSet(name, f.note.box:GetText())
    if ok then
        chosen = why
        f.name:SetText("")
        ns.msg(L["Vorlage \"%s\" gespeichert."]:format(chosen))
    else
        ns.msg(why)
    end
    ns.Refresh()
end

local function deleteSet()
    if not chosen then return end
    local name = chosen
    W.Confirm(L["Vorlage löschen"], L["Die Vorlage \"%s\" löschen?"]:format(name), L["Löschen"], function()
        RN.DeleteSet(name)
        chosen = nil
        ns.Refresh()
    end)
end

local function party() return RN.Mode() == "party" end

local function send(f)
    local ok, why = RN.Send(f.note.box:GetText())
    if ok then
        ns.msg(party() and L["Gruppen-Notiz an die Gruppe geschickt."] or L["Raid-Notiz an den Raid geschickt."])
    else
        ns.msg(why)
    end
    ns.Refresh()
end

-- the raid marks of the row, as the client's raid menu lists them (skull first); the word is the one
-- RN.Render reads in the client's language
local MARK_ROW = {
    { 8, L["Totenkopf"], L["totenkopf##Markierung"] }, { 7, L["Kreuz"], L["kreuz##Markierung"] },
    { 6, L["Quadrat"], L["quadrat##Markierung"] }, { 5, L["Mond"], L["mond##Markierung"] },
    { 4, L["Dreieck"], L["dreieck##Markierung"] }, { 3, L["Diamant"], L["diamant##Markierung"] },
    { 2, L["Kreis"], L["kreis##Markierung"] }, { 1, L["Stern"], L["stern##Markierung"] },
}

-- the field a mark goes into: the one written in last, the note's only while it may be edited
local function markTarget(f)
    if f.markBox == f.own.box or f.readOnly then return f.own.box, RN.SetOwn end
    return f.note.box, RN.SetDraft
end

local counter

local function insertMark(f, word)
    local box, save = markTarget(f)
    box:SetFocus()
    box:Insert("{" .. word .. "}")
    save(box:GetText() or "")
    counter(f)
end

function counter(f)
    local text = f.note.box:GetText() or ""
    local chars, lines = RN.MAX_CHARS, RN.MAX_LINES
    if party() then chars, lines = RN.PARTY_CHARS, RN.PARTY_LINES end
    f.count:SetText(L["%d/%d Zeichen · %d/%d Zeilen"]:format(#text, chars, RN.LineCount(text), lines))
end

ns.RegisterPanel{ key = "raidnote", label = L["Raid- und Gruppen-Notiz"], sub = L["Cooldowns, Einteilungen und Taktik für Raid und Gruppe, auch im Kampf zu sehen."], icon = "Interface\\Icons\\INV_Misc_Note_02", order = 18, group = "raid",
    create = function(parent)
        local f = W.Page(parent)
        f:Bands({ "row", "line", "row" })
        f.sets = W.Picker(f, S.SET_W, function(v)
            local text = RN.SetText(v)
            if not text then return end
            chosen = v
            if mayEdit() then
                setBox(f.note.box, text)
                RN.SetDraft(text)
            end
            ns.Refresh()
        end)
        W.Tooltip(f.sets, L["Vorlagen"], L["Eine gespeicherte Notiz laden, z. B. eine je Boss. Laden ersetzt den Text im Feld."])
        f.name = W.LineEdit(f, S.NAME_W, function() end)
        W.Tooltip(f.name, L["Name der Vorlage"], L["Unter diesem Namen speichert \"Speichern\" den Text; leer: die gewählte Vorlage."])
        f.save = W.Link(f, L["Speichern"], function() saveSet(f) end)
        f.del = W.Link(f, L["Löschen"], deleteSet)
        W.Tooltip(f.del, L["Vorlage löschen"], L["Löscht die gewählte Vorlage, nach einer Frage."])
        f.show = W.Link(f, L["Fenster zeigen"], function() if RN.Window then RN.Window.Toggle() end end)
        W.Tooltip(f.show, L["Raid-Notiz"], L["Zeigt oder schließt das Fenster mit der Notiz. Auch /amisia notiz und im Minimap-Menü."])
        for _, b in ipairs({ f.save, f.del, f.show }) do W.FitChip(b) end
        f:Place(1, { f.sets, f.name, f.save, f.del }, { f.show })
        f.status = f:Line(2)
        -- the raid marks (F-198)
        f.markLabel = W.Text(f, T.FONT.hint)
        f.markLabel:SetText(L["Markierung einfügen:"])
        f.marks = {}
        local row = { f.markLabel }
        for i, m in ipairs(MARK_ROW) do
            local b = W.IconButton(f, S.MARK, { file = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. m[1] }, function()
                insertMark(f, m[3])
            end, tostring(m[1]))
            W.Tooltip(b, m[2], L["Setzt %s an die Schreibmarke im Feld, in dem du zuletzt geschrieben hast."]:format("{" .. m[3] .. "}"))
            b.word = m[3]
            f.marks[i] = b
            row[#row + 1] = { b, gap = i == 1 and nil or S.MARK_GAP }
        end
        f:Place(3, row)
        local y = f.top
        f.note = W.EditArea(f)
        f.note:SetPoint("TOPLEFT", 0, y)
        f.note:SetPoint("TOPRIGHT", 0, y)
        f.note:SetHeight(S.EDIT_H)
        f.note.box:SetMaxLetters(RN.MAX_CHARS)
        f.note.box:HookScript("OnEditFocusGained", function(self) f.markBox = self end)
        if f.note.box.SetMaxBytes then f.note.box:SetMaxBytes(RN.MAX_CHARS + 1) end
        f.note.box:HookScript("OnTextChanged", function(self, userInput)
            if self.setting then return end
            if userInput then
                if f.readOnly then
                    setBox(self, plainText(RN.Shown()))
                else
                    RN.SetDraft(self:GetText())
                end
            end
            counter(f)
        end)
        y = y - S.EDIT_H - S.GAP
        f.count = W.Text(f, T.FONT.hint, S.COUNT_W * 2)
        f.count:SetPoint("TOPLEFT", LAY.TEXT_X, y - 5)
        f.send = W.Button(f, L["An Raid senden"], 130, function() send(f) end)
        W.FitChip(f.send, 130)
        f.send:SetPoint("TOPRIGHT", 0, y)
        W.Tooltip(f.send, L["Senden"], L["Schickt die Notiz an alle im Raid (oder als Gruppenleiter an die Gruppe) mit Amisia; sie ersetzt die vorige. Nicht im Kampf."])
        y = y - T.BUTTON_H - S.GAP
        f.ownTitle = W.Text(f, T.FONT.title, 300)
        f.ownTitle:SetPoint("TOPLEFT", LAY.TEXT_X, y)
        f.ownTitle:SetText(L["Eigene Notiz"])
        f.ownHint = W.Text(f, T.FONT.hint, 300)
        f.ownHint:SetPoint("TOPRIGHT", -LAY.TEXT_X, y)
        f.ownHint:SetJustifyH("RIGHT")
        f.ownHint:SetText(L["Nur für dich, wird nie gesendet."])
        y = y - S.FROM_H - S.GAP
        f.own = W.EditArea(f)
        f.own:SetPoint("TOPLEFT", 0, y)
        f.own:SetPoint("TOPRIGHT", 0, y)
        f.own:SetHeight(S.OWN_H)
        f.own.box:SetMaxLetters(RN.MAX_OWN)
        f.own.box:HookScript("OnEditFocusGained", function(self) f.markBox = self end)
        if f.own.box.SetMaxBytes then f.own.box:SetMaxBytes(RN.MAX_OWN + 1) end
        f.own.box:HookScript("OnTextChanged", function(self, userInput)
            if userInput and not self.setting then RN.SetOwn(self:GetText()) end
        end)
        f:Footer({ { "hint", lines = 2 } })
        f.hint:SetText(L["{stern} {kreis} {diamant} {dreieck} {mond} {quadrat} {kreuz} {totenkopf} (auch {star} ... {skull}, {rt1} ... {rt8}) werden Zielmarkierungen; Namen aus dem Raid stehen in Klassenfarbe, deine Zeilen gelb."])
        return f
    end,
    refresh = function(f)
        local may = RN.CanEdit()
        local canSend, why = RN.CanSend()
        local c = RN.Shown()
        local inParty = party()
        f.readOnly = not may
        f.note:SetLocked(not may)
        -- the templates
        local values = {}
        for _, s in ipairs(RN.Sets()) do values[#values + 1] = { value = s.name, text = s.name } end
        if chosen and not RN.SetText(chosen) then chosen = nil end
        f.sets:SetValues(#values > 0 and values or { { value = "", text = L["Keine Vorlagen"] } })
        f.sets:SetValue(chosen or (#values > 0 and "" or ""))
        for _, w in ipairs({ f.sets, f.name, f.save, f.del }) do w:SetShown(may) end
        f.del:SetEnabled(chosen ~= nil)
        -- the note's field: the own draft, or the received note read only
        local box = f.note.box
        if not box:HasFocus() then
            if may then
                setBox(box, RN.Draft() ~= "" and RN.Draft() or plainText(c))
            else
                setBox(box, plainText(c))
            end
        end
        counter(f)
        local held = canSend and RN.SendHeld()
        f.send:SetText(inParty and L["An Gruppe senden"] or L["An Raid senden"])
        W.FitChip(f.send, 130)
        f.send:SetShown(may)
        f.send:SetEnabled(canSend and not held)
        local from = c and L["Aktuelle Notiz von %s, %s."]:format(c.by, date("%H:%M", c.at))
            or (inParty and L["Noch keine Gruppen-Notiz."] or L["Noch keine Raid-Notiz."])
        if canSend then
            f.status:SetText(from .. (held and (" " .. ORANGE .. held .. "|r") or ""))
        else
            -- an officer outside a raid writes now and sends there
            if may and why == L["Nur in Raid oder Gruppe."] then why = L["Schreiben geht jetzt, senden erst im Raid oder als Gruppenleiter."] end
            f.status:SetText(from .. " " .. GREY .. (why or "") .. "|r")
        end
        if not f.own.box:HasFocus() then setBox(f.own.box, RN.Own()) end
    end }

local function again()
    if ns.CurrentPage and ns.CurrentPage() == "raidnote" then ns.RefreshSoon() end
end
ns.Listen("RAIDNOTE", again)
-- the right to send follows the raid rank and the fight
ns.OnEvent("GROUP_ROSTER_UPDATE", again)
ns.OnEvent("PLAYER_REGEN_DISABLED", again)
ns.OnEvent("PLAYER_REGEN_ENABLED", again)
end)
