-- Amisia main window in the look of Forever's profession window: the client's portrait frame, a
-- status bar with the recording state, a search box and under it the pages of the chosen tab on the
-- left, the page itself in an inset on the right, the client's panel tabs under the window (one per
-- page group, ns.PANEL_GROUPS; D-45) and side tabs on the right edge for the side windows. Typing
-- two characters into the search box turns the page list into the results (UI/Search.lua). Pages
-- are built the first time they are opened and refreshed only while shown.
local ADDON, ns = ...
local L = ns.L

local W, T = ns.W, ns.Theme
local M = T.MAIN
local WIDTH, HEIGHT = M.W, M.H
local NAV_W, NAV_MAX = M.NAV_W, M.NAV_ROWS
local ROW_H, INDENT = M.NAV_ROW_H, M.NAV_INDENT
local DOT = "|TInterface\\AddOns\\Amisia\\Media\\Icons\\dot:10:10:0:0|t "
local PORTRAIT = "Interface\\AddOns\\Amisia\\Media\\Icons\\Amisia"

local F, nav, content, statusBar, statusText, menuBtn, helpBtn, settingsBtn, search, results, noHits, searchHint, homeBtn
local built, current = {}, nil
local previous      -- the page shown before the current one (the feedback's details name it)
local navButtons = {}
local sideTabs = {}
local bottomTabs = {}     -- group key -> the tab under the window
local query = ""          -- the search text, trimmed and lower case

-- The side windows the tabs on the right edge open and close, top to bottom; tip: what the window is
-- for (the tab's tooltip under its name).
local SIDE_TABS = {
    { key = "gear", label = L["Ausrüstungstabelle"], icon = "Interface\\Icons\\INV_Chest_Chain_05", frame = "AmisiaGearFrame",
      tip = L["Das beste Item je Platz für jede Stufe, mit Quelle und Alternativen."],
      visible = function() return ns.Gear ~= nil and ns.Gear.Available() and ns.ToggleGearFrame ~= nil end,
      toggle = function() ns.ToggleGearFrame() end },
    { key = "talents", label = L["Talentrechner"], icon = "Interface\\Icons\\Ability_Marksmanship", frame = "AmisiaTalentFrame",
      tip = L["Talente planen, im großen Fenster."],
      visible = function() return ns.Talents ~= nil and ns.Talents.Available() and ns.ToggleTalentFrame ~= nil end,
      toggle = function() ns.ToggleTalentFrame() end },
    { key = "goals", label = L["Ausrüstungsziele"], icon = "Interface\\Icons\\INV_Helmet_03", frame = "AmisiaGoalsFrame",
      tip = L["Deine Ziele an deinem Charakter anprobieren, Platz für Platz mit Rangliste und Katalog."],
      visible = function() return ns.Gear ~= nil and ns.Gear.Available() and ns.ToggleGoalsFrame ~= nil end,
      toggle = function() ns.ToggleGoalsFrame() end },
    { key = "rolls", label = "Rolls", icon = "Interface\\Icons\\INV_Misc_Dice_01", frame = "AmisiaRollFrame",
      tip = L["Die laufende Würfelrunde: Würfe in Reihenfolge, Vergeben, Stechen."],
      visible = function() return ns.IsOfficerView() and ns.ToggleRollFrame ~= nil end,
      toggle = function() ns.ToggleRollFrame() end },
    { key = "softres", label = L["Soft-Reserve-Import"], icon = "Interface\\Icons\\INV_Scroll_03", frame = "AmisiaSoftResFrame",
      tip = L["Eine Soft-Reserve-Liste einfügen, prüfen und übernehmen."],
      visible = function() return ns.IsOfficerView() and ns.ToggleSoftResFrame ~= nil end,
      toggle = function() ns.ToggleSoftResFrame() end },
}

-- settings.window: the place (point, rel, x, y), the last tab (tab: a group key) and the last page
-- of each tab (pages: { [group] = page key }); the collapsed sections of before 2.27.0 are dropped.
local function windowState()
    AmisiaDB.settings.window = type(AmisiaDB.settings.window) == "table" and AmisiaDB.settings.window or {}
    local w = AmisiaDB.settings.window
    w.collapsed = nil
    if type(w.pages) ~= "table" then w.pages = {} end
    if w.tab ~= nil and type(w.tab) ~= "string" then w.tab = nil end
    return w
end

local function savePosition()
    local point, _, rel, x, y = F:GetPoint()
    local w = windowState()
    w.point, w.rel, w.x, w.y = point, rel, x, y
end

local function restorePosition()
    local w = windowState()
    F:ClearAllPoints()
    if w.point then
        F:SetPoint(w.point, UIParent, w.rel or w.point, w.x or 0, w.y or 0)
    else
        F:SetPoint("CENTER")
    end
end

function ns.ApplyScale(v)
    if F then F:SetScale((v or ns.Get("ui.scale") or 100) / 100) end
end

-- The remembered tab and pages stay (settings.window.tab, pages), only the position goes.
function ns.ResetPositions()
    windowState().point = nil
    if F then restorePosition() end
    if ns.ResetGearPosition then ns.ResetGearPosition() end
    if ns.ResetRollWindowPosition then ns.ResetRollWindowPosition() end
    if ns.ResetTalentWindowPosition then ns.ResetTalentWindowPosition() end
    if ns.ResetGoalsWindowPosition then ns.ResetGoalsWindowPosition() end
    if ns.ResetRaidCalendarPosition then ns.ResetRaidCalendarPosition() end
    ns.msg(L["Fensterposition zurückgesetzt."])
end

local function reportError(err)
    local handler = geterrorhandler and geterrorhandler()
    if handler then handler(err) end
end

local function errorPage(parent, err)
    local f = CreateFrame("Frame", nil, parent)
    local t = W.Text(f, T.FONT.title, 560, true)
    t:SetPoint("TOPLEFT", 10, -10)
    t:SetText(L["Diese Seite konnte nicht geladen werden."] .. "\n|cff8f86a3" .. (tostring(err):match("^[^\n]*") or "?") .. "|r")
    return f
end

local function updateHeader()
    local act = ns.Active and ns.Active()
    if act then
        local late = ns.LateCount(act)
        statusText:SetText(("%s|cff4fbf7a%s|r · %s%s"):format(DOT, act.zone or "?", L["%d Raider"]:format(ns.MemberCount(act)),
            late > 0 and (" · |cffe0a344" .. L["%d zu spät"]:format(late) .. "|r") or ""))
    elseif ns.IsEnabled() then
        statusText:SetText("|cff8f86a3" .. L["Keine Aufnahme, startet im Raid"] .. "|r")
    else
        statusText:SetText("|cffe0a344" .. L["Aufnahme pausiert"] .. "|r")
    end
    settingsBtn:SetShown(current ~= "settings" and ns.SettingsSectionsOf ~= nil and #ns.SettingsSectionsOf(current) > 0)
    -- the "?" sits left of the gear, or at the edge when the page has no settings
    helpBtn:ClearAllPoints()
    if settingsBtn:IsShown() then
        helpBtn:SetPoint("RIGHT", settingsBtn, "LEFT", -M.ICON_GAP, 0)
    else
        helpBtn:SetPoint("TOPRIGHT", -M.ICON_RIGHT, -M.HEAD_Y)
    end
end

-- The "?" shows only when the open page has explanations (footer lines with help = true, D-67);
-- after the page's refresh, which writes them.
local function updateHelp()
    helpBtn:SetShown(#W.HelpLines(content) > 0)
end

-- The menu behind the status line (D-67): the recording and the view, which were two red buttons in
-- the head. Each entry says what a click does; its tip says more.
local function headMenu()
    return {
        { ns.IsEnabled() and L["Aufnahme pausieren"] or L["Aufnahme fortsetzen"], function()
            ns.SetEnabled(not ns.IsEnabled())
            ns.Refresh()
        end, tip = ns.IsEnabled()
            and L["Pausiert die Raid-Aufnahme: Teilnehmer, Bosse und Beute werden nicht mehr mitgeschrieben. Die Pause bleibt auch nach einem /reload, bis du sie hier fortsetzt (oder im Schnellmenü der Minimap, /amisia pause)."]
            or L["Die Raid-Aufnahme ist pausiert. \"Aufnahme fortsetzen\" schaltet sie wieder an; sie startet dann von selbst in einer Raidinstanz mit Raidgruppe."] },
        { ns.IsOfficerView() and L["Zur Raider-Ansicht"] or L["Zur Offiziersansicht"], function() ns.ToggleView() end,
          tip = L["Ein Klick zeigt die andere Ansicht: Raider sehen ihre Seiten, Offiziere auch Rolls, Punkte, das Raid-Archiv und den Export. Für die Gilde bist du dadurch kein Offizier; Rechte prüft Amisia am Rang. Die Ansicht nach Rang (Automatisch) stellst du unter Einstellungen, Oberfläche ein."] },
    }
end

-- The view switch in the head: a click shows the other view (and sets it, as the setting
-- "Ansicht" does); "Automatisch" stays in the settings and in /amisia ansicht auto.
function ns.ToggleView()
    ns.Set("ui.view", ns.IsOfficerView() and "raider" or "officer")
    ns.Refresh()
end

local function groupOf(key)
    local p = ns.Panel(key)
    return p and ns.PanelGroup(p) or nil
end

-- The visible pages of a tab, in their order.
local function pagesOf(group)
    local out = {}
    for _, p in ipairs(ns.panels) do
        if ns.PanelGroup(p) == group and ns.Visible(p) then out[#out + 1] = p end
    end
    return out
end

-- The visible pages of every tab at once (group -> pages, in their order): one pass for a refresh.
local function pagesByGroup()
    local out = {}
    for _, g in ipairs(ns.PANEL_GROUPS) do out[g.key] = {} end
    for _, p in ipairs(ns.panels) do
        local g = ns.PanelGroup(p)
        if ns.Visible(p) then
            out[g] = out[g] or {}
            out[g][#out[g] + 1] = p
        end
    end
    return out
end

-- What the settings show (the chosen section, or the sorted keys of a page's sections; "" while
-- searching): a fold in the page list holds only while this stays the same.
local function settingsShown(chosen, set)
    if chosen then return chosen end
    if not set then return "" end
    local keys = {}
    for k in pairs(set) do keys[#keys + 1] = k end
    table.sort(keys)
    return table.concat(keys, " ")
end

-- Folded by a click in the page list, as the auction house's categories: the tabs under "Einstellungen"
-- (treeShut) and the open tab's sections (tabShut = { key, at }); both hold for what the settings show
-- at the click (at), another section or page's sections unfold everything again.
local treeShut, tabShut

-- What the page list shows: the visible pages of the open page's tab; while the settings page is open,
-- under it its tabs and, under the tab of the chosen section, that tab's sections (D-49), unless folded:
-- { kind = "page"|"group"|"section", key, label, on = chosen, changed, open, has }.
local function navEntries(byGroup)
    local out = {}
    local group = groupOf(current)
    for _, p in ipairs(byGroup and (byGroup[group] or {}) or pagesOf(group)) do
        out[#out + 1] = { kind = "page", key = p.key, label = p.label, on = p.key == current }
        if p.key == "settings" and current == "settings" and ns.SettingsGroups and ns.SettingsChosen then
            local chosen, set = ns.SettingsChosen()
            local at = settingsShown(chosen, set)
            -- a fold ends once the settings show something else (and does not come back with it)
            if treeShut ~= at then treeShut = nil end
            if tabShut and tabShut.at ~= at then tabShut = nil end
            local tree = treeShut == nil
            out[#out].open, out[#out].at = tree, at
            for _, g in ipairs(tree and ns.SettingsGroups() or {}) do
                local has = false
                for _, sec in ipairs(g.sections) do
                    if sec.key == chosen or (set and set[sec.key]) then has = true end
                end
                local open = has and not (tabShut and tabShut.key == g.key and tabShut.at == at)
                out[#out + 1] = { kind = "group", key = g.key, label = g.label, first = g.sections[1].key, open = open,
                    has = has, at = at }
                if open then
                    for _, sec in ipairs(g.sections) do
                        out[#out + 1] = { kind = "section", key = sec.key, label = sec.label,
                            on = sec.key == chosen or (set and set[sec.key]) or false, changed = ns.SectionChanged(sec) }
                    end
                end
            end
        end
    end
    return out
end

-- The page list: one bar each from the top, packed as the auction house's category list (a page as a
-- category bar, a settings tab and section as its sub-category bars); the bars are NAV_ROW_H high,
-- lower (NAV_ROW_MIN at least) when more than fit the list. F.navOrder holds what is shown, top to
-- bottom ({ button = row, entry = what it shows }).
local function updateNav(byGroup)
    local order, y = {}, 0
    local entries = navEntries(byGroup)
    local rowH = ROW_H
    if #entries > 0 then
        rowH = math.max(M.NAV_ROW_MIN, math.min(ROW_H, math.floor(M.NAV_LIST_H / #entries)))
    end
    local used = 0
    for _, e in ipairs(entries) do
        local b = navButtons[used + 1]
        if not b then break end
        used = used + 1
        b.key, b.entry = e.key, e
        b:SetKind(e.kind)
        b.label:SetText(e.kind == "section" and e.changed and (DOT .. e.label) or e.label)
        b:SetHeight(rowH)
        if b.art then b.art:Fit(rowH) end
        if b.subArt then b.subArt:Fit(rowH) end
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", nav, "TOPLEFT", INDENT, y)
        b:SetSelected(e.on)
        b:Show()
        order[#order + 1] = { button = b, entry = e }
        y = y - rowH
    end
    for i = used + 1, NAV_MAX do navButtons[i]:Hide() end
    F.navOrder, F.navRowH = order, rowH
end

---------------------------------------------------------------------------
-- The tabs under the window
---------------------------------------------------------------------------
-- The page a tab opens: the one last open there when it is still shown, else its first.
local function tabPage(group)
    local pages = pagesOf(group)
    local last = windowState().pages[group]
    for _, p in ipairs(pages) do
        if p.key == last then return p.key end
    end
    return pages[1] and pages[1].key or nil
end

-- Opens the tab of group (its last page); nothing when it has no visible page.
function ns.ShowTab(group)
    local key = tabPage(group)
    if key then ns.ShowPage(key) end
end

-- The tab's look: the client's PanelTemplates helpers when there, else the slices by hand.
local function selectTab(tab, on)
    if tab.flat then
        tab.ground:SetAlpha(on and 0.9 or 0.45)
        tab.Text:SetTextColor(on and 1 or T.GOLD[1], on and 1 or T.GOLD[2], on and 1 or T.GOLD[3])
        tab:SetEnabled(not on)
    elseif on and PanelTemplates_SelectTab then
        PanelTemplates_SelectTab(tab)
    elseif not on and PanelTemplates_DeselectTab then
        PanelTemplates_DeselectTab(tab)
    end
    tab.selected = on and true or false
end

-- Each tab as wide as its text + 20, at least BTAB_MIN_W, sized by Amisia on every client: Forever's
-- PanelTemplates_TabResize gives the same, the classic one (TBC, Era) adds both edge pieces on top
-- (about 140 px a tab, six of them past the window; D-57).
local function sizeTab(tab)
    local w = math.max(M.BTAB_MIN_W, (tab.Text:GetStringWidth() or 0) + 20)
    tab.Text:SetWidth(w - 20)
    tab:SetWidth(w)
end

-- A tab under the window: the client's panel tab (PanelTabButtonTemplate, as under the character
-- window); without the template a flat tab of the same size. Named: the classic PanelTemplates_SelectTab
-- looks the highlight up by the tab's name and breaks on a nameless tab.
local function bottomTab(g)
    local ok, tab = pcall(CreateFrame, "Button", "AmisiaMainTab_" .. g.key, F, "PanelTabButtonTemplate")
    if not ok or not tab or not tab.Text or not tab.Left or not tab.LeftActive then
        if ok and tab then tab:Hide() end
        tab = CreateFrame("Button", nil, F)
        tab:SetHeight(M.BTAB_H - 4)
        tab.ground = W.Flat(tab, 0.18, 0.08, 0.05, 0.45)
        tab.Text = W.Text(tab, "GameFontNormalSmall")
        tab.Text:SetPoint("CENTER", 0, 2)
        tab.flat = true
    else
        -- the template sizes itself again on show and on a display change (PanelTabButtonMixin, the
        -- client's PanelTemplates_TabResize): sizeTab alone decides
        tab:SetScript("OnShow", nil)
        tab:SetScript("OnEvent", nil)
        if tab.UnregisterEvent then tab:UnregisterEvent("DISPLAY_SIZE_CHANGED") end
    end
    tab.group = g.key
    tab:SetText(g.label)
    if tab.flat then tab.Text:SetText(g.label) end
    -- a click while the search shows its results clears it: the tab's page list comes back
    tab:SetScript("OnClick", function(self)
        if PlaySound and SOUNDKIT and SOUNDKIT.IG_CHARACTER_INFO_TAB then PlaySound(SOUNDKIT.IG_CHARACTER_INFO_TAB) end
        ns.ClearSearch()
        ns.ShowTab(self.group)
    end)
    tab:Hide()
    return tab
end

-- The window's clamp: the side tabs on the right and the bottom tabs below stay on the screen.
local function clamp()
    if not F.SetClampRectInsets then return end
    local right = 0
    for _, def in ipairs(SIDE_TABS) do
        local tab = sideTabs[def.key]
        if tab and tab:IsShown() then right = tab:GetWidth() break end
    end
    local below = 0
    for _, g in ipairs(ns.PANEL_GROUPS) do
        local tab = bottomTabs[g.key]
        if tab and tab:IsShown() then below = M.BTAB_H - M.BTAB_Y break end
    end
    F:SetClampRectInsets(0, right, 0, -below)
end

-- Shows the tabs whose group has a visible page, left to right without gaps, the open page's selected
-- (and, while the search shows its results, still clickable: a click brings its page list back).
local function updateTabs(byGroup)
    local searching = #query >= M.SEARCH_MIN
    local open = groupOf(current)
    local prev
    F.tabOrder = {}
    for _, g in ipairs(ns.PANEL_GROUPS) do
        local tab = bottomTabs[g.key]
        if tab then
            if #(byGroup and byGroup[g.key] or pagesOf(g.key)) > 0 then
                tab:ClearAllPoints()
                if prev then
                    tab:SetPoint("TOPLEFT", prev, "TOPRIGHT", M.BTAB_GAP, 0)
                else
                    tab:SetPoint("TOPLEFT", F, "BOTTOMLEFT", M.BTAB_X, M.BTAB_Y)
                end
                tab:Show()
                sizeTab(tab)
                selectTab(tab, g.key == open)
                if searching and g.key == open then tab:SetEnabled(true) end
                F.tabOrder[#F.tabOrder + 1] = g.key
                prev = tab
            else
                tab:Hide()
            end
        end
    end
    clamp()
end

---------------------------------------------------------------------------
-- The search over the page list (UI/Search.lua finds, this shows)
---------------------------------------------------------------------------
-- The line under the page list while the box holds fewer than SEARCH_MIN characters ("Noch 1
-- Zeichen für die Suche"), under the last bar; left out when the list leaves no room for it.
local function updateSearchHint()
    local left = M.SEARCH_MIN - #query
    if #query == 0 or left <= 0 then
        searchHint:Hide()
        return
    end
    local below = #(F.navOrder or {}) * (F.navRowH or ROW_H) + M.SEARCH_GAP
    searchHint:ClearAllPoints()
    searchHint:SetPoint("TOPLEFT", nav, "TOPLEFT", M.NAV_LABEL_X, -below)
    searchHint:SetText(left == 1 and L["Noch 1 Zeichen für die Suche"] or L["Noch %d Zeichen für die Suche"]:format(left))
    searchHint:SetShown(below + ROW_H <= M.NAV_LIST_H)
end

-- The hits of the search text in place of the page list. A refresh (data, a setting) keeps the
-- scroll place (SetItems clamps it); only a new text starts at the top (setQuery).
local function showResults()
    local searching = #query >= M.SEARCH_MIN
    nav:SetShown(not searching)
    results:SetShown(searching)
    if F then updateSearchHint() end
    if not searching then
        noHits:Hide()
        return
    end
    local rows = {}
    for _, grp in ipairs(ns.Search(query)) do
        rows[#rows + 1] = { head = grp.label, count = #grp.hits }
        for _, hit in ipairs(grp.hits) do rows[#rows + 1] = hit end
    end
    results:SetItems(rows)
    -- under ITEM_MIN characters items, recipes and commands are not searched yet: the hint says so
    local itemMin = ns.SearchIndex.ITEM_MIN
    noHits:SetText(#query < itemMin and L["Nichts gefunden. Items, Rezepte und Befehle ab %d Zeichen."]:format(itemMin)
        or L["Nichts gefunden."])
    noHits:SetShown(#rows == 0)
end

local function setQuery(text)
    text = (tostring(text or ""):match("^%s*(.-)%s*$") or ""):lower()
    if text == query then return end
    query = text
    results.offset = 0
    showResults()
    if F and F:IsShown() then updateTabs() end
end

-- Clears the search box (Escape, the clear button, a click on a result).
function ns.ClearSearch()
    if not search then return end
    search:SetText("")
    search:ClearFocus()
    setQuery("")
end

-- A result row: a group as the auction house's category bar (gold name, the count white), a hit as
-- its indented sub-category bar (white, from RES_HIT_X); no icons, as there. Without the client's
-- bars: the group as a section bar and the hit as a plain list row, as before 2.29.0.
local function buildResult(r)
    local w = NAV_W - T.SCROLL_ROOM
    r.headArt = W.NavBar(r, false)
    r.hitArt = r.headArt and W.NavBar(r, true)
    if r.headArt and r.hitArt then
        r.headArt:Fit(M.RES_ROW_H - 1)
        r.hitArt:Fit(M.RES_ROW_H - 1)
        r.bg:Hide()
        r.hover:SetAlpha(0)       -- the bars bring their own glow
        r.headArt.hover:Hide()    -- a group is no button: no glow over it
    else
        r.headArt, r.hitArt = nil, nil
        r.bar = W.SectionHeader(r, "", false)
        r.bar:SetPoint("TOPLEFT", 0, 0)
        r.bar:SetPoint("BOTTOMRIGHT", 0, 0)
        r.bar:Hide()
    end
    r.label = W.Text(r, T.FONT.text, w - M.RES_HIT_X - 6)
    r.label:SetPoint("LEFT", M.RES_HIT_X, 0)
    r:SetScript("OnClick", function(self)
        local hit = self.item
        if not hit or hit.head or not hit.run then return end
        ns.ClearSearch()
        hit.run()
    end)
    r:SetScript("OnEnter", function(self)
        local hit = self.item
        if not hit or hit.head then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if hit.item and GameTooltip.SetItemByID then
            GameTooltip:SetItemByID(hit.item)
        else
            GameTooltip:AddLine(hit.text, 1, 0.82, 0)
            if hit.tip then GameTooltip:AddLine(hit.tip, 0.85, 0.85, 0.85, true) end
        end
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function fillResult(r, hit)
    local head = hit.head ~= nil
    if r.headArt then
        r.headArt.normal:SetShown(head)
        r.hitArt.normal:SetShown(not head)
        r.hitArt.hover:SetShown(not head)
        r.label:ClearAllPoints()
        if head then
            r.label:SetPoint("LEFT", M.NAV_LABEL_X, 0)
            r.label:SetWidth(NAV_W - T.SCROLL_ROOM - M.NAV_LABEL_X - 6)
            r.label:SetFontObject(T.FONT.title)
            r.label:SetText(("%s |cffffffff%d|r"):format(hit.head, hit.count))
        else
            r.label:SetPoint("LEFT", M.RES_HIT_X, 0)
            r.label:SetWidth(NAV_W - T.SCROLL_ROOM - M.RES_HIT_X - 6)
            r.label:SetFontObject(T.FONT.text)
            r.label:SetText(hit.label or hit.text)
        end
        return
    end
    if head then
        r.bar:SetHeaderText(("%s |cffffffff%d|r"):format(hit.head, hit.count))
        r.bar:Show()
        r.bg:Hide()
        r.label:SetText("")
        return
    end
    r.bar:Hide()
    r.bg:Show()
    r.label:SetText(hit.label or hit.text)
end

-- The client fills the tab's interior with the icon (fillToInterior, through SetChecked); the
-- player found that too large: pull the icon in by M.TAB_ICON_INSET on every side. Done after each
-- SetChecked, and only on the anchors the client set (not twice on ours).
local function insetIcon(tab)
    local icon, d = tab.Icon, M.TAB_ICON_INSET or 0
    if not icon or d <= 0 or not icon.GetNumPoints then return end
    local n = icon:GetNumPoints()
    local p1, _, _, x1, y1 = icon:GetPoint(1)
    local w1, h1 = icon:GetSize()
    -- what we left last time, unchanged: done (the size counts only for an icon on one point; on
    -- two the client works it out later, and comparing it would pull the icon in again and again)
    local was = tab.insetAt
    if n == 0 or (was and was[1] == p1 and was[2] == x1 and was[3] == y1 and was[6] == n
        and (n >= 2 or (was[4] == w1 and was[5] == h1))) then return end
    if n >= 2 then
        local pts = {}
        for i = 1, n do pts[i] = { icon:GetPoint(i) } end
        icon:ClearAllPoints()
        for _, p in ipairs(pts) do
            local point, rel, relPoint, x, y = p[1], p[2], p[3], p[4] or 0, p[5] or 0
            local dx = point:find("LEFT") and d or point:find("RIGHT") and -d or 0
            local dy = point:find("TOP") and -d or point:find("BOTTOM") and d or 0
            icon:SetPoint(point, rel, relPoint, x + dx, y + dy)
        end
    elseif (w1 or 0) > 2 * d and (h1 or 0) > 2 * d then
        icon:SetSize(w1 - 2 * d, h1 - 2 * d)
    end
    local p2, _, _, x2, y2 = icon:GetPoint(1)
    local w2, h2 = icon:GetSize()
    tab.insetAt = { p2, x2, y2, w2, h2, n }
end

-- Shows, places (one under the other, no gaps) and marks the side tabs. Runs in ns.Refresh and
-- whenever a side window shows or hides (each window calls it through W.Window's onVisibility, so
-- the windows need not know this file).
function ns.UpdateSideTabs()
    if not F then return end
    local prev
    for _, def in ipairs(SIDE_TABS) do
        local tab = sideTabs[def.key]
        if tab then
            local win = _G[def.frame]
            if def.visible() then
                tab:ClearAllPoints()
                if prev then
                    tab:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -M.TAB_GAP)
                else
                    tab:SetPoint("TOPLEFT", F, "TOPRIGHT", 0, -M.TAB_Y)
                end
                tab:Show()
                prev = tab
            else
                tab:Hide()
            end
            tab:SetChecked(win ~= nil and win:IsShown() and true or false)
            insetIcon(tab)
        end
    end
    -- the tabs hang outside the frame on the right: keep them on the screen when moving it, but only
    -- while at least one is shown (and the bottom tabs below it)
    clamp()
end

-- A row of the page list: a bar of the auction house's category list (W.NavBar), the page's name
-- gold from NAV_LABEL_X (white while the mouse is over it, as the client's highlight font), no icon
-- (the pages keep theirs for the search and other places). Without the client's bars: the recipe
-- list's glow when chosen and its hover, the same gold name.
local function navRow()
    local b = CreateFrame("Button", nil, nav)
    b:SetSize(NAV_W - INDENT, ROW_H)
    b.art = W.NavBar(b, false)
    if b.art then
        b.sel, b.hover = b.art.sel, b.art.hover
    else
        b.sel = W.SelectBar(b)
        b.hover = b:CreateTexture(nil, "HIGHLIGHT")
        b.hover:SetAllPoints()
        if W.HasAtlas("Professions_Recipe_Hover") then
            b.hover:SetAtlas("Professions_Recipe_Hover")
            b.hover:SetAlpha(T.HOVER_ALPHA)
        else
            b.hover:SetColorTexture(1, 1, 1, 0.08)
        end
    end
    -- a settings tab or section: the sub-category bar (D-49)
    b.subArt = b.art and W.NavBar(b, true)
    if b.subArt then b.subArt.normal:Hide(); b.subArt.hover:Hide() end
    function b:SetSelected(on)
        local sub = self.kind ~= "page" and self.subArt
        self.sel:SetShown(not sub and on and true or false)
        if self.subArt then self.subArt:SetSelected(sub and on) end
    end
    -- the bar, the indent and the font of what the row shows: a page gold on the category bar, a
    -- settings tab gold and a section white on the sub-category bar
    function b:SetKind(kind)
        self.kind = kind
        local sub = kind ~= "page" and self.subArt
        if self.art then
            self.art.normal:SetShown(not sub)
            self.art.hover:SetShown(not sub)
        end
        if self.subArt then
            self.subArt.normal:SetShown(sub and true or false)
            self.subArt.hover:SetShown(sub and true or false)
        end
        local x = kind == "group" and M.NAV_SUB_X or kind == "section" and M.NAV_SUB2_X or M.NAV_LABEL_X
        self.label:ClearAllPoints()
        self.label:SetPoint("LEFT", x, 0)
        self.label:SetWidth(NAV_W - INDENT - x - 6)
        self.font = kind == "section" and T.FONT.text or T.FONT.title
        self.label:SetFontObject(self.font)
    end
    b.label = W.Text(b, T.FONT.title, M.NAV_LABEL_W)
    b.label:SetPoint("LEFT", M.NAV_LABEL_X, 0)
    if b.label.SetShadowOffset then b.label:SetShadowOffset(1, -1) end
    b.kind, b.font = "page", T.FONT.title
    b:SetScript("OnClick", function(self)
        local e = self.entry
        if e and e.kind == "section" then
            ns.ShowSettingsSection(e.key)
        elseif e and e.kind == "group" then
            -- an open tab folds, a folded one with the chosen section unfolds, another opens its first
            if e.open then
                tabShut = { key = e.key, at = e.at }
                ns.Refresh()
            elseif e.has then
                tabShut = nil
                ns.Refresh()
            else
                ns.ShowSettingsSection(e.first)
            end
        elseif self.key == "settings" and current == "settings" and ns.ShowSettingsSection then
            -- the chosen section with the tabs open, folds the tabs, unfolds them again
            local chosen = ns.SettingsChosen()
            if chosen and e then
                treeShut = e.open and e.at or nil
                ns.Refresh()
            else
                treeShut = nil
                ns.ShowSettingsSection()
            end
        else
            ns.ShowPage(self.key)
        end
    end)
    b:SetScript("OnEnter", function(self) self.label:SetFontObject(T.FONT.body) end)
    b:SetScript("OnLeave", function(self) self.label:SetFontObject(self.font or T.FONT.title) end)
    b:Hide()
    return b
end

-- A side tab as on the profession window (LargeSideTabButtonTemplate); nil without the template,
-- the side windows stay reachable from the pages and the quick menu.
local function sideTab(def)
    local ok, tab = pcall(CreateFrame, "Frame", nil, F, "LargeSideTabButtonTemplate")
    if not ok or not tab or not tab.SetCustomOnMouseUpHandler or not tab.Icon or not tab.SetChecked then
        if ok and tab then tab:Hide() end
        return nil
    end
    tab.fillToInterior = true
    tab.tooltipText = def.label
    tab.Icon:SetTexture(def.icon)
    -- the icon alone does not say what the window is for: its name, then one line (after the
    -- template's own tooltip, which shows the name alone)
    local function enter(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(def.label, 1, 0.82, 0)
        GameTooltip:AddLine(def.tip, 0.85, 0.85, 0.85, true)
        GameTooltip:Show()
    end
    tab:HookScript("OnEnter", enter)
    tab:HookScript("OnLeave", function() GameTooltip:Hide() end)
    tab:SetCustomOnMouseUpHandler(function(self, button, upInside)
        if button ~= "LeftButton" or not upInside then return end
        def.toggle()
        ns.UpdateSideTabs()
    end)
    tab:Hide()
    return tab
end

local function build()
    F = W.Window("AmisiaFrame", WIDTH, HEIGHT, { portrait = PORTRAIT, strata = "FULLSCREEN",
        title = "Amisia |cff8f86a3" .. (ns.VERSION or "") .. "|r", background = "Profession-Background-Overview",
        onShow = function(self)
            if self.Raise then self:Raise() end
            ns.Refresh()
            -- the setup offer (Setup.lua) at the first open after a login
            ns.Fire("MAIN_SHOWN")
        end,
        onDragStop = function() savePosition() end })
    restorePosition()
    ns.ApplyScale()

    -- the head (D-67): the recording state as plain text, centred between the portrait and the icons,
    -- on the frame's own ground (a dark bar there did not fit the window's look); a click on it or on
    -- its arrow opens the menu with the recording and the view. Right: "?" and the gear, no red buttons.
    local BAR_W = WIDTH - M.HEAD_X - M.ICON_RIGHT - 2 * (M.ICON_SIZE + M.ICON_GAP)
    local bar = CreateFrame("Button", nil, F)
    bar:SetSize(BAR_W, M.HEAD_H)
    bar:SetPoint("TOPLEFT", M.HEAD_X, -M.HEAD_Y)
    statusBar = bar
    statusText = W.Text(bar, T.FONT.body)
    statusText:SetPoint("CENTER", bar, "CENTER", -(M.MENU_SIZE + M.ICON_GAP) / 2, 0)
    statusText:SetJustifyH("CENTER")
    if statusText.SetShadowOffset then statusText:SetShadowOffset(1, -1) end
    local function openMenu() W.Menu(menuBtn, headMenu()) end
    menuBtn = W.ArrowButton(bar, "down", M.MENU_SIZE, openMenu)
    menuBtn:SetPoint("LEFT", statusText, "RIGHT", M.ICON_GAP, 0)
    bar:SetScript("OnClick", openMenu)
    -- the status line still moves the window, as the head did before it took the mouse
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function() F:StartMoving() end)
    bar:SetScript("OnDragStop", function()
        F:StopMovingOrSizing()
        savePosition()
    end)
    local function statusTip(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine(L["Raid-Aufnahme"], 1, 0.82, 0)
        GameTooltip:AddLine(ns.IsEnabled() and L["Aufnahme an: startet von selbst in einer Raidinstanz mit Raidgruppe."]
            or L["Aufnahme pausiert."], 0.85, 0.85, 0.85, true)
        GameTooltip:AddLine(ns.IsOfficerView() and L["Ansicht: Offiziere"] or L["Ansicht: Raider"], 0.85, 0.85, 0.85)
        GameTooltip:AddLine(L["Klick: pausieren, fortsetzen oder die Ansicht wechseln."], 0.6, 0.6, 0.6, true)
        GameTooltip:Show()
    end
    bar:SetScript("OnEnter", statusTip)
    bar:SetScript("OnLeave", function() GameTooltip:Hide() end)
    menuBtn:HookScript("OnEnter", statusTip)
    menuBtn:HookScript("OnLeave", function() GameTooltip:Hide() end)
    -- the portrait: a click opens the overview from every tab (the window's "home")
    local portrait = F.PortraitContainer and F.PortraitContainer.portrait or F.portrait
    if portrait then
        homeBtn = CreateFrame("Button", nil, F.PortraitContainer or F)
        homeBtn:SetAllPoints(portrait)
        -- dragging the portrait still moves the window
        homeBtn:RegisterForDrag("LeftButton")
        homeBtn:SetScript("OnDragStart", function() F:StartMoving() end)
        homeBtn:SetScript("OnDragStop", function()
            F:StopMovingOrSizing()
            savePosition()
        end)
        homeBtn:SetScript("OnClick", function()
            ns.ClearSearch()
            ns.ShowPage("overview")
        end)
        W.Tooltip(homeBtn, L["Übersicht"], L["Ein Klick auf das Bild öffnet die Übersicht, von jedem Reiter aus."])
    end
    -- the settings of the open page (D-49): the quest log's gear, shown only when it has some
    settingsBtn = W.IconButton(F, M.ICON_SIZE, { atlas = "questlog-icon-setting" }, function() ns.ShowSettingsFor(current) end,
        L["E##Einstellungen"])
    settingsBtn:SetPoint("TOPRIGHT", -M.ICON_RIGHT, -M.HEAD_Y)
    settingsBtn:SetScript("OnEnter", function(self)
        local names = {}
        for _, sec in ipairs(ns.SettingsSectionsOf(current)) do names[#names + 1] = sec.label end
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine(L["Einstellungen"], 1, 0.82, 0)
        GameTooltip:AddLine(table.concat(names, ", "), 0.85, 0.85, 0.85, true)
        GameTooltip:Show()
    end)
    settingsBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    settingsBtn:Hide()
    -- the open page's explanations (D-67): the client's help sign, as on its own windows
    helpBtn = W.IconButton(F, M.ICON_SIZE, { file = "Interface\\common\\help-i" }, nil, "?")
    helpBtn:SetPoint("TOPRIGHT", -M.ICON_RIGHT, -M.HEAD_Y)
    helpBtn:SetScript("OnEnter", function(self)
        local p = ns.Panel(current)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine(p and p.label or L["Hilfe"], 1, 0.82, 0)
        for _, line in ipairs(W.HelpLines(content)) do GameTooltip:AddLine(line, 0.85, 0.85, 0.85, true) end
        GameTooltip:Show()
    end)
    helpBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    helpBtn:Hide()

    -- the page list in an inset with the recipe list's ground, the page in an inset beside it
    local listInset = W.Inset(F)
    listInset:SetPoint("TOPLEFT", M.MARGIN, -M.TOP)
    listInset:SetPoint("BOTTOMLEFT", M.MARGIN, M.MARGIN)
    listInset:SetWidth(M.LIST_W)
    listInset.fill("Professions-background-summarylist")
    local contentInset = W.Inset(F)
    contentInset:SetPoint("TOPLEFT", M.CONTENT_X, -M.TOP)
    contentInset:SetPoint("BOTTOMRIGHT", -M.MARGIN, M.MARGIN)

    -- the search box at the list's top, the pages (or the results) under it
    search = W.SearchBox(listInset, NAV_W, nil)
    search:SetPoint("TOPLEFT", M.INNER, -M.INNER)
    search:HookScript("OnTextChanged", function(self) setQuery(self:GetText()) end)
    search:SetScript("OnEscapePressed", function() ns.ClearSearch() end)
    if search.clearButton then search.clearButton:HookScript("OnClick", function() ns.ClearSearch() end) end
    -- what the box finds and from how many characters; above the window, so it never covers the hits
    search:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(L["Suchen"], 1, 0.82, 0)
        GameTooltip:AddLine(L["Ab %d Zeichen: Seiten, Einstellungen, Dungeons und in der Offiziersansicht Spieler. Ab %d Zeichen auch Items, Rezepte und Befehle. Stichwörter finden die passende Seite, z. B. \"dkp\" die Punkte. Escape leert das Feld."]
            :format(M.SEARCH_MIN, ns.SearchIndex.ITEM_MIN), 0.85, 0.85, 0.85, true)
        GameTooltip:Show()
    end)
    search:HookScript("OnLeave", function() GameTooltip:Hide() end)
    local listTop = M.INNER + T.FIELD_H + M.SEARCH_GAP
    nav = CreateFrame("Frame", nil, listInset)
    nav:SetPoint("TOPLEFT", M.INNER, -listTop)
    nav:SetPoint("BOTTOMRIGHT", -M.INNER, M.INNER)
    for i = 1, NAV_MAX do navButtons[i] = navRow() end
    results = W.List(listInset, M.RES_ROWS, M.RES_ROW_H, buildResult, fillResult)
    results:SetPoint("TOPLEFT", M.INNER, -listTop)
    results:SetWidth(NAV_W - T.SCROLL_ROOM)
    results:Hide()
    noHits = W.Text(listInset, T.FONT.hint, NAV_W - 8, true)
    noHits:SetPoint("TOP", results, "TOP", 0, -T.LAYOUT.EMPTY_Y)
    noHits:SetJustifyH("CENTER")
    noHits:SetText(L["Nichts gefunden."])
    noHits:Hide()
    -- under SEARCH_MIN characters: how many more (updateSearchHint places it under the last bar)
    searchHint = W.Text(listInset, T.FONT.hint, NAV_W - 2 * M.NAV_LABEL_X)
    searchHint:Hide()

    -- 602 x 478, as before: the pages keep their layout
    content = CreateFrame("Frame", nil, contentInset)
    content:SetPoint("TOPLEFT", M.PAGE_PAD, -M.PAGE_PAD)
    content:SetPoint("BOTTOMRIGHT", -M.PAGE_PAD, M.PAGE_PAD)

    for _, def in ipairs(SIDE_TABS) do
        local tab = sideTab(def)
        if tab then sideTabs[def.key] = tab end
    end
    for _, g in ipairs(ns.PANEL_GROUPS) do bottomTabs[g.key] = bottomTab(g) end
    -- test hooks and the parts the layout tests read
    F.statusBar, F.statusText, F.menuBtn, F.helpBtn, F.settingsBtn, F.headMenu = statusBar, statusText, menuBtn, helpBtn, settingsBtn, headMenu
    F.listInset, F.contentInset, F.nav, F.content = listInset, contentInset, nav, content
    F.sideTabs, F.navOrder, F.tabs, F.tabOrder = sideTabs, {}, bottomTabs, {}
    F.search, F.results, F.noHits, F.searchHint, F.homeBtn = search, results, noHits, searchHint, homeBtn
end

function ns.CurrentPage() return current end
function ns.PreviousPage() return previous end

-- Shows the page key (a page not shown now: the overview, else the first shown). chosen: the player
-- (or a command) asked for it, so it is remembered as its tab's page; a redirect is not (the page
-- before it stays the tab's page, and the tab follows what is shown).
local function showPage(key, chosen)
    if not F then build() end
    local p = ns.Panel(key)
    if not ns.Visible(p) then p = ns.Panel("overview") end
    if not ns.Visible(p) then
        for _, other in ipairs(ns.panels) do
            if ns.Visible(other) then p = other break end
        end
    end
    if not p then return end
    if current ~= p.key then previous = current end
    current = p.key
    -- the tab follows the page; both are remembered for the next open, the page only when asked for
    local w = windowState()
    w.tab = ns.PanelGroup(p)
    if chosen and p.key == key then w.pages[w.tab] = current end
    for k, frame in pairs(built) do
        if k ~= current then frame:Hide() end
    end
    if not built[current] then
        local ok, frame = pcall(p.create, content)
        if not ok or type(frame) ~= "table" then
            -- not passed to the error handler: the error page shows it and the window stays usable
            frame = errorPage(content, ok and L["create gab keinen Frame zurück"] or frame)
        end
        frame:SetAllPoints(content)
        built[current] = frame
    end
    built[current]:Show()
    if F:IsShown() then ns.Refresh() else F:Show() end
end

function ns.ShowPage(key) showPage(key, true) end

local soonPending, soonDirty = false, false
function ns.Refresh()
    if not F or not F:IsShown() then return end
    soonDirty = false
    local p = ns.Panel(current)
    if not ns.Visible(p) then
        showPage("overview", false)
        return
    end
    updateHeader()
    local byGroup = pagesByGroup()
    updateNav(byGroup)
    updateTabs(byGroup)
    -- the hits again for the new data, at the same scroll place
    if #query >= M.SEARCH_MIN then showResults() else updateSearchHint() end
    ns.UpdateSideTabs()
    local frame = built[current]
    if p.refresh and frame then
        local ok, err = pcall(p.refresh, frame)
        if not ok then reportError(err) end
    end
    updateHelp()
end

-- A refresh at the next frame for data changes (a loot line, an award, a sync, a roster snapshot, a
-- setting): many in one frame make one refresh; nothing while the window is closed (its show
-- refreshes). A refresh in between (a click) takes the place of the waiting one.
function ns.RefreshSoon()
    if not F or not F:IsShown() then return end
    soonDirty = true
    if soonPending then return end
    soonPending = true
    C_Timer.After(0, function()
        soonPending = false
        if soonDirty then ns.Refresh() end
    end)
end

-- The page the window opens with: the open one, else the last of the last tab, else the overview.
local function startPage()
    if current then return current end
    local w = AmisiaDB and AmisiaDB.settings and windowState()
    return (w and w.tab and tabPage(w.tab)) or "overview"
end

function ns.ToggleMain()
    if F and F:IsShown() then F:Hide() else ns.ShowPage(startPage()) end
end

-- The old entry point: /amisia export and the minimap called it with the newest session.
function ns.Toggle(exportLatest)
    if exportLatest and ns.ShowExport then ns.ShowExport(true) else ns.ToggleMain() end
end

ns.Listen("SETTING", function() ns.RefreshSoon() end)
ns.Listen("DATA_CHANGED", function() ns.RefreshSoon() end)

local VIEW_WORDS = { offizier = "officer", officer = "officer", raider = "raider", auto = "auto", automatisch = "auto" }   -- l10n-ok: typed words
ns.RegisterSlash("ansicht", { en = "view", args = L["[offizier|raider|auto]"], desc = L["Offiziers- oder Raider-Ansicht"],
    run = function(rest)
        local word = (type(rest) == "string" and rest:match("^%s*(%S*)") or ""):lower()
        local view = VIEW_WORDS[word]
        if word ~= "" and not view then
            ns.msg(L["Aufruf: /amisia ansicht [offizier|raider|auto]"])
            return
        end
        if view then
            ns.Set("ui.view", view)
            if ns.Refresh then ns.Refresh() end
        end
        local set = ns.Get("ui.view")
        ns.msg(L["Ansicht: %s%s."]:format(ns.IsOfficerView() and L["Offizier"] or "Raider",
            set == "auto" and (" (" .. L["Automatisch"] .. ")") or ""))
    end })

-- With a word: the section it names (ns.SettingsSection), else the settings searched for it.
ns.RegisterSlash("einstellungen", { en = "settings", aliases = { "optionen", "config" }, args = L["[Abschnitt oder Suchwort]"],
    desc = L["Einstellungen öffnen"],
    run = function(rest)
        rest = rest:match("^%s*(.-)%s*$") or ""
        if rest == "" then return ns.ShowPage("settings") end
        local sec = ns.SettingsSection(rest)
        if sec then ns.ShowSettingsSection(sec.key) elseif ns.ShowSettings then ns.ShowSettings(rest) end
    end })
