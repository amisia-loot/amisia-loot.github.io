-- The main window's search (D-45): what the search box over the page list finds, grouped "Seiten",
-- "Einstellungen" (a section by its name or its tab's, e.g. "Allgemein", then the single settings),
-- "Rezepte" (every recipe of the profession data by the client's spell name), "Dungeons", "Items",
-- "Spieler", "Befehle"; pages and settings sections also by their keywords (PAGE_WORDS,
-- SECTION_WORDS: "dkp" finds the page Punkte). UI/MainFrame.lua shows the hits in place of the page list and
-- runs a hit's action on a click. Kept fast: nothing at all under T.MAIN.SEARCH_MIN characters,
-- items only once the gear data is built or from 3 characters on (only then may the gear data be
-- built), the indexes of items and players built once and kept for a while, at most RES_MAX hits per
-- group. Item names come only from what the client already holds (AmisiaDB.itemNames and cached
-- items): the search never asks the server for an item. Players only in the officer view (D-36: the
-- numbers per player are the officers').
local ADDON, ns = ...
local L = ns.L
local T = ns.Theme
local M = T.MAIN

local Search = {}
ns.SearchIndex = Search

Search.ITEM_MIN = 3        -- characters before the gear data may be built for the item names
Search.KEEP = 60           -- seconds an index is kept before it is built again

local function hit(text, q)
    return type(text) == "string" and ns.Fold(text):find(q, 1, true) ~= nil
end

local function now() return GetTime and GetTime() or 0 end

---------------------------------------------------------------------------
-- Items
---------------------------------------------------------------------------
local items, itemsAt, itemsGear   -- { { id, name, low, q } }, when built, the gear table it read

local function itemInfo(id)
    if not (C_Item and C_Item.GetItemInfo) then return nil end
    local ok, name, link, q = pcall(C_Item.GetItemInfo, id)
    if ok then return name, link, q end
    return nil
end

-- The item names the client holds: those Amisia saw (loot, awards, soft-reserves) and, when allowed,
-- the gear data's items the client has cached (no server question).
local function itemIndex(withGear)
    local gear = withGear and ns.Data and ns.HasData("GEAR") and ns.Data("GEAR") or rawget(ns, "GEAR")
    if items and itemsGear == gear and now() - itemsAt < Search.KEEP then return items end
    local out, seen = {}, {}
    local known = AmisiaDB and AmisiaDB.itemNames or {}
    for id, e in pairs(known) do
        local name = type(e) == "table" and e.n
        if type(id) == "number" and type(name) == "string" and name ~= "" and name ~= ("Item " .. id) then
            seen[id] = true
            out[#out + 1] = { id = id, name = name, low = ns.Fold(name), q = tonumber(e.q) }
        end
    end
    local cached = C_Item and C_Item.IsItemDataCachedByID
    if type(gear) == "table" and type(gear.I) == "table" and cached then
        for id in pairs(gear.I) do
            if type(id) == "number" and not seen[id] and cached(id) then
                local name, _, q = itemInfo(id)
                if type(name) == "string" and name ~= "" then
                    seen[id] = true
                    out[#out + 1] = { id = id, name = name, low = ns.Fold(name), q = q }
                end
            end
        end
    end
    items, itemsAt, itemsGear = out, now(), gear
    return out
end

-- The item's link into the chat line (the open one, else the chat opens with it).
local function linkToChat(id)
    local _, link = itemInfo(id)
    if not link then return end
    local CU = _G.ChatFrameUtil
    if CU and CU.InsertLink and CU.InsertLink(link) then return end
    if CU and CU.OpenChat then CU.OpenChat(link) end
end

local function itemHits(q)
    local gearBuilt = rawget(ns, "GEAR") ~= nil
    if not gearBuilt and #q < Search.ITEM_MIN then return {} end
    local found = {}
    for _, e in ipairs(itemIndex(#q >= Search.ITEM_MIN)) do
        if e.low:find(q, 1, true) then found[#found + 1] = e end
    end
    table.sort(found, function(a, b)
        local sa, sb = a.low:sub(1, #q) == q, b.low:sub(1, #q) == q
        if sa ~= sb then return sa end
        return a.low < b.low
    end)
    local out = {}
    for i = 1, math.min(#found, M.RES_MAX) do
        local e = found[i]
        local color = e.q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[e.q]
        out[i] = { text = e.name, label = color and color.hex and (color.hex .. e.name .. "|r") or e.name, item = e.id,
            run = function() linkToChat(e.id) end }
    end
    return out
end

---------------------------------------------------------------------------
-- Players
---------------------------------------------------------------------------
local players, playersAt   -- { { name, low, class } }

local function playerIndex()
    if players and now() - playersAt < Search.KEEP then return players end
    local out, byLow = {}, {}
    local function add(name, class)
        if type(name) ~= "string" or name == "" or name == "-" then return end
        local low = ns.Fold(name)
        local e = byLow[low]
        if not e then
            e = { name = name, low = low }
            byLow[low] = e
            out[#out + 1] = e
        end
        if type(class) == "string" and class ~= "" then e.class = e.class or class end
    end
    for _, s in ipairs(ns.Sessions and ns.Sessions() or {}) do
        for name, m in pairs(type(s.members) == "table" and s.members or {}) do add(name, type(m) == "table" and m.class) end
        for _, a in ipairs(type(s.awards) == "table" and s.awards or {}) do
            if a.to == nil or a.to == "player" then add(a.name) end
        end
    end
    local lineup = AmisiaDB and AmisiaDB.lineup
    for _, n in pairs(type(lineup) == "table" and type(lineup.nights) == "table" and lineup.nights or {}) do
        for _, e in ipairs(type(n) == "table" and type(n.list) == "table" and n.list or {}) do add(e.n, e.c) end
    end
    players, playersAt = out, now()
    return out
end

local function playerHits(q)
    if not ns.IsOfficerView() then return {} end
    local found = {}
    for _, e in ipairs(playerIndex()) do
        if e.low:find(q, 1, true) then found[#found + 1] = e end
    end
    table.sort(found, function(a, b) return a.low < b.low end)
    local out = {}
    for i = 1, math.min(#found, M.RES_MAX) do
        local e = found[i]
        out[i] = { text = e.name, label = ns.ClassColored(e.name, e.class),
            tip = L["Öffnet die Statistik dieses Spielers."],
            run = function() if ns.ShowStats then ns.ShowStats("players", e.name) end end }
    end
    return out
end

---------------------------------------------------------------------------
-- Recipes and dungeons
---------------------------------------------------------------------------
local recipes, recipesData   -- { { name, low, skill, spell, learn } }, the profession table it read

-- Every recipe by the client's spell name (spell names are the client's own data: no server question).
-- Built once from Search.ITEM_MIN characters on (only then may the profession data be built).
local function recipeIndex()
    local Pr = ns.Prof
    if not Pr or not Pr.Available() then return {} end
    local d = ns.Data("PROFESSIONS")
    if recipes and recipesData == d then return recipes end
    local out = {}
    for _, skill in ipairs(Pr.Skills()) do
        for _, r in ipairs(Pr.Recipes(skill)) do
            local name = Pr.SpellName(r.spell) or (r.item > 0 and Pr.ItemInfo(r.item)) or nil
            if type(name) == "string" and name ~= "" then
                out[#out + 1] = { name = name, low = ns.Fold(name), skill = skill, spell = r.spell, learn = r.learn }
            end
        end
    end
    recipes, recipesData = out, d
    return out
end

local function byStart(q)
    return function(a, b)
        local sa, sb = a.low:sub(1, #q) == q, b.low:sub(1, #q) == q
        if sa ~= sb then return sa end
        if a.low ~= b.low then return a.low < b.low end
        return (a.learn or 0) < (b.learn or 0)
    end
end

local function recipeHits(q)
    if #q < Search.ITEM_MIN then return {} end
    local page = ns.Panel and ns.Panel("professions")
    if not page or not ns.Visible(page) then return {} end
    local found = {}
    for _, e in ipairs(recipeIndex()) do
        if e.low:find(q, 1, true) then found[#found + 1] = e end
    end
    table.sort(found, byStart(q))
    local Pr, out = ns.Prof, {}
    for i = 1, math.min(#found, M.RES_MAX) do
        local e = found[i]
        out[i] = { text = e.name,
            tip = L["%s, ab Fertigkeit %d. Öffnet das Rezept auf der Seite Berufe."]:format(Pr.Name(e.skill), e.learn or 0),
            run = function() if ns.ShowRecipe then ns.ShowRecipe(e.skill, e.spell, e.name) end end }
    end
    return out
end

local function dungeonHits(q)
    local page = ns.Panel and ns.Panel("dungeons")
    local Dn = ns.Dungeons
    if not page or not ns.Visible(page) or not Dn or not Dn.Facts then return {} end
    local found = {}
    for _, e in ipairs(Dn.Facts() or {}) do
        if type(e) == "table" and type(e.key) == "string" then
            local name = Dn.Name(e)
            local low = ns.Fold(name)
            -- the client's name and the fact's (an English name on a German client) both find it
            if low:find(q, 1, true) or hit(e.name, q) then
                found[#found + 1] = { name = name, low = low, key = e.key, kind = e.kind }
            end
        end
    end
    table.sort(found, byStart(q))
    local out = {}
    for i = 1, math.min(#found, M.RES_MAX) do
        local e = found[i]
        out[i] = { text = e.name,
            tip = e.kind == "raid" and L["Raid. Öffnet ihn auf der Seite Raids."] or L["Dungeon. Öffnet ihn auf der Seite Dungeons."],
            run = function() if ns.ShowDungeon then ns.ShowDungeon(e.key) end end }
    end
    return out
end

---------------------------------------------------------------------------
-- Keywords
---------------------------------------------------------------------------
-- Search words of a page (by its key) and of a settings section (by its key), German and English,
-- lower case: never shown, only matched at a word's start, so "dkp" finds the page Punkte and
-- "waypoint" the map. A word the name already holds needs no entry.
Search.PAGE_WORDS = {
    overview = "start home übersicht overview",   -- l10n-ok: search words
    raids = "sessions aufzeichnungen recorded",   -- l10n-ok: search words
    lineup = "aufstellung lineup gruppen groups einladen invite",   -- l10n-ok: search words
    raidcheck = "buffs flask fläschchen verbrauch consumables reparatur durability",   -- l10n-ok: search words
    raidlog = "log protokoll verlauf history",   -- l10n-ok: search words
    rolls = "loot vergabe würfeln roll dice",   -- l10n-ok: search words
    awards = "loot vergabe würfeln roll awards verteilen",   -- l10n-ok: search words
    stats = "statistik stats teilnahme attendance",   -- l10n-ok: search words
    points = "dkp epgp punkte points gebote bids",   -- l10n-ok: search words
    softres = "reserve reservierung sr softres",   -- l10n-ok: search words
    gear = "bis ausrüstung gear upgrade ziele goals wunschliste wishlist",   -- l10n-ok: search words
    dungeons = "instanz instance planer",   -- l10n-ok: search words
    raidjournal = "journal bosse bosses instanz instance",   -- l10n-ok: search words
    map = "wegpunkt waypoint pfeil arrow karte map",   -- l10n-ok: search words
    quests = "questweg questlog",   -- l10n-ok: search words
    professions = "berufe rezepte recipes crafting professions handwerk",   -- l10n-ok: search words
    scrolls = "magier mage schriftrollen scrolls",   -- l10n-ok: search words
    talents = "skillung talents build talentbaum",   -- l10n-ok: search words
    export = "website csv",   -- l10n-ok: search words
    members = "gilde mitglieder roster guild members",   -- l10n-ok: search words
    bank = "gildenbank guild bank",   -- l10n-ok: search words
    calendar = "termin raidkalender event calendar",   -- l10n-ok: search words
    duels = "duell duel",   -- l10n-ok: search words
    settings = "optionen options config einstellungen settings",   -- l10n-ok: search words
    about = "hilfe help befehle commands version",   -- l10n-ok: search words
    feedback = "bug fehler wunsch melden report",   -- l10n-ok: search words
}
Search.SECTION_WORDS = {
    points = "dkp epgp punkte points",   -- l10n-ok: search words
    rolls = "loot würfeln roll",   -- l10n-ok: search words
    rollwin = "würfeln roll dice fenster window",   -- l10n-ok: search words
    awards = "loot vergabe awards",   -- l10n-ok: search words
    map = "wegpunkt waypoint pfeil arrow karte map",   -- l10n-ok: search words
    softres = "reserve sr softres",   -- l10n-ok: search words
    signup = "anmeldung signup termin calendar",   -- l10n-ok: search words
    lineup = "aufstellung lineup einladen invite",   -- l10n-ok: search words
    bis = "bis ausrüstung gear upgrade",   -- l10n-ok: search words
    ui = "minimap größe scale ansicht view",   -- l10n-ok: search words
    record = "aufnahme recording",   -- l10n-ok: search words
}

local folded = {}   -- keyword text -> its folded words
local function wordHit(text, q)
    if type(text) ~= "string" then return false end
    local words = folded[text]
    if not words then
        words = {}
        for w in ns.Fold(text):gmatch("%S+") do words[#words + 1] = w end
        folded[text] = words
    end
    for _, w in ipairs(words) do
        if w:sub(1, #q) == q then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Pages and settings
---------------------------------------------------------------------------
-- The pages by name first, then those a keyword names.
local function pageHits(q)
    local out, named = {}, {}
    local function add(p)
        -- the tab in the tooltip: two pages may share a name (Raids in Raid and in Dungeons & Raids)
        local tab = ns.PanelGroup(p)
        for _, g in ipairs(ns.PANEL_GROUPS) do
            if g.key == tab then tab = g.label end
        end
        out[#out + 1] = { text = p.label, tip = L["Seite im Reiter %s."]:format(tab),
            run = function() ns.ShowPage(p.key) end }
    end
    for _, p in ipairs(ns.panels) do
        if #out >= M.RES_MAX then return out end
        if ns.Visible(p) and hit(p.label, q) then
            named[p.key] = true
            add(p)
        end
    end
    for _, p in ipairs(ns.panels) do
        if #out >= M.RES_MAX then break end
        if not named[p.key] and ns.Visible(p) and wordHit(Search.PAGE_WORDS[p.key], q) then add(p) end
    end
    return out
end

local function settingHits(q)
    local out = {}
    -- the sections first: by their name or their tab's ("Allgemein", "Raid", ...)
    for _, g in ipairs(ns.SettingsGroups and ns.SettingsGroups() or {}) do
        local tabHit = hit(g.label, q)
        for _, section in ipairs(g.sections or {}) do
            if #out >= M.RES_MAX then return out end
            if tabHit or hit(section.label, q) or wordHit(Search.SECTION_WORDS[section.key], q) then
                out[#out + 1] = { text = section.label,
                    tip = L["Einstellungen, Reiter %s. Öffnet den Abschnitt."]:format(g.label),
                    run = function() if ns.ShowSettingsSection then ns.ShowSettingsSection(section.key) end end }
            end
        end
    end
    for _, section in ipairs(ns.schema) do
        if ns.Visible(section) then
            for _, it in ipairs(section.items) do
                if #out >= M.RES_MAX then return out end
                if it.key and it.label and it.type ~= "desc" and ns.Visible(it) and ns.SettingHits(it, q) then
                    out[#out + 1] = { text = it.label, tip = section.label .. (it.tip and ("\n" .. it.tip) or ""),
                        run = function() if ns.ShowSettings then ns.ShowSettings(it.label) end end }
                end
            end
        end
    end
    return out
end

---------------------------------------------------------------------------
-- Commands
---------------------------------------------------------------------------
-- "/amisia <word> " into the chat line (the open one, else the chat opens with it): the player adds
-- what the command wants and sends it with Enter; nothing runs by the click itself.
local function commandToChat(text)
    local CU = _G.ChatFrameUtil
    if CU and CU.OpenChat then
        CU.OpenChat(text)
    elseif ChatFrame_OpenChat then
        ChatFrame_OpenChat(text)
    end
end

-- The commands of the help (ns.SlashHelpLines' rules: officers' only in the officer view, Forever's
-- only on Forever) by their words and their description, from Search.ITEM_MIN characters.
local function commandHits(q)
    if #q < Search.ITEM_MIN then return {} end
    local officer = ns.IsOfficerView()
    local out = {}
    for _, def in ipairs(ns.slash or {}) do
        if #out >= M.RES_MAX then break end
        if (officer or not def.officer) and (ns.FOREVER or not def.forever) then
            local found = wordHit(def.word, q) or wordHit(def.en, q) or hit(def.desc, q)
            for _, a in ipairs(def.aliases or {}) do found = found or wordHit(a, q) end
            if found then
                local word = ns.SlashWord(def)
                -- the bar shows the command alone (the arguments would not fit), the tooltip the rest
                out[#out + 1] = { text = "/amisia " .. word,
                    tip = (def.args and ("/amisia " .. word .. " " .. def.args .. "\n") or "")
                        .. (def.desc and (def.desc .. "\n") or "") .. L["Ein Klick schreibt den Befehl in die Chatzeile."],
                    run = function() commandToChat("/amisia " .. word .. " ") end }
            end
        end
    end
    return out
end

-- The hits of text: { { key, label, hits = { { text, label, tip, item, run } } } },
-- the groups without a hit left out; nothing under SEARCH_MIN characters.
function ns.Search(text)
    local q = ns.Fold(tostring(text or ""):match("^%s*(.-)%s*$") or "")
    if #q < M.SEARCH_MIN then return {} end
    local groups = {
        { key = "pages", label = L["Seiten"], find = pageHits },
        { key = "settings", label = L["Einstellungen"], find = settingHits },
        { key = "recipes", label = L["Rezepte"], find = recipeHits },
        { key = "dungeons", label = "Dungeons", find = dungeonHits },
        { key = "items", label = "Items", find = itemHits },
        { key = "players", label = L["Spieler##Suche"], find = playerHits },
        { key = "commands", label = L["Befehle"], find = commandHits },
    }
    local out = {}
    for _, g in ipairs(groups) do
        -- a broken group must not stop the typing: its error goes to the client's handler
        local ok, hits = pcall(g.find, q)
        if not ok then
            ns.ReportError(hits)
        elseif #hits > 0 then
            out[#out + 1] = { key = g.key, label = g.label, hits = hits }
        end
    end
    return out
end

-- for the tests: forget the indexes
function Search._reset() items, itemsAt, itemsGear, players, playersAt, recipes, recipesData = nil, nil, nil, nil, nil, nil, nil end

ns.Listen("DATA_CHANGED", function() players = nil end)
