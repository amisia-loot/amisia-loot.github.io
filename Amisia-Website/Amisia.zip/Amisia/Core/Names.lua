-- Character names. WoW Forever names are "First Surname" (one space, the surname may hold a
-- dash). Everything that compares names goes through FullName and SameName, and the export writes
-- "_" for the space (no WoW name holds an underscore), so its fields stay space-separated.
local ADDON, ns = ...
local L = ns.L

-- One spelling of a name: trimmed, single spaces, and the surname added when it comes separately
-- (UnitName's second value). A dash stays: it belongs to the surname.
function ns.FullName(name, surname)
    if type(name) ~= "string" then return nil end
    name = name:match("^%s*(.-)%s*$"):gsub("%s+", " ")
    if type(surname) == "string" and surname ~= "" and not name:find(" ", 1, true) then
        name = name .. " " .. surname
    end
    if name == "" then return nil end
    return name
end

function ns.UnitFullName(unit)
    local name, second = UnitName(unit)
    return ns.FullName(name, second)
end

-- Whether two spellings mean the same character. A side without surname (a client that leaves it
-- out in one place) matches on the first name.
function ns.SameName(a, b)
    a, b = ns.FullName(a), ns.FullName(b)
    if not a or not b then return false end
    if a:lower() == b:lower() then return true end
    if not a:find(" ", 1, true) or not b:find(" ", 1, true) then
        return a:match("^(%S+)"):lower() == b:match("^(%S+)"):lower()
    end
    return false
end

-- The group, read once per frame (every addon message, roll line and roll window refresh asks for
-- it, often once per name): list = the plain names in roster order (secret ones left out), class[i]
-- = the plain class token of list[i]; low[lower name] = its first spelling. Read again in the next
-- frame, when the member count changes, and on GROUP_ROSTER_UPDATE, the lockdown changing and an
-- encounter (names turn secret or plain).
local groupAt, groupCount, groupIdx
local function groupIndex()
    local t, count = GetTime(), GetNumGroupMembers() or 0
    if groupIdx and groupAt == t and groupCount == count then return groupIdx end
    local idx = { list = {}, class = {}, low = {} }
    for i = 1, count do
        local raw, _, _, _, _, class = GetRaidRosterInfo(i)
        local n = ns.FullName(ns.Plain(raw))
        if n then
            local k = #idx.list + 1
            idx.list[k], idx.class[k] = n, ns.Plain(class)
            local low = n:lower()
            if not idx.low[low] then idx.low[low] = n end
        end
    end
    groupAt, groupCount, groupIdx = t, count, idx
    return idx
end
-- read only: callers must not change it
ns.GroupIndex = groupIndex

-- The first names of the group index idx, made when a lookup needs them (a name the group does
-- not hold as it is): first[lower first name] = { n = names carrying it, d = different spellings,
-- m = the first of them, k = its index in list, [1..d] = those spellings in lower case }.
local function groupFirst(idx)
    idx = idx or groupIndex()
    local first = idx.first
    if first then return first end
    first = {}
    local seen = {}
    for k, n in ipairs(idx.list) do
        local low = n:lower()
        local f = low:match("^(%S+)")
        local e = first[f]
        if not e then
            e = { n = 0, d = 0, m = n, k = k }
            first[f] = e
        end
        e.n = e.n + 1
        if not seen[low] then
            seen[low] = true
            e.d = e.d + 1
            e[e.d] = low
        end
    end
    idx.first = first
    return first
end
ns.GroupFirst = groupFirst

local function dropGroup() groupIdx = nil end
for _, event in ipairs({ "GROUP_ROSTER_UPDATE", "ADDON_RESTRICTION_STATE_CHANGED", "ENCOUNTER_START", "ENCOUNTER_END",
                         "PLAYER_ENTERING_WORLD" }) do
    ns.OnEvent(event, dropGroup)
end

-- The plain names of the group (secret ones left out); {} when alone. A new table each call.
function ns.GroupRoster()
    local out = {}
    for i, n in ipairs(groupIndex().list) do out[i] = n end
    return out
end

-- How many names of roster carry the first name of name.
local function firstNameCount(name, roster)
    local first = name:match("^(%S+)"):lower()
    local n = 0
    for _, r in ipairs(roster or {}) do
        r = ns.FullName(r)
        if r and r:match("^(%S+)"):lower() == first then n = n + 1 end
    end
    return n
end

-- ns.SameName within a group: a match on the first name alone (one side without surname) holds
-- only when no more than one name of roster carries that first name. "Vulo" on a list is no one
-- when "Vulo Sturmwind" and "Vulo Eisherz" are both in the raid.
function ns.SameNameIn(a, b, roster)
    a, b = ns.FullName(a), ns.FullName(b)
    if not a or not b then return false end
    if a:lower() == b:lower() then return true end
    if not ns.SameName(a, b) then return false end
    return firstNameCount(a, roster) <= 1
end

-- ns.SameNameIn(a, b, ns.GroupRoster()) through the group index.
function ns.SameNameInGroup(a, b)
    a, b = ns.FullName(a), ns.FullName(b)
    if not a or not b then return false end
    if a:lower() == b:lower() then return true end
    if not ns.SameName(a, b) then return false end
    local e = groupFirst()[a:match("^(%S+)"):lower()]
    return (e and e.n or 0) <= 1
end

-- Whether a name is in the own group (ns.SameNameIn over the group): the same spelling, else the
-- one name of the group with its first name when one side has no surname.
function ns.InMyGroup(name)
    local idx = groupIndex()
    if #idx.list == 0 then return false end
    name = ns.FullName(name)
    if not name then return false end
    local low = name:lower()
    if idx.low[low] then return true end
    local e = groupFirst(idx)[low:match("^(%S+)")]
    return e ~= nil and e.n == 1 and (not low:find(" ", 1, true) or not e.m:find(" ", 1, true))
end

-- Whether a name belongs to the group (ns.SameName, the first of the roster that fits); true and
-- its class token.
function ns.InGroup(name)
    local idx = groupIndex()
    if #idx.list == 0 then return false end
    name = ns.FullName(name)
    if not name then return false end
    local low = name:lower()
    local e = groupFirst(idx)[low:match("^(%S+)")]
    if not e then return false end
    local f, spaced = low:match("^(%S+)"), low:find(" ", 1, true)
    -- the names with this first name, in roster order (the first at e.k)
    local seen = 0
    for k = e.k, #idx.list do
        local n = idx.list[k]
        local nl = n:lower()
        if k == e.k or nl:match("^(%S+)") == f then
            if not spaced or nl == low or not n:find(" ", 1, true) then return true, idx.class[k] end
            seen = seen + 1
            if seen == e.n then break end
        end
    end
    return false
end

-- A value as it is, or nil when the client marks it secret (chat and unit names in a boss fight
-- on the Forever client). A secret value is never compared, only skipped.
function ns.Plain(v)
    local secret = _G.issecretvalue
    if type(secret) == "function" and secret(v) then return nil end
    return v
end

-- The group's loot method as C_PartyInfo.GetLootMethod tells it: true, method, partyID, raidID (a
-- secret value counts as unknown: nil); false when the client cannot tell.
function ns.LootMethod()
    local info = _G.C_PartyInfo
    if type(info) ~= "table" or type(info.GetLootMethod) ~= "function" then return false end
    local ok, method, partyID, raidID = pcall(info.GetLootMethod)
    if not ok then return false end
    return true, ns.Plain(method), ns.Plain(partyID), ns.Plain(raidID)
end

-- Whether this client is in a raid of its own (not an instance group).
function ns.HomeRaid()
    if _G.LE_PARTY_CATEGORY_HOME then return IsInRaid(LE_PARTY_CATEGORY_HOME) and true or false end
    return IsInRaid() and true or false
end

function ns.InGuild()
    return type(_G.IsInGuild) == "function" and IsInGuild() and true or false
end

-- Whether this client is in a battleground or an arena instance.
function ns.InPvPInstance()
    local _, kind = GetInstanceInfo()
    kind = ns.Plain(kind)
    return kind == "pvp" or kind == "arena"
end

-- Whether the client says a battlefield is active (C_PvP.IsActiveBattlefield).
function ns.InBattlefield()
    local pvp = _G.C_PvP
    if type(pvp) ~= "table" or type(pvp.IsActiveBattlefield) ~= "function" then return false end
    local ok, on = pcall(pvp.IsActiveBattlefield)
    return ok and ns.Plain(on) == true
end

-- The own faction as the data writes it ("A", "H"), nil when the client tells none.
function ns.OwnFaction()
    local f = UnitFactionGroup and ns.Plain((UnitFactionGroup("player"))) or nil
    return f == "Alliance" and "A" or f == "Horde" and "H" or nil
end

-- The realm's clock in epoch seconds (the same on every client of the raid), else the own clock:
-- times that other clients or the site compare (costs, corrections, prio edits).
function ns.ServerTime()
    local t = type(GetServerTime) == "function" and tonumber(ns.Plain(GetServerTime())) or nil
    return math.floor(t or time())
end

-- A text for a search: lower case, the German capitals folded too (lower() leaves the bytes of
-- Ä, Ö and Ü as they are). nil and other values give "".
local FOLD = { ["Ä"] = "ä", ["Ö"] = "ö", ["Ü"] = "ü" } -- l10n-ok: case folding, not text
function ns.Fold(s)
    if type(s) ~= "string" then return "" end
    return (s:gsub("\195[\132\150\156]", FOLD):lower())
end

function ns.ExportName(name)
    return (tostring(name or "?"):gsub(" ", "_"))
end

-- text in the colour of class (a class token); text as it is for an unknown class or none.
function ns.ClassColored(text, class)
    local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    return c and c.colorStr and ("|c%s%s|r"):format(c.colorStr, text) or text
end

-- /amisia namen: how Amisia reads names on this client, to check Forever's surnames.
ns.RegisterSlash("namen", { en = "names", desc = L["zeigt, wie Amisia Namen liest"], run = function()
    local n, second = UnitName("player")
    ns.msg(L["Du: UnitName = \"%s\", \"%s\" -> %s"]:format(tostring(n), tostring(second), tostring(ns.UnitFullName("player"))))
    for i = 1, math.min(GetNumGroupMembers() or 0, 5) do
        local rn = GetRaidRosterInfo(i)
        ns.msg(L["Gruppe %d: Raidliste = \"%s\" -> %s"]:format(i, tostring(rn), tostring(ns.FullName(rn))))
    end
end })
