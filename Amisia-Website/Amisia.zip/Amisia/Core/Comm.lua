-- Amisia comm: the addon message layer between Amisia clients. Two prefixes (control and data), an
-- envelope with the protocol number, packing of tables through the client's own encoding functions,
-- chunking and reassembly, a send queue with its own throttle per prefix that waits in the chat
-- lockdown and reads every send result, no sending in battlegrounds, receive limits per sender.
local ADDON, ns = ...
ns.Load(function()
local L = ns.L

ns.SYNC_PROTO = 1        -- protocol of this client
ns.SYNC_MIN_PROTO = 1    -- the oldest protocol this client still reads

local PREFIX_CTRL, PREFIX_DATA = "Amisia", "AmisiaD"
local MAX_TEXT = 250     -- bytes of one message (the client takes 255)
ns.COMM_MAX_TEXT = MAX_TEXT
local CHUNK = 200        -- Base64 characters per data part
local MAX_PARTS, MAX_PARTS_OP, MAX_PARTS_DK = 60, 8, 20
local MAX_UNPACKED = 65536

local MSG_BURST, MSG_REFILL = 10, 1        -- messages per prefix at once, then per second
local BYTE_BURST, BYTE_REFILL = 1000, 500  -- bytes of both prefixes at once, then per second
local CTRL_RESERVE = 260                   -- bytes a data part leaves for a waiting control message
local MAX_QUEUE = 200
local TICK = 0.25
local LOCK_POLL = 2
local DEFAULT_TTL = 60
local LOW_TTL = 120        -- entries of lowest priority (opts.low) fall after this unless told otherwise
local MAX_TRIES = 5

local SET_TTL = 30          -- seconds a part set waits for its next part
local SETS_PER_SENDER = 3
local DONE_KEEP = 60        -- seconds a finished set is remembered (late doubles start nothing)
local RECV_WINDOW, RECV_MAX = 10, 40
local BYTE_WINDOW, BYTE_MAX = 60, 20480
local IGNORE_FOR = 60
local OPEN_PARTS, OPEN_BYTES = 90, 18000   -- parts and Base64 bytes of the open sets of one sender
local OUTSIDER_FOR = 60     -- seconds the data parts of a sender outside the guild are dropped unread
-- seconds between two handled messages per sender; a new keeper's gathering (RQ with "G") apart, and a guild
-- queue state with a battleground that popped, was joined or declined (QW with a P, J or L entry: QWP, F-227) apart
local KIND_GAP = { VQ = 300, RQ = 20, RQG = 20, UQ = 5, NW = 10, DV = 60, CV = 60, LV = 8, LQ = 15, SV = 8, KV = 8, KQ = 15, PV = 60, PQ = 60, GQ = 30, MQ = 30, WS = 1, AQ = 30, XQ = 10, XA = 10, IQ = 300, RO = 30, RX = 10, QR = 10, YQ = 10, YI = 10, ZQ = 30, NV = 8, AC = 300, EA = 10, EQ = 300, TQ = 30, QW = 10, QWP = 1 }
-- the same per first field: a drop question per week, a drop request per (first) bucket; a source
-- question per kind, a source request per kind and bucket; a roll window answer per round; a raid
-- sign-up per night; the raid IDs of a character; a soft-reserve question per list (its import epoch);
-- a feedback answer per report id; the group quest state per dungeon; a raid note question per note
local KEYED_GAP = { DQ = 60, DR = 60, CQ = 60, CR = 60, WA = 2, AN = 10, IV = 60, SQ = 5, FA = 5, QS = 3, NQ = 5, EJ = 5, ZA = 5 }
local KEYED_MAX = 64        -- keyed gaps remembered per sender before the old ones are cleared

-- PARTY only in an own home party (D-97: the routes and points shared with a group of five; D-110: the
-- group's quest state of a dungeon; D-138: the group note)
local CHANNELS = { RAID = true, PARTY = true, GUILD = true, WHISPER = true }
local BLOB_ARTS = { SP = true, SO = true, OP = true, DK = true, CK = true, LC = true, PK = true, KS = true, SR = true, RN = true }
-- parts a blob of an art may have (default MAX_PARTS)
local ART_PARTS = { OP = MAX_PARTS_OP, DK = MAX_PARTS_DK, CK = MAX_PARTS_DK, LC = 40, PK = MAX_PARTS_DK, KS = MAX_PARTS_DK, SR = 30, RN = 30 }

local available = false
local stats = { sent = 0, failed = 0, dropped = 0, expired = 0, bad = 0, limited = 0, throttled = 0, received = 0 }

local function now() return GetTime() end

local report = ns.ReportError

---------------------------------------------------------------------------
-- Debug lines (sync.debug): grey, at most 20 a minute
---------------------------------------------------------------------------
local debugTimes = {}
local function debugLine(text, always)
    if not ns.Get("sync.debug") then return end
    local t = now()
    if not always then
        local keep = {}
        for _, at in ipairs(debugTimes) do
            if t - at < 60 then keep[#keep + 1] = at end
        end
        debugTimes = keep
        if #keep >= 20 then return end
        keep[#keep + 1] = t
    end
    -- what others sent shows as text: a bar of theirs could draw a texture or a clickable link
    DEFAULT_CHAT_FRAME:AddMessage("|cff999999Amisia Sync: " .. tostring(text):gsub("|", "||") .. "|r")
end

local noted = {}   -- reason -> time of the last debug note, once a minute
local function noteOnce(reason, text)
    local t = now()
    if noted[reason] and t - noted[reason] < 60 then return end
    noted[reason] = t
    debugLine(text)
end

-- A message as one debug line: kind and fields with spaces, a data part without its payload.
local function describe(kind, fields)
    if kind == "BL" then
        return ("BL %s %s %s %s/%s"):format(fields[1] or "?", fields[2] or "?", fields[3] or "?", fields[4] or "?", fields[5] or "?")
    end
    return kind .. (fields[1] and (" " .. table.concat(fields, " ")) or "")
end

---------------------------------------------------------------------------
-- Prefixes
---------------------------------------------------------------------------
-- What the client answered to each registration (the self-test shows it): the result, or the
-- error text of a raising call.
local prefixResults = {}

do
    local info = _G.C_ChatInfo
    local register = type(info) == "table" and info.RegisterAddonMessagePrefix
    if type(register) == "function" and type(info.SendAddonMessage) == "function" then
        available = true
        for _, prefix in ipairs({ PREFIX_CTRL, PREFIX_DATA }) do
            local ok, result = pcall(register, prefix)
            prefixResults[#prefixResults + 1] = { prefix = prefix, ok = ok, result = result }
            -- 0 success, 1 already registered; 2 invalid and 3 too many prefixes switch the layer off
            if not ok or (result ~= 0 and result ~= 1 and result ~= true) then available = false end
        end
        if not available then
            ns.msg(L["Addon-Nachrichten sind nicht verfügbar (Präfix nicht angemeldet). Sync und Versionsprüfung sind aus."])
        end
    end
end

-- Whether the message layer works at all (prefixes registered, the send function there).
function ns.CommAvailable() return available end

-- The prefixes and what their registration returned: { { prefix, ok, result } }; empty when the
-- client has no registration function.
function ns.CommPrefixResults()
    local out = {}
    for i, r in ipairs(prefixResults) do out[i] = { prefix = r.prefix, ok = r.ok, result = r.result } end
    return out
end

-- The layer works and the raid sync is switched on.
function ns.CommReady() return available and ns.Get("sync.enabled") ~= false end

-- Whether the client can pack tables (C_EncodingUtil with the six functions).
function ns.CommPacking()
    local api = _G.C_EncodingUtil
    if type(api) ~= "table" then return false end
    for _, f in ipairs({ "SerializeCBOR", "DeserializeCBOR", "CompressString", "DecompressString", "EncodeBase64", "DecodeBase64" }) do
        if type(api[f]) ~= "function" then return false end
    end
    return true
end

function ns.CommStats()
    local out = {}
    for k, v in pairs(stats) do out[k] = v end
    return out
end

---------------------------------------------------------------------------
-- Packing
---------------------------------------------------------------------------
local function deflate()
    local e = _G.Enum and Enum.CompressionMethod
    return e and e.Deflate or 0
end

-- A table as Base64 text (CBOR, Deflate, Base64), or nil and the reason.
function ns.CommPack(tbl)
    if not ns.CommPacking() then return nil, L["Packen ist auf diesem Client nicht möglich."] end
    if type(tbl) ~= "table" then return nil, L["Keine Daten."] end
    local api = C_EncodingUtil
    local ok, out = pcall(function()
        local raw = api.SerializeCBOR(tbl)
        local packed = type(raw) == "string" and api.CompressString(raw, deflate()) or nil
        return type(packed) == "string" and api.EncodeBase64(packed) or nil
    end)
    if not ok then report(out) return nil, L["Packen fehlgeschlagen."] end
    if type(out) ~= "string" or out == "" then return nil, L["Packen fehlgeschlagen."] end
    return out
end

-- The table of a Base64 text, or nil. Never raises.
function ns.CommUnpack(text)
    if not ns.CommPacking() or type(text) ~= "string" or text == "" then return nil end
    local api = C_EncodingUtil
    local ok, out = pcall(function()
        local packed = api.DecodeBase64(text)
        if type(packed) ~= "string" or packed == "" then return nil end
        local raw = api.DecompressString(packed, deflate())
        if type(raw) ~= "string" or raw == "" or #raw > MAX_UNPACKED then return nil end
        return api.DeserializeCBOR(raw)
    end)
    if not ok or type(out) ~= "table" then return nil end
    return out
end

-- Text cut into pieces of 200 characters.
function ns.CommChunks(text)
    local out = {}
    for i = 1, #text, CHUNK do out[#out + 1] = text:sub(i, i + CHUNK - 1) end
    return out
end

---------------------------------------------------------------------------
-- Field checks of the received kinds
---------------------------------------------------------------------------
local function isKey(v) return type(v) == "string" and v:match("^%d%d%d%d%-%d%d%-%d%d:%d+$") ~= nil end
local function isNum(v, lo, hi)
    local n = type(v) == "string" and v:match("^%d+$") and tonumber(v)
    return n ~= nil and n >= lo and n <= hi
end
local function isHex(v, len) return type(v) == "string" and #v == len and v:match("^%x+$") ~= nil end
local function isFlags(v, set) return v == "-" or (type(v) == "string" and v ~= "" and #v <= #set and not v:find("[^" .. set .. "]")) end

local function itemList(v)
    if type(v) ~= "string" or v == "" then return false end
    local n = 0
    for id in (v .. ","):gmatch("([^,]*),") do
        n = n + 1
        if n > 8 or not isNum(id, 1, 999999) then return false end
    end
    return true
end

local function answerList(v)
    if type(v) ~= "string" or v == "" then return false end
    local n = 0
    for entry in (v .. ","):gmatch("([^,]*),") do
        n = n + 1
        local id, art, gain, pct, slot = entry:match("^([^:]+):([^:]+):([^:]+):([^:]+):([^:]+)$")
        if n > 8 or not id or not isNum(id, 1, 999999) or not (art == "U" or art == "W" or art == "-")
            or not gain:match("^%-?%d+$") or not isNum(pct, 0, 999999) or not slot:match("^[%w_%-]+$") then
            return false
        end
    end
    return true
end

-- A comma list of at most max entries, each passing ok; "-" (empty) when allowEmpty.
local function commaList(v, max, ok, allowEmpty)
    if v == "-" then return allowEmpty == true end
    if type(v) ~= "string" or v == "" then return false end
    local n = 0
    for entry in (v .. ","):gmatch("([^,]*),") do
        n = n + 1
        if n > max or not ok(entry) then return false end
    end
    return true
end

-- The drop exchange (DropSync.lua): week "w:hhhh:n", bucket "day:inst:hhhh:n", a known kill as its
-- id (8 hex) and the digest of its items (4 hex).
local function weekEntry(e)
    local w, _, n = e:match("^(%d):(%x%x%x%x):(%d+)$")
    return w ~= nil and isNum(w, 0, 3) and isNum(n, 0, 999999)
end
local function bucketEntry(e)
    local day, inst, _, n = e:match("^(%d+):(%d+):(%x%x%x%x):(%d+)$")
    return day ~= nil and isNum(day, 0, 99999) and isNum(inst, 1, 99999) and isNum(n, 1, 999999)
end
local function killEntry(e) return isHex(e, 12) end
-- DR: pairs of a bucket key and its known kills (or "*"), 12 buckets at most
local function drPairs(f)
    if #f < 2 or #f % 2 ~= 0 or #f > 24 then return false end
    for i = 1, #f, 2 do
        if not isKey(f[i]) or not (f[i + 1] == "*" or commaList(f[i + 1], 16, killEntry)) then return false end
    end
    return true
end

-- The source exchange (CollectSync.lua): a kind "q:hhhh:n", a bucket "bb:hhhh:n" (bb two hex,
-- 00-3f), a known record as 4 hex.
local COLLECT_KINDS = { q = true, s = true, w = true }
local function collectKindEntry(e)
    local k, n = e:match("^([qsw]):%x%x%x%x:(%d+)$")
    return k ~= nil and isNum(n, 0, 999999)
end
local function collectBucket(b)
    return type(b) == "string" and b:match("^%x%x$") ~= nil and tonumber(b, 16) <= 63
end
local function collectBucketEntry(e)
    local b, n = e:match("^(%x%x):%x%x%x%x:(%d+)$")
    return b ~= nil and collectBucket(b) and isNum(n, 1, 999999)
end
local function hex4(e) return isHex(e, 4) end
-- a guild bank need "itemID:min:target"
local function needEntry(e)
    local id, min, target = e:match("^(%d+):(%d+):(%d+)$")
    return id ~= nil and isNum(id, 1, 9999999) and isNum(min, 0, 99999) and isNum(target, 0, 99999)
end

-- a loot rule "id:kind:value:target" (LootRules.lua): q with 2 or 3 and m with "-" to bank or de, i
-- with item ids joined by "+" (at most 50) to bank or de, p with one item id to a player's name ("_"
-- for the space, no digits)
local function ruleTarget(v) return v == "bank" or v == "de" end
local function ruleName(v)
    return type(v) == "string" and v ~= "" and #v <= 48 and not v:find("[%s%c,:|+%d]") and not ruleTarget(v:lower())
end
local function ruleEntry(e)
    local _, k, value, to = e:match("^(%x%x%x%x):([qmip]):([^:]+):([^:]+)$")
    if not k then return false end
    if k == "q" then return (value == "2" or value == "3") and ruleTarget(to) end
    if k == "m" then return value == "-" and ruleTarget(to) end
    if k == "p" then return isNum(value, 1, 9999999) and ruleName(to) end
    local n = 0
    for x in (value .. "+"):gmatch("([^+]*)%+") do
        n = n + 1
        if n > 50 or not isNum(x, 1, 9999999) then return false end
    end
    return ruleTarget(to)
end

-- the roll window (RollWindow.lua): a character's name in a field (no digits, commas, colons or bars)
local function rollName(v)
    return type(v) == "string" and v ~= "" and #v <= 48 and not v:find("[%c,:|%d]")
end
local ROUND_ART = { R = true, B = true, N = true }
local ANSWER = { P = true, N = true, G = true, B = true }
-- the result of a round: "value:kind" (value may be empty: need or greed), "T" a tie, "-" none
local function rollResult(v)
    if v == "-" or v == "T" then return true end
    local value, kind = (v or ""):match("^(%d*):(%u+)$")
    return kind ~= nil and #value <= 7 and #kind <= 5
end
local function optNum(v) return v == nil or v == "-" or isNum(v, 0, 9999999) end

-- the raid sign-up (Raid/Signup.lua): a night, a role, a class token
-- the routes (Gear/Routes.lua): a route's name or a point's label (no bar, no control character)
local function routeText(v, max) return type(v) == "string" and v ~= "" and #v <= max and not v:find("[%c|]") end

local function isNight(v) return type(v) == "string" and v:match("^%d%d%d%d%-%d%d%-%d%d$") ~= nil end
local SIGN_STATUS = { A = true, V = true, X = true }
local SIGN_ROLE = { T = true, H = true, M = true, R = true, ["-"] = true }
local CLASS_TOKEN = { WARRIOR = true, PALADIN = true, HUNTER = true, ROGUE = true, PRIEST = true, SHAMAN = true, MAGE = true,
                      WARLOCK = true, DRUID = true, ["-"] = true }

local NO_REASONS = { CONFLICT = true, GONE = true, DENIED = true, NORAID = true, BAD = true }

-- feedback (Core/Feedback.lua): a report id "<epoch>-<n>", the client "f"/"t"/"e"
local function feedbackId(v) return type(v) == "string" and #v <= 20 and v:match("^%d+%-%d+$") ~= nil end
local FEEDBACK_GAME = { f = true, t = true, e = true }
local function noBar(v, max) return type(v) == "string" and v ~= "" and #v <= max and not v:find("|", 1, true) end

-- the raid check (Raid/RaidCheck.lua): a worn slot 1-19; the consumables "F" (flask), "E<n>" (n
-- elixirs, 1-9), "W" (well fed) in this order, or "-"
local function slotEntry(e) return isNum(e, 1, 19) end
local function consumables(v)
    if v == "-" then return true end
    if type(v) ~= "string" or v == "" then return false end
    local fl, e, n = v:match("^(F?)(E?)(%d?)W?$")
    if not fl or (e == "") ~= (n == "") or n == "0" then return false end
    return true
end
-- raid IDs (Raid/RaidIDs.lua): a character's name (no digits, commas, colons or bars), an ID
-- "instance:difficulty:reset epoch:killed/total"
local function charName(v) return type(v) == "string" and v ~= "" and #v <= 48 and not v:find("[%c,:|%d]") end
local function lockEntry(e)
    local m, d, r, k, t = e:match("^(%d+):(%d+):(%d+):(%d+)/(%d+)$")
    return m ~= nil and isNum(m, 1, 999999) and isNum(d, 0, 255) and isNum(r, 1, 4294967295) and isNum(k, 0, 99) and isNum(t, 0, 99)
        and (tonumber(t) == 0 or tonumber(k) <= tonumber(t))
end

-- kind -> fields check; more fields than these are allowed (a later client of the same protocol)
-- A dungeon key of the quest data (letters, digits, "_", at most 24).
local function dungeonKey(v) return type(v) == "string" and #v >= 1 and #v <= 24 and v:match("^[%w_]+$") ~= nil end
-- The quest states of a QS: "-", or 1-100 entries of a base-36 step (1-4 characters, at least 1) and one
-- of the state characters . < + ! * /, the ids at most 999999.
local function questStates(v)
    if v == "-" then return true end
    if type(v) ~= "string" or v == "" or #v > 240 then return false end
    local n, at, id = 0, 1, 0
    while at <= #v do
        local s, e, d = v:find("^([0-9a-z]+)[%.%+!%*/<]", at)
        if not s or #d > 4 then return false end
        local step = tonumber(d, 36)
        if not step or step < 1 then return false end
        id, n = id + step, n + 1
        if n > 100 or id > 999999 then return false end
        at = e + 1
    end
    return true
end

-- the guild calls (F-211): the art, a role, a title or note (no bar, no control character), "T/H/S"
-- counts of 0-40 each
local CALL_ART = { D = true, Q = true, H = true, S = true }
local CALL_ROLE = { T = true, H = true, S = true }
local function callText(v, max) return type(v) == "string" and v ~= "" and #v <= max and not v:find("[%c|]") end
local function roleTriple(v)
    local t, h, s = (type(v) == "string" and v or ""):match("^(%d%d?)/(%d%d?)/(%d%d?)$")
    t, h, s = tonumber(t), tonumber(h), tonumber(s)
    if not t or t > 40 or h > 40 or s > 40 then return nil end
    return t, h, s
end

local VALID = {
    HI = function(f) return #f >= 4 and f[1]:match("^%d+%.%d+%.%d+$") and isNum(f[2], 0, 9) and isFlags(f[3], "OL")
                         and (f[4] == "-" or isKey(f[4])) end,
    VQ = function(f) return #f >= 1 and isHex(f[1], 4) end,
    ST = function(f) return #f >= 4 and isKey(f[1]) and isNum(f[2], 0, 999999) and isHex(f[3], 16) and isFlags(f[4], "KM") end,
    RQ = function(f) return #f >= 3 and isKey(f[1]) and isNum(f[2], 0, 999999) and (f[3] == "P" or f[3] == "O" or f[3] == "PO") end,
    BL = function(f)
        if #f < 6 or not BLOB_ARTS[f[1]] or not isKey(f[2]) or not isNum(f[3], 0, 999999) then return false end
        local i, n = tonumber(f[4]), tonumber(f[5])
        if not isNum(f[4], 1, MAX_PARTS) or not isNum(f[5], 1, MAX_PARTS) or i > n then return false end
        if ART_PARTS[f[1]] and n > ART_PARTS[f[1]] then return false end
        return #f[6] > 0 and #f[6] <= CHUNK and f[6]:match("^[A-Za-z0-9+/=]+$") ~= nil
    end,
    OK = function(f) return #f >= 3 and isKey(f[1]) and isHex(f[2], 12) and isNum(f[3], 0, 999999) end,
    NO = function(f) return #f >= 4 and isKey(f[1]) and isHex(f[2], 12) and NO_REASONS[f[3]] and isNum(f[4], 0, 999999) end,
    NW = function(f) return #f >= 4 and isKey(f[1]) and isNum(f[2], 0, 999999) and isHex(f[3], 16) and isNum(f[4], 0, 999999) end,
    UQ = function(f) return #f >= 2 and isHex(f[1], 4) and itemList(f[2]) end,
    UA = function(f) return #f >= 2 and isHex(f[1], 4) and answerList(f[2]) end,
    -- drop exchange: DV <drop proto> <records> <newest day> <weeks>; DQ <week>;
    -- DI <week> <part> <parts> <buckets>|-; DR (<bucket key> <known kills>|*)...; DW <seconds>
    -- (busy: ask again later)
    DV = function(f) return #f >= 4 and isNum(f[1], 0, 9) and isNum(f[2], 0, 999999) and isNum(f[3], 0, 99999)
                         and commaList(f[4], 4, weekEntry) end,
    DQ = function(f) return #f >= 1 and isNum(f[1], 0, 3) end,
    DI = function(f)
        if #f < 4 or not isNum(f[1], 0, 3) or not isNum(f[2], 1, 20) or not isNum(f[3], 1, 20) then return false end
        return tonumber(f[2]) <= tonumber(f[3]) and commaList(f[4], 12, bucketEntry, true)
    end,
    DR = drPairs,
    DW = function(f) return #f >= 1 and isNum(f[1], 1, 3600) end,
    -- source exchange: CV <collect proto> <records> <kinds>; CQ <kind>; CI <kind> <part> <parts>
    -- <buckets>|-; CR (<kind><bucket> <known records>|*)... (12 buckets of one kind at most); CW <seconds> (busy)
    CV = function(f) return #f >= 3 and isNum(f[1], 0, 9) and isNum(f[2], 0, 999999) and commaList(f[3], 3, collectKindEntry) end,
    CQ = function(f) return #f >= 1 and COLLECT_KINDS[f[1]] == true end,
    CI = function(f)
        if #f < 4 or not COLLECT_KINDS[f[1]] or not isNum(f[2], 1, 8) or not isNum(f[3], 1, 8) then return false end
        return tonumber(f[2]) <= tonumber(f[3]) and commaList(f[4], 20, collectBucketEntry, true)
    end,
    CR = function(f)
        if #f < 2 or #f % 2 ~= 0 or #f > 24 then return false end
        for i = 1, #f, 2 do
            if #f[i] ~= 3 or f[i]:sub(1, 1) ~= f[1]:sub(1, 1) or not COLLECT_KINDS[f[i]:sub(1, 1)] or not collectBucket(f[i]:sub(2))
                or not (f[i + 1] == "*" or commaList(f[i + 1], 45, hex4)) then
                return false
            end
        end
        return true
    end,
    CW = function(f) return #f >= 1 and isNum(f[1], 1, 3600) end,
    -- loot council (LootPrio.lua): LV <raid key> <hash> <items> from the keeper; LQ <raid key> <own hash>
    LV = function(f) return #f >= 3 and isKey(f[1]) and isHex(f[2], 16) and isNum(f[3], 0, 999) end,
    LQ = function(f) return #f >= 2 and isKey(f[1]) and isHex(f[2], 16) end,
    -- soft-reserves (SoftResShare.lua): SV <import epoch> <hash|-> <reservations> from an officer with
    -- his own list ("-": cleared); SQ <import epoch> <own hash|-> asks him for it
    SV = function(f) return #f >= 3 and isNum(f[1], 1, 4e9) and (f[2] == "-" or isHex(f[2], 16)) and isNum(f[3], 0, 9999) end,
    SQ = function(f) return #f >= 2 and isNum(f[1], 1, 4e9) and (f[2] == "-" or isHex(f[2], 16)) end,
    -- the raid note (F-196): NV <note id> <hash> <lines>; NQ <note id> <own hash>|-
    NV = function(f) return #f >= 3 and isNum(f[1], 1, 4e9) and isHex(f[2], 16) and isNum(f[3], 1, 120) end,
    NQ = function(f) return #f >= 2 and isNum(f[1], 1, 4e9) and (f[2] == "-" or isHex(f[2], 16)) end,
    -- the group note (F-213, D-138; PARTY only): TN <note id> <part> <parts> <hash> <piece> (the text percent-escaped:
    -- %, |, line end and tab as %XX; a piece of 1-200 bytes); TQ <note id or -> <own hash or ->
    TN = function(f)
        if #f < 5 or not isNum(f[1], 1, 4e9) or not isNum(f[2], 1, 6) or not isNum(f[3], 1, 6) or tonumber(f[2]) > tonumber(f[3]) then return false end
        if not isHex(f[4], 16) or type(f[5]) ~= "string" or #f[5] < 1 or #f[5] > 200 or f[5]:find("[%c|]") then return false end
        -- every % starts a whole escape
        return not f[5]:gsub("%%%x%x", ""):find("%", 1, true)
    end,
    TQ = function(f) return #f >= 2 and (f[1] == "-" or isNum(f[1], 1, 4e9)) and (f[2] == "-" or isHex(f[2], 16)) end,
    -- DKP/EPGP (Raid/PointsSync.lua): KV <raid key> <hash> <players> from the keeper; KQ <raid key> <own hash>;
    -- KC <raid key> <award id> <D|G> <amount> <epoch>: an officer's cost of an award
    KV = function(f) return #f >= 3 and isKey(f[1]) and isHex(f[2], 16) and isNum(f[3], 0, 999) end,
    KQ = function(f) return #f >= 2 and isKey(f[1]) and isHex(f[2], 16) end,
    KC = function(f) return #f >= 5 and isKey(f[1]) and isHex(f[2], 12) and (f[3] == "D" or f[3] == "G") and isNum(f[4], 0, 999999)
                         and isNum(f[5], 0, 4294967295) end,
    -- recipe exchange (Gear/Crafters.lua): PV <crafter proto> <crafters> <digest>; PQ <crafter proto>
    -- <format B|L> <request number>; PW <seconds> (busy)
    PV = function(f) return #f >= 3 and isNum(f[1], 0, 9) and isNum(f[2], 0, 99) and isHex(f[3], 8) end,
    PQ = function(f) return #f >= 3 and isNum(f[1], 0, 9) and (f[2] == "B" or f[2] == "L") and isNum(f[3], 1, 999999) end,
    PW = function(f) return #f >= 1 and isNum(f[1], 1, 3600) end,
    -- guild bank needs (BankNeeds.lua): GN <rev> <part> <parts> <set by> <id:min:target,...|->;
    -- GQ <rev> (who has a newer list); GP <itemID> <count> <epoch> (a pledge, 0 takes it back)
    GN = function(f)
        if #f < 5 or not isNum(f[1], 0, 4294967295) or not isNum(f[2], 1, 5) or not isNum(f[3], 1, 5) then return false end
        if tonumber(f[2]) > tonumber(f[3]) or f[4] == "" or #f[4] > 60 or f[4]:find("[%s%c,:|]") then return false end
        return commaList(f[5], 8, needEntry, true)
    end,
    GQ = function(f) return #f >= 1 and isNum(f[1], 0, 4294967295) end,
    GP = function(f) return #f >= 3 and isNum(f[1], 1, 9999999) and isNum(f[2], 0, 99999) and isNum(f[3], 0, 4294967295) end,
    -- loot rules (LootRules.lua): MR <rev> <part> <parts> <set by> <id:kind:value:target,...|->, an
    -- officer's set in at most 4 parts; MQ <rev> (who has a newer set)
    MR = function(f)
        if #f < 5 or not isNum(f[1], 0, 4294967295) or not isNum(f[2], 1, 4) or not isNum(f[3], 1, 4) then return false end
        if tonumber(f[2]) > tonumber(f[3]) or f[4] == "" or #f[4] > 60 or f[4]:find("[%s%c,:|]") then return false end
        return commaList(f[5], 6, ruleEntry, true)
    end,
    MQ = function(f) return #f >= 1 and isNum(f[1], 0, 4294967295) end,
    -- the roll window (RollWindow.lua): WS <round id> <item string> <seconds> <R|B|N> <flags T/S|->
    -- <reservers|-> [<min bid or price|->] [<price offspec|->] [<tie names|->]; WE <round id> <D|X>
    -- <winner|-> [<result>]; WA <round id> <P|N|G|B> [<bid>]
    WS = function(f)
        if #f < 6 or not isHex(f[1], 4) or type(f[2]) ~= "string" or #f[2] > 120 or not f[2]:match("^item:%d+[%-%d:]*$") then return false end
        if not isNum(f[3], 5, 120) or not ROUND_ART[f[4]] or not isFlags(f[5], "TS") then return false end
        if not commaList(f[6], 8, rollName, true) or not optNum(f[7]) or not optNum(f[8]) then return false end
        return f[9] == nil or commaList(f[9], 10, rollName, true)
    end,
    WE = function(f) return #f >= 3 and isHex(f[1], 4) and (f[2] == "D" or f[2] == "X") and (f[3] == "-" or rollName(f[3]))
                         and (f[4] == nil or rollResult(f[4])) end,
    WA = function(f) return #f >= 2 and isHex(f[1], 4) and ANSWER[f[2]] == true and (f[2] ~= "B" or isNum(f[3], 1, 9999999)) end,
    -- the raid sign-up (Raid/Signup.lua): AN <night> <A|V|X> <T|H|M|R|-> <class|-> <epoch> <event id|->
    -- [<note|->] (the note is cleaned and cut to 40 by the receiver); AQ <O|-> <rev> (an officer asks)
    AN = function(f)
        return #f >= 6 and isNight(f[1]) and SIGN_STATUS[f[2]] == true and SIGN_ROLE[f[3]] == true and CLASS_TOKEN[f[4]] == true
            and isNum(f[5], 1, 4294967295) and (f[6] == "-" or (#f[6] <= 20 and isNum(f[6], 0, math.huge)))
            and (f[7] == nil or #f[7] <= 120)
    end,
    AQ = function(f) return #f >= 2 and (f[1] == "O" or f[1] == "-") and isNum(f[2], 0, 4294967295) end,
    -- the raid check (Raid/RaidCheck.lua): XQ <question id>; XA <question id|-> <lowest durability|->
    -- <items under the threshold> <item level x10|-> <empty slots|-> <unenchanted slots|-> <free
    -- points|-> <consumables|->; a value out of its bounds drops the whole message
    XQ = function(f) return #f >= 1 and isHex(f[1], 4) end,
    XA = function(f)
        return #f >= 8 and (f[1] == "-" or isHex(f[1], 4)) and (f[2] == "-" or isNum(f[2], 0, 100)) and isNum(f[3], 0, 19)
            and (f[4] == "-" or isNum(f[4], 0, 9999)) and commaList(f[5], 19, slotEntry, true) and commaList(f[6], 19, slotEntry, true)
            and (f[7] == "-" or isNum(f[7], 0, 99)) and consumables(f[8])
    end,
    -- raid IDs (Raid/RaidIDs.lua): IV <character> <class|-> <level> <ids|-> (6 at most); IQ - (an officer asks)
    IV = function(f) return #f >= 4 and charName(f[1]) and CLASS_TOKEN[f[2]] == true and isNum(f[3], 1, 99) and commaList(f[4], 6, lockEntry, true) end,
    IQ = function(f) return #f >= 1 and f[1] == "-" end,
    -- feedback (Core/Feedback.lua): FB <id> <part> <parts 2-4>, part 1: <B|W> <version> <f|t|e> <locale>
    -- <class|-> <level> <page|-> <error|->, the others: <text piece> (escaped); FA <id> ("angekommen")
    FB = function(f)
        if #f < 4 or not feedbackId(f[1]) or not isNum(f[2], 1, 4) or not isNum(f[3], 2, 4) or tonumber(f[2]) > tonumber(f[3]) then return false end
        if f[2] == "1" then
            return #f >= 11 and (f[4] == "B" or f[4] == "W") and #f[5] <= 12 and f[5]:match("^%d+%.%d+%.%d+") ~= nil
                and FEEDBACK_GAME[f[6]] == true and f[7]:match("^%a%a%a%a$") ~= nil and CLASS_TOKEN[f[8]] == true and isNum(f[9], 0, 99)
                and (f[10] == "-" or (#f[10] <= 24 and f[10]:match("^[%w_]+$") ~= nil)) and noBar(f[11], 160)
        end
        return noBar(f[4], 220)
    end,
    FA = function(f) return #f >= 1 and feedbackId(f[1]) end,
    -- the routes (Gear/Routes.lua): RO <id> <parts 1-24> <bytes 1-6000> <map id> <stops 0-30> <lines 0-20>
    -- <name> heads a route, RD <id> <part> <piece> carries it; RX <map id> <x 0-10000> <y 0-10000> <label|->
    -- a single point
    RO = function(f)
        return #f >= 7 and isHex(f[1], 4) and isNum(f[2], 1, 24) and isNum(f[3], 1, 6000) and isNum(f[4], 1, 999999)
            and isNum(f[5], 0, 30) and isNum(f[6], 0, 20) and routeText(f[7], 30)
    end,
    RD = function(f) return #f >= 3 and isHex(f[1], 4) and isNum(f[2], 1, 24) and routeText(f[3], 230) end,
    RX = function(f)
        return #f >= 4 and isNum(f[1], 1, 999999) and isNum(f[2], 0, 10000) and isNum(f[3], 0, 10000) and routeText(f[4], 24)
    end,
    -- the group quest state (Gear/GroupQuests.lua, D-110): QS <dungeon key> <version> <flags T|-> <list>
    -- (base-36 id steps, each followed by its state character, or "-"); QR <dungeon keys, comma, max 4>
    -- <version>
    QS = function(f)
        return #f >= 4 and dungeonKey(f[1]) and isNum(f[2], 1, 9) and isFlags(f[3], "T") and questStates(f[4])
    end,
    QR = function(f) return #f >= 2 and commaList(f[1], 4, dungeonKey) and isNum(f[2], 1, 9) end,
    -- the layer change in the guild (Gear/LayerChange.lua, D-117): YQ <zone map> <zoneUID> <request id> asks the
    -- guild; YA <request id> <zone map> <zoneUID> answers from another layer; YI <request id> <zone map>
    -- <the host's zoneUID> asks that member for the invite
    YQ = function(f) return #f >= 3 and isNum(f[1], 1, 999999) and isNum(f[2], 1, 4294967295) and isHex(f[3], 4) end,
    YA = function(f) return #f >= 3 and isHex(f[1], 4) and isNum(f[2], 1, 999999) and isNum(f[3], 1, 4294967295) end,
    YI = function(f) return #f >= 3 and isHex(f[1], 4) and isNum(f[2], 1, 999999) and isNum(f[3], 1, 4294967295) end,
    -- the zone (F-216, D-141): ZQ <request id> <zone map> <zoneUID|0> whispered to a player of the zone outside the
    -- guild; ZA <request id> <zone map> <zoneUID|0> <1 helps|0> the answer of every Amisia user there
    ZQ = function(f) return #f >= 3 and isHex(f[1], 4) and isNum(f[2], 1, 999999) and (f[3] == "0" or isNum(f[3], 1, 4294967295)) end,
    ZA = function(f)
        return #f >= 4 and isHex(f[1], 4) and isNum(f[2], 1, 999999) and (f[3] == "0" or isNum(f[3], 1, 4294967295))
            and (f[4] == "0" or f[4] == "1")
    end,
    -- the guild characters (Core/GuildChars.lua, F-210, D-135): AC <main> <name:itemlevel|name:->... (1 to 10
    -- characters); a field out of its bounds drops the whole message
    AC = function(f)
        if #f < 2 or #f > 11 or not charName(f[1]) then return false end
        for i = 2, #f do
            local n, il = f[i]:match("^(.+):([^:]+)$")
            if not n or not charName(n) or not (il == "-" or isNum(il, 1, 999)) then return false end
        end
        return true
    end,
    -- the guild calls (Raid/GuildCalls.lua, F-211, D-136): EA <call id> <rev> <D|Q|H|S> <dungeon key|-> <title>
    -- <level from> <epoch|0> <wanted T/H/S> <signed T/H/S> <in group T/H/S> <O|F> <note|->; EJ <call id> <T|H|S>
    -- <level> or <call id> -; EX <call id>; EQ <nonce>; a field out of its bounds drops the whole message
    EA = function(f)
        if #f < 12 or not isHex(f[1], 4) or not isNum(f[2], 1, 999999) or not CALL_ART[f[3]] then return false end
        if not (f[4] == "-" or dungeonKey(f[4])) or not callText(f[5], 120) or not isNum(f[6], 1, 99) then return false end
        if not (f[7] == "0" or isNum(f[7], 1, 4294967295)) or not (f[11] == "O" or f[11] == "F") then return false end
        if not (f[12] == "-" or callText(f[12], 240)) then return false end
        local t, h, s = roleTriple(f[8])
        if not t or t + h + s < 1 or t + h + s > 40 then return false end
        t, h, s = roleTriple(f[9])
        if not t or t + h + s > 30 then return false end
        return roleTriple(f[10]) ~= nil
    end,
    EJ = function(f) return #f >= 2 and isHex(f[1], 4) and (f[2] == "-" or (CALL_ROLE[f[2]] == true and isNum(f[3], 1, 99))) end,
    EX = function(f) return #f >= 1 and isHex(f[1], 4) end,
    EQ = function(f) return #f >= 1 and isHex(f[1], 4) end,
    -- the guild queue for battlegrounds (Raid/GuildQueue.lua, F-227, D-155): QW 1 <battlegroundID:state:seconds>... with
    -- 0 to 6 entries, each battleground once, state W (waited 0-86400 s), P (popped, 0-600 s left), J (joined) or L
    -- (declined) with 0; no entry: no queue any more. A field out of its bounds drops the whole message
    QW = function(f)
        if #f < 1 or #f > 7 or f[1] ~= "1" then return false end
        local seen = {}
        for i = 2, #f do
            local id, state, sec = f[i]:match("^(%d+):([WPJL]):(%d+)$")
            if not id or not isNum(id, 1, 99999) or seen[tonumber(id)] then return false end
            if not isNum(sec, 0, state == "W" and 86400 or state == "P" and 600 or 0) then return false end
            seen[tonumber(id)] = true
        end
        return true
    end,
}

-- Whether a QW carries a battleground that popped, was joined or declined (its own gap QWP: it goes at once).
local function queueNews(f)
    for i = 2, #f do
        if f[i]:find(":[PJL]:") then return true end
    end
    return false
end

local function prefixOf(kind) return kind == "BL" and PREFIX_DATA or PREFIX_CTRL end

---------------------------------------------------------------------------
-- Who may be talked to
---------------------------------------------------------------------------
-- The own echo: exactly the own full name, also with the own realm ending. Never a first name
-- alone (another character with that first name would be deaf to this client).
local function isSelf(sender)
    local me = ns.UnitFullName("player")
    local name = ns.FullName(sender)
    if not me or not name then return false end
    if name:lower() == me:lower() then return true end
    local base = ns.StripOwnRealm(name)
    return base ~= nil and base:lower() == me:lower()
end

-- A whisper target must be a name of the group or the guild (as the client gives it, a realm
-- ending allowed).
local function knownTarget(target)
    return ns.TrustName(target) ~= nil
end

local homeRaid, inGuild = ns.HomeRaid, ns.InGuild

-- Whispers to players who just went offline (2.94.1): the time of the last whisper to a name and the time
-- the server said the name is offline (its "... ist jetzt offline." or "kein Spieler ... online" line).
local OFFLINE_KEEP, GONE_FOR = 60, 120
local whisperedAt, goneAt = {}, {}
local function nameKey(name)
    name = ns.Plain(name)
    if type(name) ~= "string" or name == "" then return nil end
    -- only the own realm's ending goes: a Forever surname may hold a dash ("Anna Mond-Licht")
    return (ns.StripOwnRealm(name) or name):lower()
end
local function gone(target)
    local k = nameKey(target)
    local at = k and goneAt[k]
    if at and GetTime() - at < GONE_FOR then return true end
    if at then goneAt[k] = nil end
    return false
end

-- Whether a channel can be used right now; nil and the reason otherwise. anyone: a whisper to a name
-- outside group and guild (only the feedback to and from the author, D-61).
local function channelOk(chan, target, anyone)
    if not CHANNELS[chan] then return nil, L["Dieser Kanal wird nicht benutzt."] end
    if chan == "RAID" and not homeRaid() then return nil, L["Keine eigene Raidgruppe."] end
    if chan == "PARTY" and not ns.HomeGroup() then return nil, L["Keine eigene Gruppe."] end
    if chan == "GUILD" and not inGuild() then return nil, L["Keine Gilde."] end
    if chan == "WHISPER" then
        if type(target) ~= "string" or target == "" then return nil, L["Kein Empfänger."] end
        if not anyone and not knownTarget(target) then return nil, L["Der Empfänger ist weder in der Gruppe noch in der Gilde."] end
        if gone(target) then return nil, L["Der Empfänger ist gerade offline gegangen."] end
    end
    return true
end

-- Battlegrounds and arenas: nothing is sent.
local function inPvP()
    local _, kind = GetInstanceInfo()
    if kind == "pvp" or kind == "arena" then return true end
    local pvp = _G.C_PvP
    if type(pvp) == "table" and type(pvp.IsActiveBattlefield) == "function" then
        local ok, on = pcall(pvp.IsActiveBattlefield)
        if ok and ns.Plain(on) then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- The lockdown
---------------------------------------------------------------------------
local function restricted()
    return ns.AddOnRestricted(_G.Enum and Enum.AddOnRestrictionType and Enum.AddOnRestrictionType.Chat or 5)
end

local function lockedNow()
    return ns.ChatLocked() or restricted()
end

local held = false        -- the queue waits for the lockdown to end (or after result 11)
local lockCheckedAt = 0

function ns.CommHeld() return held or lockedNow() end

---------------------------------------------------------------------------
-- The send queue
---------------------------------------------------------------------------
local queue = {}          -- { prefix, text, chan, target, key, expires, ready, tries, kind, desc }
local msgTokens = { [PREFIX_CTRL] = MSG_BURST, [PREFIX_DATA] = MSG_BURST }
local byteTokens, refilledAt = BYTE_BURST, nil
local pausedUntil = 0
local ticker

function ns.CommQueueSize() return #queue end

local function refill()
    local t = now()
    if refilledAt then
        local d = t - refilledAt
        for p, v in pairs(msgTokens) do msgTokens[p] = math.min(MSG_BURST, v + d * MSG_REFILL) end
        byteTokens = math.min(BYTE_BURST, byteTokens + d * BYTE_REFILL)
    end
    refilledAt = t
end

local function cost(e) return #e.prefix + #e.text end

local pump

local function startTicker()
    if ticker then return end
    ticker = C_Timer.NewTicker(TICK, ns.Perf.Wrap("Ticker Comm", function() pump(false) end))
end

local function stopTicker()
    if ticker then ticker:Cancel(); ticker = nil end
end

local function removeAt(i)
    table.remove(queue, i)
end

-- One try: true when the queue may go on, false when it has to stop (pause or hold).
local function attempt(i)
    local e = queue[i]
    local ok = channelOk(e.chan, e.target, e.anyone)
    if not ok then
        stats.dropped = stats.dropped + 1
        removeAt(i)
        return true
    end
    local okCall, result = pcall(C_ChatInfo.SendAddonMessage, e.prefix, e.text, e.chan, e.chan == "WHISPER" and e.target or nil)
    if not okCall then result = 9 end
    result = ns.Plain(result)
    if result == true then result = 0 end
    if result == 0 then
        stats.sent = stats.sent + 1
        if e.chan == "WHISPER" then
            local k = nameKey(e.target)
            if k then whisperedAt[k] = GetTime() end
        end
        msgTokens[e.prefix] = msgTokens[e.prefix] - 1
        byteTokens = byteTokens - cost(e)
        removeAt(i)
        if e.sent then
            local okSent, err = pcall(e.sent)
            if not okSent then report(err) end
        end
        debugLine("> " .. e.chan .. (e.chan == "WHISPER" and (" " .. tostring(e.target)) or "") .. " " .. e.desc)
        return true
    elseif result == 3 or result == 8 then
        stats.throttled = stats.throttled + 1
        e.tries = (e.tries or 0) + 1
        if e.tries >= MAX_TRIES then
            stats.dropped = stats.dropped + 1
            removeAt(i)
            noteOnce("throttle", L["Nachricht nach %d gedrosselten Versuchen verworfen."]:format(MAX_TRIES))
            pausedUntil = now() + 2
        else
            pausedUntil = now() + 2 ^ e.tries
        end
        return false
    elseif result == 11 then
        held = true
        lockCheckedAt = now()
        return false
    elseif result == 5 or result == 10 or result == 12 then
        stats.dropped = stats.dropped + 1
        removeAt(i)
        return true
    end
    stats.failed = stats.failed + 1
    removeAt(i)
    noteOnce("error", L["Senden fehlgeschlagen (Ergebnis %s)."]:format(tostring(result)))
    return true
end

-- Whether an entry's own condition (opts.when) lets it go now.
local function free(e)
    if not e.when then return true end
    local ok, yes = pcall(e.when)
    if not ok then report(yes) return false end
    return yes == true
end

-- The next entry that may go now: the first ready control message, else the first ready data part
-- (which leaves bytes for a waiting control message). Entries of lowest priority (opts.low) only
-- while nothing else waits in the queue. nil when nothing may go.
local function pick()
    local t = now()
    local urgent = false
    for _, e in ipairs(queue) do
        if not e.low then urgent = true break end
    end
    local ctrl, data
    for i, e in ipairs(queue) do
        if e.ready <= t and (not e.low or not urgent) and free(e) then
            if e.prefix == PREFIX_CTRL then
                if not ctrl then ctrl = i end
            elseif not data then
                data = i
            end
            if ctrl and data then break end
        end
    end
    if ctrl then
        local e = queue[ctrl]
        if msgTokens[PREFIX_CTRL] >= 1 and byteTokens >= cost(e) then return ctrl end
    end
    if data then
        local e = queue[data]
        local need = cost(e) + (ctrl and CTRL_RESERVE or 0)
        if msgTokens[PREFIX_DATA] >= 1 and byteTokens >= need then return data end
    end
    return nil
end

-- Sends what the allowances permit. force: check the lockdown now (event), not only every 2 s.
pump = function(force)
    local t = now()
    local keep = {}
    for _, e in ipairs(queue) do
        if e.expires > t then keep[#keep + 1] = e else stats.expired = stats.expired + 1 end
    end
    queue = keep
    if #queue == 0 then
        stopTicker()
        return
    end
    if held and not force and t - lockCheckedAt < LOCK_POLL then return end
    if t < pausedUntil or inPvP() then return end
    lockCheckedAt = t
    held = lockedNow()
    if held then return end
    refill()
    while true do
        local i = pick()
        if not i then break end
        if not attempt(i) then break end
    end
    if #queue == 0 then stopTicker() end
end

-- Puts entries into the queue (the oldest data part, then the oldest control message falls out
-- above 200) and sends what may go.
local function enqueue(entries, key)
    if key then
        local keep, at = {}, nil
        for _, q in ipairs(queue) do
            if q.key == key then
                at = at or #keep + 1
            else
                keep[#keep + 1] = q
            end
        end
        queue = keep
        -- a single message keeps the place of the one it replaces
        if at and #entries == 1 then
            table.insert(queue, at, entries[1])
            entries = {}
        end
    end
    for _, e in ipairs(entries) do queue[#queue + 1] = e end
    while #queue > MAX_QUEUE do
        -- the oldest entry of lowest priority, else the oldest data part, else the oldest message
        local drop
        for i, q in ipairs(queue) do
            if q.low then drop = i break end
        end
        for i, q in ipairs(queue) do
            if drop then break end
            if q.prefix == PREFIX_DATA then drop = i break end
        end
        table.remove(queue, drop or 1)
        stats.dropped = stats.dropped + 1
        noteOnce("full", L["Sendeschlange voll, älteste Nachricht verworfen."])
    end
    startTicker()
    pump(false)
end

local function entry(kind, text, chan, target, opts, desc)
    local t = now()
    local jitter = tonumber(opts.jitter) or 0
    local low = opts.low and true or nil
    return { prefix = prefixOf(kind), text = text, chan = chan, target = target, key = opts.key, kind = kind,
             expires = t + (tonumber(opts.ttl) or (low and LOW_TTL or DEFAULT_TTL)), ready = t + (jitter > 0 and math.random() * jitter or 0),
             tries = 0, desc = desc, low = low, when = type(opts.when) == "function" and opts.when or nil,
             sent = type(opts.sent) == "function" and opts.sent or nil, anyone = opts.anyone and true or nil }
end

local function envelope(kind, fields)
    if type(kind) ~= "string" or not kind:match("^%u%u$") then return nil, L["Unbekannte Nachricht."] end
    if type(fields) ~= "table" then return nil, L["Keine Felder."] end
    local parts = {}
    for i, f in ipairs(fields) do
        f = tostring(f)
        if f:find("[%c|]") then return nil, L["Ungültiges Feld."] end
        parts[i] = f
    end
    local text = ns.SYNC_PROTO .. kind .. (#parts > 0 and ("\t" .. table.concat(parts, "\t")) or "")
    if #text > MAX_TEXT then return nil, L["Nachricht zu lang."] end
    return text, parts
end

-- Sends one control message. kind: "HI", "VQ", ...; fields: list of strings; chan "GUILD", "RAID",
-- "PARTY" (only the routes, D-97, the group quest state, D-110, and the group note, D-138) or "WHISPER" with target. opts.ttl (seconds, default 60), opts.key (a waiting entry with the same
-- key is replaced), opts.jitter (random delay of 0 to n seconds before the first try), opts.low
-- (lowest priority: goes only while nothing else waits, ttl default 120), opts.when (a function; the
-- entry waits while it does not return true), opts.sent (a function called once the message went),
-- opts.anyone (a whisper to a name outside group and guild: only Feedback's FB and FA, D-61, and the layer's ZQ,
-- ZA and YI to players of the zone, D-141).
function ns.CommSend(kind, fields, chan, target, opts)
    if not available then return nil, L["Addon-Nachrichten sind nicht verfügbar."] end
    if kind == "BL" then return nil, L["Daten gehen über CommSendBlob."] end
    local text, parts = envelope(kind, fields)
    if not text then return nil, parts end
    local ok, why = channelOk(chan, target, opts and opts.anyone)
    if not ok then return nil, why end
    enqueue({ entry(kind, text, chan, target, opts or {}, describe(kind, parts)) }, opts and opts.key)
    return true
end

-- Drops the waiting messages sent with opts.key key (a state that may not go any more: the guild queue's QW on
-- entering a battleground, F-227). Returns how many went.
function ns.CommCancel(key)
    local n = 0
    for i = #queue, 1, -1 do
        if queue[i].key == key then
            table.remove(queue, i)
            n = n + 1
        end
    end
    return n
end

-- A third prefix in plain text (D-145, F-220): the wire format of the other layer addon, spoken by
-- Gear/LayerForeign.lua alone. Registered here, so that Comm.lua stays the only file that registers and
-- sends; nothing of Amisia's envelope, queue or limits: the caller keeps its own throttle. Returns whether
-- the client took the prefix and its result (the layer self-test shows it; never listed by name in a report).
local plain = {}
function ns.CommPlainPrefix(prefix)
    if type(prefix) ~= "string" or prefix == "" or #prefix > 16 or prefix == PREFIX_CTRL or prefix == PREFIX_DATA then return false end
    if plain[prefix] ~= nil then return plain[prefix].ok, plain[prefix].result end
    local info = _G.C_ChatInfo
    local register = type(info) == "table" and info.RegisterAddonMessagePrefix
    if type(register) ~= "function" or type(info.SendAddonMessage) ~= "function" then
        plain[prefix] = { ok = false, result = "missing" }
        return false, "missing"
    end
    local okCall, result = pcall(register, prefix)
    result = okCall and ns.Plain(result) or result
    local ok = okCall and (result == 0 or result == 1 or result == true)
    plain[prefix] = { ok = ok, result = result }
    return ok, result
end

-- One whisper of plain text on a prefix of CommPlainPrefix: never in the chat lockdown, a battleground or
-- an arena, never to a name that just went offline, one line without codes. chan "GUILD" (F-221, D-146: the
-- answer to the other layer addon's guild line): to the own guild instead, target unused. Returns the client's
-- result (0 sent, 3 throttled, 4 refused for this chat type, 11 lockdown, ...) or nil and the reason.
function ns.CommSendPlain(prefix, text, target, chan)
    if not available or not (plain[prefix] and plain[prefix].ok) then return nil, "prefix" end
    if type(text) ~= "string" or text == "" or #text > MAX_TEXT or text:find("[%c]") then return nil, "text" end
    local guild = chan == "GUILD"
    if guild then
        if not inGuild() then return nil, "guild" end
        target = nil
    elseif chan ~= nil and chan ~= "WHISPER" then
        return nil, "chan"
    elseif type(target) ~= "string" or target == "" or gone(target) then
        return nil, "target"
    end
    if lockedNow() then return 11 end
    if inPvP() then return nil, "pvp" end
    local okCall, result = pcall(C_ChatInfo.SendAddonMessage, prefix, text, guild and "GUILD" or "WHISPER", target)
    if not okCall then return 9 end
    result = ns.Plain(result)
    if result == true or result == nil then result = 0 end
    if result == 0 and not guild then
        local k = nameKey(target)
        if k then whisperedAt[k] = GetTime() end
    end
    return result
end

-- The blob counter starts from the clock, not at 1: receivers remember a finished set (art:key:seq
-- of a sender) for DONE_KEEP seconds, so after a quick /reload a counter from 1 would repeat a recent
-- id and its first blob would be dropped as a late double. The clock moves ten steps a second, faster
-- than any sender sends blobs.
local seq = math.floor((GetTime() or 0) * 10) % 999999

-- Packs tbl, cuts it into parts and queues them. art "SP", "SO", "OP", "DK", "CK", "LC", "KS", "PK", "SR" or "RN"; key the raid
-- key (DK: the bucket key, the same "date:instance" form; CK: "0000-00-00:<kind * 100 + bucket + 1>"; PK:
-- "0000-00-01:<request number>"; SR: "<list date>:<import epoch>"; RN: "<date>:<note id>"). opts as CommSend. Returns true and the
-- number of parts and their bytes.
function ns.CommSendBlob(art, key, tbl, chan, target, opts)
    if not available then return nil, L["Addon-Nachrichten sind nicht verfügbar."] end
    if not BLOB_ARTS[art] then return nil, L["Unbekannte Datenart."] end
    if not isKey(key) then return nil, L["Ungültiger Raid-Schlüssel."] end
    local ok, why = channelOk(chan, target)
    if not ok then return nil, why end
    local packed, err = ns.CommPack(tbl)
    if not packed then return nil, err end
    local chunks = ns.CommChunks(packed)
    -- translated like every reason here; Raid/Sync.lua and Raid/LootPrio.lua compare it with L["Daten zu groß."]
    if #chunks > (ART_PARTS[art] or MAX_PARTS) then return nil, L["Daten zu groß."] end
    seq = seq % 999999 + 1
    opts = opts or {}
    local list, bytes = {}, 0
    for i, c in ipairs(chunks) do
        local fields = { art, key, tostring(seq), tostring(i), tostring(#chunks), c }
        list[i] = entry("BL", ns.SYNC_PROTO .. "BL\t" .. table.concat(fields, "\t"), chan, target, opts, describe("BL", fields))
        bytes = bytes + cost(list[i])
    end
    enqueue(list, opts.key)
    return true, #chunks, bytes
end

-- The restriction changed: read the state after the dispatch (it is not final during it).
ns.OnEvent("ADDON_RESTRICTION_STATE_CHANGED", function()
    C_Timer.After(0, function()
        if #queue > 0 then pump(true) else held = false end
    end)
end)

---------------------------------------------------------------------------
-- Receiving
---------------------------------------------------------------------------
local handlers, blobHandlers = {}, {}

function ns.CommOn(kind, fn)
    handlers[kind] = handlers[kind] or {}
    table.insert(handlers[kind], fn)
end

function ns.CommOnBlob(art, fn)
    blobHandlers[art] = blobHandlers[art] or {}
    table.insert(blobHandlers[art], fn)
end

local function run(list, ...)
    for _, fn in ipairs(list or {}) do
        local ok, err = pcall(fn, ...)
        if not ok then report(err) end
    end
end

-- per sender (lower case): { times = { t }, bytes = { { t, n } }, ignoreUntil, kinds = { kind -> t },
-- last = the time of its latest message }
local senders = {}
-- A sender silent for 10 minutes without an open part set is forgotten: every limit and gap it
-- held (10 s, 60 s, at most 5 minutes) has run out, so a fresh state means the same.
local SENDER_IDLE, SENDER_SWEEP = 600, 60
local sendersSweptAt = 0

local function senderState(key)
    local t = now()
    if t - sendersSweptAt >= SENDER_SWEEP then
        sendersSweptAt = t
        for k, x in pairs(senders) do
            if t - (x.last or 0) > SENDER_IDLE and #x.sets == 0 then senders[k] = nil end
        end
    end
    local s = senders[key]
    if not s then
        s = { times = {}, bytes = {}, kinds = {}, sets = {}, done = {} }
        senders[key] = s
    end
    s.last = t
    return s
end

-- Whether a message of n bytes from this sender is still within its limits.
local function withinLimits(s, sender, n)
    local t = now()
    if s.ignoreUntil and t < s.ignoreUntil then return false end
    local times, bytes, total = {}, {}, 0
    for _, at in ipairs(s.times) do
        if t - at < RECV_WINDOW then times[#times + 1] = at end
    end
    for _, b in ipairs(s.bytes) do
        if t - b[1] < BYTE_WINDOW then bytes[#bytes + 1] = b; total = total + b[2] end
    end
    times[#times + 1] = t
    bytes[#bytes + 1] = { t, n }
    total = total + n
    s.times, s.bytes = times, bytes
    if #times > RECV_MAX or total > BYTE_MAX then
        s.ignoreUntil = t + IGNORE_FOR
        s.times, s.bytes = {}, {}
        debugLine(L["%s sendet zu viel, 60 s ignoriert."]:format(sender), true)
        return false
    end
    return true
end

-- the reasons of bad() as shown (a message kind such as "HI" shows as it is)
local BAD_REASONS = { Daten = L["Daten"], Absender = L["Absender"], Teile = L["Teile"], Grenze = L["Grenze"],
                      Umschlag = L["Umschlag"], ["Präfix"] = L["Präfix"], Kanal = L["Kanal"] } -- l10n-ok: the reasons as keys

local function bad(reason)
    stats.bad = stats.bad + 1
    noteOnce("bad:" .. reason, L["Ungültige Nachricht verworfen (%s)."]:format(BAD_REASONS[reason] or reason))
end

-- Drops part sets without a new part for 30 s and announces the loss.
local function sweep()
    local t = now()
    for _, s in pairs(senders) do
        local keep = {}
        for _, set in ipairs(s.sets) do
            if t - set.last >= SET_TTL then
                ns.Fire("COMM_BLOB_LOST", set.sender, set.art, set.key)
            else
                keep[#keep + 1] = set
            end
        end
        s.sets = keep
        for id, at in pairs(s.done) do
            if t - at >= DONE_KEEP then s.done[id] = nil end
        end
    end
end

local function dropSet(s, set)
    for j, x in ipairs(s.sets) do if x == set then table.remove(s.sets, j) break end end
end

-- A finished set: unpacked only for a member of the own guild (the roster may have to be read
-- first), then handed to the handlers of its kind.
local function finishSet(sender, name, set)
    local text = table.concat(set.parts, "", 1, set.n)
    local function unpack()
        local tbl = ns.CommUnpack(text)
        if not tbl then
            bad("Daten")
            return
        end
        run(blobHandlers[set.art], sender, tbl, set.chan, set.key)
    end
    ns.TrustWait(name, "member", function(ok)
        if ok then unpack() else bad("Absender") end
    end)
end

-- Whether a part set of kind art for raid key from the raw sender is coming in right now.
function ns.CommIncoming(sender, art, key)
    local s = type(sender) == "string" and senders[sender:lower()]
    if not s then return false end
    sweep()
    for _, set in ipairs(s.sets) do
        if set.art == art and set.key == key then return true end
    end
    return false
end

local function onPart(s, sender, name, f, chan)
    local art, key, n, i = f[1], f[2], tonumber(f[5]), tonumber(f[4])
    local id = art .. ":" .. key .. ":" .. f[3]
    sweep()
    if s.done[id] then return end
    local set
    for _, x in ipairs(s.sets) do
        if x.id == id then set = x break end
    end
    if set and set.n ~= n then
        -- the same set with another part count: all of it is bad
        dropSet(s, set)
        bad("Teile")
        return
    end
    if not set then
        if #s.sets >= SETS_PER_SENDER then
            local oldest = 1
            for j, x in ipairs(s.sets) do if x.last < s.sets[oldest].last then oldest = j end end
            table.remove(s.sets, oldest)
        end
        set = { id = id, art = art, key = key, n = n, parts = {}, got = 0, bytes = 0, sender = sender, chan = chan }
        s.sets[#s.sets + 1] = set
    end
    set.last = now()
    C_Timer.After(SET_TTL + 0.5, sweep)
    if not set.parts[i] then
        -- the open parts and bytes of one sender are bounded before anything is unpacked
        local parts, bytes = 0, 0
        for _, x in ipairs(s.sets) do parts, bytes = parts + x.got, bytes + (x.bytes or 0) end
        if parts + 1 > OPEN_PARTS or bytes + #f[6] > OPEN_BYTES then
            dropSet(s, set)
            bad("Grenze")
            return
        end
        set.parts[i] = f[6]
        set.got = set.got + 1
        set.bytes = set.bytes + #f[6]
    end
    if set.got < n then return end
    dropSet(s, set)
    s.done[id] = now()
    finishSet(sender, name, set)
end

local function onMessage(prefix, text, chan, sender)
    if prefix ~= PREFIX_CTRL and prefix ~= PREFIX_DATA then return end
    if not available then return end
    text, chan, sender = ns.Plain(text), ns.Plain(chan), ns.Plain(sender)
    if type(text) ~= "string" or type(chan) ~= "string" or type(sender) ~= "string" or sender == "" then
        stats.bad = stats.bad + 1
        return
    end
    if isSelf(sender) then return end
    local s = senderState(sender:lower())
    if not withinLimits(s, sender, #text) then
        stats.limited = stats.limited + 1
        return
    end
    local proto, kind, rest = text:match("^(%d)(%u%u)(.*)$")
    proto = tonumber(proto)
    if not proto then return bad("Umschlag") end
    if proto > ns.SYNC_PROTO then return end
    if proto < ns.SYNC_MIN_PROTO then return end
    if prefixOf(kind) ~= prefix then return bad("Präfix") end -- l10n-ok: a reason key, shown via BAD_REASONS
    local fields = {}
    if rest ~= "" then
        if rest:sub(1, 1) ~= "\t" then return bad("Umschlag") end
        for field in (rest:sub(2) .. "\t"):gmatch("([^\t]*)\t") do fields[#fields + 1] = field end
    end
    local check = VALID[kind]
    if not check or not check(fields) then return bad(kind) end
    stats.received = stats.received + 1
    debugLine("< " .. sender .. " " .. describe(kind, fields))
    local gapKey = (kind == "RQ" and fields[5] == "G") and "RQG" or (kind == "QW" and queueNews(fields)) and "QWP" or kind
    local gap = KIND_GAP[gapKey]
    if gap then
        local t = now()
        if s.kinds[gapKey] and t - s.kinds[gapKey] < gap then return end
        s.kinds[gapKey] = t
    end
    local keyed = KEYED_GAP[kind]
    if keyed then
        local t, k = now(), kind .. ":" .. fields[1]
        s.keyed = s.keyed or { n = 0, at = {} }
        if s.keyed.at[k] and t - s.keyed.at[k] < keyed then return end
        if not s.keyed.at[k] then
            if s.keyed.n >= KEYED_MAX then
                local keep, n = {}, 0
                for key, at in pairs(s.keyed.at) do
                    if t - at < 600 then keep[key], n = at, n + 1 end
                end
                s.keyed.at, s.keyed.n = keep, n
                if n >= KEYED_MAX then return end
            end
            s.keyed.n = s.keyed.n + 1
        end
        s.keyed.at[k] = t
    end
    if kind == "BL" then
        if not ns.CommPacking() then return end
        -- no blob art goes to the guild channel (each is RAID or WHISPER): parts there are dropped
        -- unread, before they could be unpacked (security audit 2026-10-17)
        if chan ~= "RAID" and chan ~= "WHISPER" then return bad("Kanal") end
        -- data only from members of the own guild: an outsider's parts are dropped from the first
        -- one on, unread, for a minute
        if s.outsider and now() < s.outsider then return end
        local name = ns.TrustName(sender) or sender
        local member = name and ns.IsVerifiedMember(name)
        if not name or member == false then
            s.outsider, s.sets = now() + OUTSIDER_FOR, {}
            return bad("Absender")
        end
        return onPart(s, sender, name, fields, chan)
    end
    run(handlers[kind], sender, fields, chan, text)
end

ns.OnEvent("CHAT_MSG_ADDON", onMessage)

---------------------------------------------------------------------------
-- A player went offline (2.94.1): the whispers to the name waiting in the queue go, new ones wait GONE_FOR
-- seconds (a message from the name ends that), and the server's "no player named ... online" line for a
-- name Amisia whispered within OFFLINE_KEEP stays out of the chat.
---------------------------------------------------------------------------
local function lineName(text, global)
    text = ns.Plain(text)
    local pattern = type(text) == "string" and ns.TemplatePattern(rawget(_G, global)) or nil
    local name = pattern and text:match(pattern)
    return name and nameKey(ns.TemplateName(name) or name) or nil
end

local function dropWhispers(k)
    for i = #queue, 1, -1 do
        local e = queue[i]
        if e.chan == "WHISPER" and nameKey(e.target) == k then
            stats.dropped = stats.dropped + 1
            table.remove(queue, i)
        end
    end
end

-- Whether a system line is the server's answer to a whisper of Amisia's to a player who is offline; and that
-- player's name key (lower case, no realm; F-221: the layer search lets the name rest).
function ns.CommOfflineLine(text)
    local k = lineName(text, "ERR_CHAT_PLAYER_NOT_FOUND_S")
    local at = k and whisperedAt[k]
    return at ~= nil and GetTime() - at <= OFFLINE_KEEP, k
end

ns.OnEvent("CHAT_MSG_SYSTEM", function(text)
    local k = lineName(text, "ERR_FRIEND_OFFLINE_S")
    if not k and ns.CommOfflineLine(text) then k = lineName(text, "ERR_CHAT_PLAYER_NOT_FOUND_S") end
    if not k then return end
    goneAt[k] = GetTime()
    dropWhispers(k)
end)
-- a message from the name: it is back
ns.OnEvent("CHAT_MSG_ADDON", function(_, _, _, sender)
    local k = nameKey(sender)
    if k then goneAt[k] = nil end
end)

do
    local add = rawget(_G, "ChatFrame_AddMessageEventFilter")
    local util = rawget(_G, "ChatFrameUtil")
    if type(add) ~= "function" and type(util) == "table" then add = util.AddMessageEventFilter end
    if type(add) == "function" then
        pcall(add, "CHAT_MSG_SYSTEM", function(_, _, text)
            local ok, ours = pcall(ns.CommOfflineLine, text)
            return ok and ours or false
        end)
    end
end

---------------------------------------------------------------------------
-- Settings and the sync command
---------------------------------------------------------------------------
-- The "sync" settings section; later parts add their items to SYNC_SETTINGS.items and register it
-- again.
ns.SYNC_SETTINGS = { key = "sync", label = L["Sync und Version"], order = 85, group = "amisia", pages = { "about" }, items = {
    { key = "sync.enabled", type = "toggle", label = L["Raid-Stand mit anderen Amisia-Clients abgleichen"], default = true,
      tip = L["Vergaben, Plus-Eins, Ersatzbank und Bosskills des laufenden Raids. Die Lootleitung hält den Stand."] },
    { key = "sync.debug", type = "toggle", label = L["Sync-Nachrichten im Chat (Fehlersuche)"], default = false, expert = true, tip = L["Schreibt jede Sync-Nachricht in den Chat. Nur zur Fehlersuche."] },
} }
ns.RegisterSettings(ns.SYNC_SETTINGS)

-- /amisia sync <word>: parts register their words here.
local syncWords = {}
function ns.RegisterSyncCommand(word, fn) syncWords[word] = fn end

local SYNC_USAGE = L["[jetzt|an|aus|raenge|debug|selbsttest]"]
-- the English sub-words (they work in every language)
local SYNC_EN = { now = "jetzt", on = "an", off = "aus", ranks = "raenge", selftest = "selbsttest" } -- l10n-ok: the registered sub-words

ns.RegisterSlash("sync", { args = SYNC_USAGE, desc = L["Stand des Abgleichs"], run = function(rest)
    local word, more = (rest or ""):match("^(%S*)%s*(.-)$")
    word = (word or ""):lower()
    if not syncWords[word] and SYNC_EN[word] then word = SYNC_EN[word] end
    if word == "" then
        if not available then
            ns.msg(L["Addon-Nachrichten sind nicht verfügbar."])
            return
        end
        -- the raid sync tells its state itself (word ""); the layer alone says its queue
        if syncWords[""] then return syncWords[""](more) end
        ns.msg(L["Sync %s · %d Nachrichten warten%s."]:format(ns.Get("sync.enabled") ~= false and L["an"] or L["aus"],
            #queue, ns.CommHeld() and L[" (Sperre)"] or ""))
        return
    end
    local fn = syncWords[word]
    if not fn then
        ns.msg(L["Aufruf: /amisia sync %s"]:format(SYNC_USAGE))
        return
    end
    fn(more)
end })

ns.RegisterSyncCommand("debug", function()
    if not ns.Get("ui.expert") then
        ns.msg(L["Nur im Expertenmodus."])
        return
    end
    local on = not ns.Get("sync.debug")
    ns.Set("sync.debug", on)
    ns.msg(on and L["Sync-Fehlersuche an."] or L["Sync-Fehlersuche aus."])
end)
end)
